(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["search-search-module"],{

/***/ "./src/app/search/adapters/search-adapter.ts":
/*!***************************************************!*\
  !*** ./src/app/search/adapters/search-adapter.ts ***!
  \***************************************************/
/*! exports provided: SearchAdapter */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchAdapter", function() { return SearchAdapter; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _models_search__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../models/search */ "./src/app/search/models/search.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");



var SearchAdapter = /** @class */ (function () {
    function SearchAdapter() {
    }
    SearchAdapter.prototype.adapt = function (item) {
        return new _models_search__WEBPACK_IMPORTED_MODULE_1__["Search"]();
    };
    SearchAdapter = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root'
        })
    ], SearchAdapter);
    return SearchAdapter;
}());



/***/ }),

/***/ "./src/app/search/components/additive/additive.component.html":
/*!********************************************************************!*\
  !*** ./src/app/search/components/additive/additive.component.html ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<table class=\"table table-hover\">\r\n    <thead>\r\n        <tr>\r\n            <th scope=\"col\">#</th>\r\n            <th scope=\"col\">Name</th>\r\n            <th scope=\"col\">Concentration</th>\r\n        </tr>\r\n    </thead>\r\n    <tbody>\r\n        <tr *ngFor=\"let additive of additiveList;  let i = index\">\r\n            <td>{{ i+1 }}</td>\r\n            <td>{{ additive.name }}</td>\r\n            <td>{{ additive.concentration }}</td>\r\n        </tr>\r\n    </tbody>\r\n</table>"

/***/ }),

/***/ "./src/app/search/components/additive/additive.component.scss":
/*!********************************************************************!*\
  !*** ./src/app/search/components/additive/additive.component.scss ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NlYXJjaC9jb21wb25lbnRzL2FkZGl0aXZlL2FkZGl0aXZlLmNvbXBvbmVudC5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/search/components/additive/additive.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/search/components/additive/additive.component.ts ***!
  \******************************************************************/
/*! exports provided: AdditiveComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdditiveComponent", function() { return AdditiveComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var AdditiveComponent = /** @class */ (function () {
    function AdditiveComponent() {
    }
    AdditiveComponent.prototype.ngOnInit = function () {
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Array)
    ], AdditiveComponent.prototype, "additiveList", void 0);
    AdditiveComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-additive',
            template: __webpack_require__(/*! ./additive.component.html */ "./src/app/search/components/additive/additive.component.html"),
            styles: [__webpack_require__(/*! ./additive.component.scss */ "./src/app/search/components/additive/additive.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], AdditiveComponent);
    return AdditiveComponent;
}());



/***/ }),

/***/ "./src/app/search/components/advsearch/advsearch.component.html":
/*!**********************************************************************!*\
  !*** ./src/app/search/components/advsearch/advsearch.component.html ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">\r\n    <div class=\"col-12\">\r\n        <div class=\"card\">\r\n            <div class=\"card-header\">\r\n                <fa-icon icon=\"search\"></fa-icon> Criteria\r\n            </div>\r\n            <div class=\"card-body\">\r\n                <form (ngSubmit)=\"submitCriteria()\" autoComplete=\"off\" novalidate>\r\n                    <ul class=\"list-group list-group-flush\">\r\n                        <li class=\"list-group-item\">\r\n                            <div class=\"row\">\r\n                                <div class=\"col-md-2\"></div>\r\n                                <div class=\"col-md-4\">\r\n                                    <span class=\"font-weight-bold\">Field</span>\r\n                                </div>\r\n                                <div class=\"col-md-2\">\r\n                                    <span class=\"font-weight-bold\">Operator</span>\r\n                                </div>\r\n                                <div class=\"col-md-4\">\r\n                                    <span class=\"font-weight-bold\">Value</span>\r\n                                </div>\r\n                            </div>\r\n                        </li>\r\n                        <li class=\"list-group-item\" *ngFor=\"let criteria of model.criteriaList; let idx = index\">\r\n                            <div class=\"row\">\r\n                                <div class=\"col-md-2\">\r\n                                    <button type=\"button\" class=\"btn btn-sm btn-danger float-right\" (click)=\"deleteCriteria(idx)\">\r\n                  <fa-icon icon=\"minus\"></fa-icon>\r\n                </button>\r\n                                </div>\r\n                                <div class=\"col-md-4\">\r\n                                    <ng-select [items]=\"fieldList\" [(ngModel)]=\"criteria.field\" [id]=\"'criteria_field_' + idx\" [name]=\"'criteria.field' + idx\" (change)=\"onFieldChanged(idx, $event)\">\r\n                                    </ng-select>\r\n                                </div>\r\n                                <div class=\"col-md-2\">\r\n                                    <ng-select [items]=\"operatorList\" [(ngModel)]=\"criteria.operation\" [id]=\"'criteria_operator_' + idx\" [name]=\"'criteria.operator' + idx\">\r\n                                    </ng-select>\r\n                                </div>\r\n                                <div [ngClass]=\"criteria.operation === 'range' ? 'col-md-2' : 'col-md-4'\">\r\n                                    <input [placeholder]='criteria.placeholder' class='form-control' [id]=\"'criteria_value_' + idx\" type=\"text\" [(ngModel)]=\"criteria.value.first\" [name]=\"'criteria.value' + idx\">\r\n                                </div>\r\n                                <div [hidden]=\"criteria.operation !== 'range'\" class=\"col-md-2\">\r\n                                    <input [placeholder]='criteria.placeholder' class='form-control' [id]=\"'criteria_value_' + idx\" type=\"text\" [(ngModel)]=\"criteria.value.last\" [name]=\"'criteria.value' + idx\">\r\n                                </div>\r\n                            </div>\r\n                        </li>\r\n                        <li class=\"list-group-item\">\r\n                            <div class=\"row\">\r\n                                <div class=\"col-2\">\r\n                                    <button type=\"button\" class=\"btn btn-sm btn-success float-right\" (click)=\"addCriteria()\">\r\n                  <fa-icon icon=\"plus\"></fa-icon>\r\n                </button>\r\n                                </div>\r\n                                <div class=\"col-8\"></div>\r\n                                <div class=\"col-2\">\r\n                                    <button type=\"submit\" class=\"btn btn-block btn-success\">Search</button>\r\n                                </div>\r\n                            </div>\r\n                        </li>\r\n\r\n                    </ul>\r\n                </form>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>\r\n<div class=\"row\">\r\n    <div class=\"col-12\">\r\n        <div class=\"card\">\r\n            <div class=\"card-header\">\r\n                Search Result\r\n            </div>\r\n            <div class=\"card-body\">\r\n                <div style=\"position: relative; top: 150px\">\r\n                    <ngx-ui-loader [loaderId]=\"'grid-loader'\"></ngx-ui-loader>\r\n                </div>\r\n                <ngx-datatable class=\"bootstrap\" [rows]=\"tableState.data\" [loadingIndicator]=\"tableState.loading\" [columnMode]=\"'force'\" [rowHeight]=\"'auto'\" [summaryRow]=\"false\" [summaryPosition]=\"'bottom'\" [footerHeight]=\"40\" [externalPaging]=\"true\" [externalSorting]=\"true\"\r\n                    [count]=\"tableState.count\" [offset]=\"tableState.page - 1\" [limit]=\"tableState.limit\" (page)='setPage($event)' (sort)=\"onSort($event)\">\r\n\r\n                    <ngx-datatable-column name=\"Test Date\" prop=\"testDate\" [width]=\"70\">\r\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\r\n                            <span class=\"datatable-header-cell-wrapper\">\r\n                          <span class=\"datatable-header-cell-label draggable\" (click)=\"sort(column.prop)\" [ngClass]=\"{'font-weight-bold': tableState.orderBy === column.prop}\">{{ column.name }}</span>\r\n                            <fa-icon [icon]=\"tableState.orderDirection === 'asc' ? 'sort-up' : 'sort-down'\" class=\"float-right\" *ngIf=\"tableState.orderBy === column.prop\"></fa-icon>\r\n                            </span>\r\n                        </ng-template>\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            <a class=\"text-primary small\" target=\"_blank\"  [routerLink]=\"[ '/lab-requests/view/' + row.businessId ]\" [queryParams]=\"{ tab: '2', version: row.version}\">\r\n                          {{value | date }}\r\n                        </a>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"Blend Base\" prop=\"blendBase\">\r\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\r\n                            <span class=\"datatable-header-cell-wrapper\">\r\n                          <span class=\"datatable-header-cell-label draggable\" (click)=\"sort(column.prop)\" [ngClass]=\"{'font-weight-bold': tableState.orderBy === column.prop}\">{{ column.name }}</span>\r\n                            <fa-icon [icon]=\"tableState.orderDirection === 'asc' ? 'sort-up' : 'sort-down'\" class=\"float-right\" *ngIf=\"tableState.orderBy === column.prop\"></fa-icon>\r\n                            </span>\r\n                        </ng-template>\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            <span class=\"small\">{{ value }}</span>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"Density\" prop=\"density\">\r\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\r\n                            <span class=\"datatable-header-cell-wrapper\">\r\n                          <span class=\"datatable-header-cell-label draggable\" (click)=\"sort(column.prop)\" [ngClass]=\"{'font-weight-bold': tableState.orderBy === column.prop}\">{{ column.name }}</span>\r\n                            <fa-icon [icon]=\"tableState.orderDirection === 'asc' ? 'sort-up' : 'sort-down'\" class=\"float-right\" *ngIf=\"tableState.orderBy === column.prop\"></fa-icon>\r\n                            </span>\r\n                        </ng-template>\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            <span class=\"small\">{{ value }}</span>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"TT40\" prop=\"tT40\">\r\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\r\n                            <span class=\"datatable-header-cell-wrapper\">\r\n                          <span class=\"datatable-header-cell-label draggable\" (click)=\"sort(column.prop)\" [ngClass]=\"{'font-weight-bold': tableState.orderBy === column.prop}\">{{ column.name }}</span>\r\n                            <fa-icon [icon]=\"tableState.orderDirection === 'asc' ? 'sort-up' : 'sort-down'\" class=\"float-right\" *ngIf=\"tableState.orderBy === column.prop\"></fa-icon>\r\n                            </span>\r\n                        </ng-template>\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            <span class=\"small\">{{ value }}</span>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"TT100\" prop=\"tT100\">\r\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\r\n                            <span class=\"datatable-header-cell-wrapper\">\r\n                          <span class=\"datatable-header-cell-label draggable\" (click)=\"sort(column.prop)\" [ngClass]=\"{'font-weight-bold': tableState.orderBy === column.prop}\">{{ column.name }}</span>\r\n                            <fa-icon [icon]=\"tableState.orderDirection === 'asc' ? 'sort-up' : 'sort-down'\" class=\"float-right\" *ngIf=\"tableState.orderBy === column.prop\"></fa-icon>\r\n                            </span>\r\n                        </ng-template>\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            <span class=\"small\">{{ value }}</span>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"Free H2O\" prop=\"freeWater\">\r\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\r\n                            <span class=\"datatable-header-cell-wrapper\">\r\n                          <span class=\"datatable-header-cell-label draggable\" (click)=\"sort(column.prop)\" [ngClass]=\"{'font-weight-bold': tableState.orderBy === column.prop}\">{{ column.name }}</span>\r\n                            <fa-icon [icon]=\"tableState.orderDirection === 'asc' ? 'sort-up' : 'sort-down'\" class=\"float-right\" *ngIf=\"tableState.orderBy === column.prop\"></fa-icon>\r\n                            </span>\r\n                        </ng-template>\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            <span class=\"small\">{{ value }}</span>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"Fluid Loss\" prop=\"fluidLoss\">\r\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\r\n                            <span class=\"datatable-header-cell-wrapper\">\r\n                          <span class=\"datatable-header-cell-label draggable\" (click)=\"sort(column.prop)\" [ngClass]=\"{'font-weight-bold': tableState.orderBy === column.prop}\">{{ column.name }}</span>\r\n                            <fa-icon [icon]=\"tableState.orderDirection === 'asc' ? 'sort-up' : 'sort-down'\" class=\"float-right\" *ngIf=\"tableState.orderBy === column.prop\"></fa-icon>\r\n                            </span>\r\n                        </ng-template>\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            <span class=\"small\">{{ value }}</span>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"BHCT\" prop=\"bhct\" [width]=\"50\">\r\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\r\n                            <span class=\"datatable-header-cell-wrapper\">\r\n                          <span class=\"datatable-header-cell-label draggable\" (click)=\"sort(column.prop)\" [ngClass]=\"{'font-weight-bold': tableState.orderBy === column.prop}\">{{ column.name }}</span>\r\n                            <fa-icon [icon]=\"tableState.orderDirection === 'asc' ? 'sort-up' : 'sort-down'\" class=\"float-right\" *ngIf=\"tableState.orderBy === column.prop\"></fa-icon>\r\n                            </span>\r\n                        </ng-template>\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            <span class=\"small\">{{ value }}</span>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"\" prop=\"addictives\" [width]=\"50\">\r\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\r\n                            <span class=\"datatable-header-cell-wrapper\">\r\n                          <span class=\"datatable-header-cell-label draggable\" (click)=\"sort(column.prop)\" [ngClass]=\"{'font-weight-bold': tableState.orderBy === column.prop}\">{{ column.name }}</span>\r\n                            <fa-icon [icon]=\"tableState.orderDirection === 'asc' ? 'sort-up' : 'sort-down'\" class=\"float-right\" *ngIf=\"tableState.orderBy === column.prop\"></fa-icon>\r\n                            </span>\r\n                        </ng-template>\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            <span class=\"small\">\r\n                                <button (click)=\"loadAdditives(row.additives)\" type=\"button\" class=\"btn btn-primary no-margin\">\r\n                                  Additives <span class=\"badge badge-light\"> {{ row.additives?.length || '0' }}</span>\r\n                            <span class=\"sr-only\">additives</span>\r\n                            </button>\r\n                            </span>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                </ngx-datatable>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>"

/***/ }),

/***/ "./src/app/search/components/advsearch/advsearch.component.scss":
/*!**********************************************************************!*\
  !*** ./src/app/search/components/advsearch/advsearch.component.scss ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".no-margin {\n  padding: 0; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2VhcmNoL2NvbXBvbmVudHMvYWR2c2VhcmNoL0U6XFxmcm9udGVuZDEvc3JjXFxhcHBcXHNlYXJjaFxcY29tcG9uZW50c1xcYWR2c2VhcmNoXFxhZHZzZWFyY2guY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxVQUFVLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9zZWFyY2gvY29tcG9uZW50cy9hZHZzZWFyY2gvYWR2c2VhcmNoLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm5vLW1hcmdpbiB7XHJcbiAgICBwYWRkaW5nOiAwO1xyXG59Il19 */"

/***/ }),

/***/ "./src/app/search/components/advsearch/advsearch.component.ts":
/*!********************************************************************!*\
  !*** ./src/app/search/components/advsearch/advsearch.component.ts ***!
  \********************************************************************/
/*! exports provided: AdvsearchComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdvsearchComponent", function() { return AdvsearchComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_search_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/search.service */ "./src/app/search/services/search.service.ts");
/* harmony import */ var src_app_core_datatable_table_state__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/datatable/table-state */ "./src/app/core/datatable/table-state.ts");
/* harmony import */ var ngx_ui_loader__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ngx-ui-loader */ "./node_modules/ngx-ui-loader/fesm5/ngx-ui-loader.js");
/* harmony import */ var _models_search_criteria__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../models/search-criteria */ "./src/app/search/models/search-criteria.ts");
/* harmony import */ var _models_search_view_model__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../models/search-view-model */ "./src/app/search/models/search-view-model.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _additive_additive_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../additive/additive.component */ "./src/app/search/components/additive/additive.component.ts");










var AdvsearchComponent = /** @class */ (function () {
    function AdvsearchComponent(searchService, ngxService, modalService) {
        this.searchService = searchService;
        this.ngxService = ngxService;
        this.modalService = modalService;
        this.tableState = new src_app_core_datatable_table_state__WEBPACK_IMPORTED_MODULE_3__["TableState"]();
        this.logicList = ['and', 'or'];
        this.fieldList = [];
        this.operatorList = ['equals', 'greaterthan', 'lessthan', 'startswith', 'endwith', 'contains', 'range'];
        this.dataLoaded = false;
    }
    AdvsearchComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.model = new _models_search_view_model__WEBPACK_IMPORTED_MODULE_6__["SearchViewModel"]();
        this.model.criteriaList.push(new _models_search_criteria__WEBPACK_IMPORTED_MODULE_5__["SearchCriteria"]());
        var a = {
            blendbase: '',
            density: 0,
            bhct: 0,
            bhst: 0,
            fluidloss: '',
            freewaterangle: '',
            freewaterpercent: '',
            tt40: '',
            tt100: '',
            testdate: '',
            intervaltosgsa: '',
        };
        Object.keys(a).forEach(function (key) { return _this.fieldList.push(key); });
    };
    AdvsearchComponent.prototype.search = function (criteria) {
        var _this = this;
        if (criteria.length !== 0) {
            var criteria_resolved = new _models_search_criteria__WEBPACK_IMPORTED_MODULE_5__["SearchCriteriaReq"]();
            this.current_criteria = Object.assign([], criteria);
            criteria_resolved.request = criteria;
            this.ngxService.startLoader('grid-loader');
            this.searchService.search(this.tableState.page, this.tableState.limit, this.tableState.filters, this.tableState.orderBy, this.tableState.orderDirection, criteria_resolved).subscribe(function (response) {
                _this.dataLoaded = true;
                _this.tableState.attachResponse(response);
                _this.ngxService.stopLoader('grid-loader');
            });
        }
        else {
            this.model.criteriaList.push(new _models_search_criteria__WEBPACK_IMPORTED_MODULE_5__["SearchCriteria"]());
        }
    };
    AdvsearchComponent.prototype.setPage = function (pageInfo) {
        this.tableState.page = pageInfo.offset + 1;
        this.search(this.current_criteria);
    };
    AdvsearchComponent.prototype.onSort = function (event) {
        this.tableState.setOrdering(event.column.prop);
        this.search(this.current_criteria);
    };
    AdvsearchComponent.prototype.sort = function (columnName) {
        if (this.dataLoaded) {
            this.tableState.setOrdering(columnName);
            this.search(this.current_criteria);
        }
    };
    AdvsearchComponent.prototype.showMe = function (row) {
    };
    AdvsearchComponent.prototype.columnSearch = function (columName$) {
        var _this = this;
        var func = function (text$) {
            return text$.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["debounceTime"])(300), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["distinctUntilChanged"])(), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["map"])(function (term) {
                _this.tableState.setFilter(columName$, term);
                _this.search(_this.current_criteria);
            }));
        };
        return func;
    };
    AdvsearchComponent.prototype.addCriteria = function () {
        this.model.criteriaList.push(new _models_search_criteria__WEBPACK_IMPORTED_MODULE_5__["SearchCriteria"]());
    };
    AdvsearchComponent.prototype.deleteCriteria = function (index) {
        this.model.criteriaList.splice(index, 1);
    };
    AdvsearchComponent.prototype.submitCriteria = function () {
        this.validate(this.model.criteriaList);
        this.search(this.model.criteriaList);
    };
    AdvsearchComponent.prototype.validate = function (criteria) {
        criteria.forEach(function (c, indx) {
            if (c.field === '' || c.operation === '' || c.value.first === '') {
                criteria.splice(indx, 1);
            }
        });
    };
    AdvsearchComponent.prototype.loadAdditives = function (additives) {
        var modalRef = this.modalService.open(_additive_additive_component__WEBPACK_IMPORTED_MODULE_9__["AdditiveComponent"], { size: 'lg' });
        modalRef.componentInstance.additiveList = additives;
    };
    AdvsearchComponent.prototype.onFieldChanged = function (idx, val) {
        if (val === 'testdate') {
            this.model.criteriaList[idx].placeholder = 'mm/dd/yyyy';
        }
    };
    AdvsearchComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-advsearch',
            template: __webpack_require__(/*! ./advsearch.component.html */ "./src/app/search/components/advsearch/advsearch.component.html"),
            styles: [__webpack_require__(/*! ./advsearch.component.scss */ "./src/app/search/components/advsearch/advsearch.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_search_service__WEBPACK_IMPORTED_MODULE_2__["SearchService"],
            ngx_ui_loader__WEBPACK_IMPORTED_MODULE_4__["NgxUiLoaderService"],
            _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_8__["NgbModal"]])
    ], AdvsearchComponent);
    return AdvsearchComponent;
}());



/***/ }),

/***/ "./src/app/search/models/search-criteria.ts":
/*!**************************************************!*\
  !*** ./src/app/search/models/search-criteria.ts ***!
  \**************************************************/
/*! exports provided: SearchCriteria, SearchCriteriaReq */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchCriteria", function() { return SearchCriteria; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchCriteriaReq", function() { return SearchCriteriaReq; });
var SearchCriteria = /** @class */ (function () {
    function SearchCriteria() {
        this.value = { first: '', last: '' };
        this.placeholder = '';
    }
    return SearchCriteria;
}());

var SearchCriteriaReq = /** @class */ (function () {
    function SearchCriteriaReq() {
    }
    return SearchCriteriaReq;
}());



/***/ }),

/***/ "./src/app/search/models/search-view-model.ts":
/*!****************************************************!*\
  !*** ./src/app/search/models/search-view-model.ts ***!
  \****************************************************/
/*! exports provided: SearchViewModel */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchViewModel", function() { return SearchViewModel; });
var SearchViewModel = /** @class */ (function () {
    function SearchViewModel() {
        this.resultList = [];
        this.criteriaList = [];
    }
    return SearchViewModel;
}());



/***/ }),

/***/ "./src/app/search/models/search.ts":
/*!*****************************************!*\
  !*** ./src/app/search/models/search.ts ***!
  \*****************************************/
/*! exports provided: Search */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Search", function() { return Search; });
var Search = /** @class */ (function () {
    function Search() {
    }
    return Search;
}());



/***/ }),

/***/ "./src/app/search/search-routing.module.ts":
/*!*************************************************!*\
  !*** ./src/app/search/search-routing.module.ts ***!
  \*************************************************/
/*! exports provided: SearchRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchRoutingModule", function() { return SearchRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _components_advsearch_advsearch_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/advsearch/advsearch.component */ "./src/app/search/components/advsearch/advsearch.component.ts");




var routes = [{
        path: '',
        component: _components_advsearch_advsearch_component__WEBPACK_IMPORTED_MODULE_3__["AdvsearchComponent"]
    }];
var SearchRoutingModule = /** @class */ (function () {
    function SearchRoutingModule() {
    }
    SearchRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], SearchRoutingModule);
    return SearchRoutingModule;
}());



/***/ }),

/***/ "./src/app/search/search.module.ts":
/*!*****************************************!*\
  !*** ./src/app/search/search.module.ts ***!
  \*****************************************/
/*! exports provided: SearchModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchModule", function() { return SearchModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _search_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./search-routing.module */ "./src/app/search/search-routing.module.ts");
/* harmony import */ var _components_advsearch_advsearch_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/advsearch/advsearch.component */ "./src/app/search/components/advsearch/advsearch.component.ts");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @swimlane/ngx-datatable */ "./node_modules/@swimlane/ngx-datatable/release/index.js");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _fortawesome_angular_fontawesome__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @fortawesome/angular-fontawesome */ "./node_modules/@fortawesome/angular-fontawesome/fesm5/angular-fontawesome.js");
/* harmony import */ var _fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @fortawesome/fontawesome-svg-core */ "./node_modules/@fortawesome/fontawesome-svg-core/index.es.js");
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @fortawesome/free-solid-svg-icons */ "./node_modules/@fortawesome/free-solid-svg-icons/index.es.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var ngx_ui_loader__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ngx-ui-loader */ "./node_modules/ngx-ui-loader/fesm5/ngx-ui-loader.js");
/* harmony import */ var _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ng-select/ng-select */ "./node_modules/@ng-select/ng-select/fesm5/ng-select.js");
/* harmony import */ var _services_search_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./services/search.service */ "./src/app/search/services/search.service.ts");
/* harmony import */ var _components_additive_additive_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./components/additive/additive.component */ "./src/app/search/components/additive/additive.component.ts");















var SearchModule = /** @class */ (function () {
    function SearchModule() {
        _fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_8__["library"].add(_fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faSearch"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faVial"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faSortUp"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faSortDown"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faCalendarAlt"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faBlender"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faHashtag"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faIndustry"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faAddressCard"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faLocationArrow"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faMapMarkerAlt"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faArrowCircleDown"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faInfoCircle"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faVials"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faComment"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faArrowCircleLeft"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faDownload"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faCircleNotch"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faEdit"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faTimesCircle"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faSave"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faPlus"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faMinus"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faCodeBranch"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faStar"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faPoll"]);
    }
    SearchModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_components_advsearch_advsearch_component__WEBPACK_IMPORTED_MODULE_5__["AdvsearchComponent"], _components_additive_additive_component__WEBPACK_IMPORTED_MODULE_14__["AdditiveComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _search_routing_module__WEBPACK_IMPORTED_MODULE_4__["SearchRoutingModule"],
                _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_6__["NgxDatatableModule"],
                _fortawesome_angular_fontawesome__WEBPACK_IMPORTED_MODULE_7__["FontAwesomeModule"],
                _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_10__["NgbModule"],
                ngx_ui_loader__WEBPACK_IMPORTED_MODULE_11__["NgxUiLoaderModule"],
                _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_12__["NgSelectModule"]
            ],
            entryComponents: [
                _components_additive_additive_component__WEBPACK_IMPORTED_MODULE_14__["AdditiveComponent"]
            ],
            exports: [
                _components_additive_additive_component__WEBPACK_IMPORTED_MODULE_14__["AdditiveComponent"]
            ],
            providers: [_services_search_service__WEBPACK_IMPORTED_MODULE_13__["SearchService"]]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], SearchModule);
    return SearchModule;
}());



/***/ }),

/***/ "./src/app/search/services/search.service.ts":
/*!***************************************************!*\
  !*** ./src/app/search/services/search.service.ts ***!
  \***************************************************/
/*! exports provided: SearchService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchService", function() { return SearchService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _adapters_search_adapter__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../adapters/search-adapter */ "./src/app/search/adapters/search-adapter.ts");





var SearchService = /** @class */ (function () {
    function SearchService(http, searchAdapter) {
        this.http = http;
        this.searchAdapter = searchAdapter;
        this.serviceUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].sldAli + "/search";
    }
    SearchService.prototype.search = function (page, limit, filters, orderBy, orderDirection, criteria) {
        var url = "" + this.serviceUrl;
        var filterQuery = [];
        filters.forEach(function (value, key) {
            key.replace(':', '\:');
            value.replace(':', '\:');
            filterQuery.push(key + ":" + value);
        });
        var q = filterQuery.join('&&');
        var queryParams = [];
        if (page) {
            queryParams.push("page=" + page);
        }
        if (limit) {
            queryParams.push("limit=" + limit);
        }
        if (orderBy) {
            queryParams.push("orderBy=" + orderBy);
        }
        if (orderDirection) {
            queryParams.push("orderDirection=" + orderDirection);
        }
        if (q) {
            queryParams.push("q=" + encodeURIComponent(q));
        }
        var queryString = queryParams.join('&');
        if (queryString) {
            url = url.concat('?', queryString);
        }
        return this.http.post(url, criteria);
    };
    SearchService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"],
            _adapters_search_adapter__WEBPACK_IMPORTED_MODULE_4__["SearchAdapter"]])
    ], SearchService);
    return SearchService;
}());



/***/ })

}]);
//# sourceMappingURL=search-search-module.js.map