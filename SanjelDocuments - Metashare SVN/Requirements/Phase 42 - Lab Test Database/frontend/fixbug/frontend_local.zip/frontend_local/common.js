(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["common"],{

/***/ "./src/app/lab-sample/adapters/lab-sample-adapter.ts":
/*!***********************************************************!*\
  !*** ./src/app/lab-sample/adapters/lab-sample-adapter.ts ***!
  \***********************************************************/
/*! exports provided: LabSampleAdapter */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LabSampleAdapter", function() { return LabSampleAdapter; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var LabSampleAdapter = /** @class */ (function () {
    function LabSampleAdapter() {
    }
    LabSampleAdapter.prototype.adapt = function (item) {
        var ret = {
            id: item.id,
            qcNumber: item.qcNumber,
            name: item.name,
            type: item.type,
            district: item.district,
            client: item.client,
            wellName: item.wellName,
            districtId: item.districtId,
            highProfile: item.highProfile,
            lsd: item.lsd,
            clientId: item.clientId,
            quantity: item.quantity,
            containerCount: item.containerCount,
            storageLocation: item.storageLocation,
            discarded: item.discarded,
            dateCollected: new Date(item.dateCollected),
            waterAnalysis: item.waterAnalysis,
            qualityControl: item.qualityControl,
            loginNo: item.loginNo,
            comments: item.comments,
            sampleSource: item.sampleSource,
            mtsNumber: item.mtsNumber,
            modifiedBy: item.modifiedBy,
            modifiedOn: item.modifiedOn,
            createdBy: item.createdBy,
            createdDate: item.createdDate
        };
        return ret;
    };
    LabSampleAdapter = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        })
    ], LabSampleAdapter);
    return LabSampleAdapter;
}());



/***/ }),

/***/ "./src/app/lab-sample/services/lab-sample.service.ts":
/*!***********************************************************!*\
  !*** ./src/app/lab-sample/services/lab-sample.service.ts ***!
  \***********************************************************/
/*! exports provided: LabSampleService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LabSampleService", function() { return LabSampleService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _adapters_lab_sample_adapter__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../adapters/lab-sample-adapter */ "./src/app/lab-sample/adapters/lab-sample-adapter.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");






var LabSampleService = /** @class */ (function () {
    function LabSampleService(http, labsampleAdapter) {
        this.http = http;
        this.labsampleAdapter = labsampleAdapter;
        this.serviceUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].sldAli + "/labSamples";
    }
    LabSampleService.prototype.lookupLogin = function () {
        var url = "" + this.serviceUrl;
        return this.http.get(url);
    };
    LabSampleService.prototype.getLoginList = function () {
        var url = "" + this.serviceUrl;
        return this.http.get(url)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(function (resp) { return resp.result.map(function (result) { return (result.loginNo); }); }));
    };
    LabSampleService.prototype.getLabSamples = function (page, limit, filters, orderBy, orderDirection) {
        var url = "" + this.serviceUrl;
        var filterQuery = [];
        filters.forEach(function (value, key) {
            key.replace(':', '\:');
            value.replace(':', '\:');
            filterQuery.push(key + ":" + value);
        });
        var q = filterQuery.join('&&');
        var queryParams = [];
        if (page) {
            queryParams.push("page=" + page);
        }
        if (limit) {
            queryParams.push("limit=" + limit);
        }
        if (orderBy) {
            queryParams.push("orderBy=" + orderBy);
        }
        if (orderDirection) {
            queryParams.push("orderDirection=" + orderDirection);
        }
        if (q) {
            queryParams.push("q=" + encodeURIComponent(q));
        }
        var queryString = queryParams.join('&');
        if (queryString) {
            url = url.concat('?', queryString);
        }
        return this.http.get(url);
    };
    LabSampleService.prototype.getLabSample = function (id) {
        var _this = this;
        var url = this.serviceUrl + "/" + id;
        return this.http.get(url)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(function (response) { return _this.labsampleAdapter.adapt(response); }));
    };
    LabSampleService.prototype.saveLabSample = function (labSample) {
        var _this = this;
        var url = "" + this.serviceUrl;
        return this.http.post(url, labSample)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(function (response) { return _this.labsampleAdapter.adapt(response); }));
    };
    LabSampleService.prototype.updateLabSample = function (id, labSample) {
        var url = this.serviceUrl + "/" + id;
        return this.http.put(url, labSample);
    };
    LabSampleService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"],
            _adapters_lab_sample_adapter__WEBPACK_IMPORTED_MODULE_4__["LabSampleAdapter"]])
    ], LabSampleService);
    return LabSampleService;
}());



/***/ }),

/***/ "./src/app/master-data/services/service-point.service.ts":
/*!***************************************************************!*\
  !*** ./src/app/master-data/services/service-point.service.ts ***!
  \***************************************************************/
/*! exports provided: ServicePointService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ServicePointService", function() { return ServicePointService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");




var ServicePointService = /** @class */ (function () {
    function ServicePointService(http) {
        this.http = http;
    }
    ServicePointService.prototype.lookupDistrict = function (filter) {
        var url = src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].sldAli + "/servicePoints?filter=" + filter;
        return this.http
            .get(url);
    };
    ServicePointService.prototype.lookupClient = function (filter) {
        var url = src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].sldAli + "/customers?filter=" + filter;
        return this.http
            .get(url);
    };
    ServicePointService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], ServicePointService);
    return ServicePointService;
}());



/***/ }),

/***/ "./src/app/user/services/user.service.ts":
/*!***********************************************!*\
  !*** ./src/app/user/services/user.service.ts ***!
  \***********************************************/
/*! exports provided: UserService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserService", function() { return UserService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");





var UserService = /** @class */ (function () {
    function UserService(http) {
        this.http = http;
    }
    UserService.prototype.search = function (userName) {
        return this.http.get(src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].sldAli + "/ldapusers?userName=" + userName).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(function (response) { return response.result; }));
    };
    UserService.prototype.getUsers = function (page, limit) {
        return this.http.get(src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].sldAli + "/users?page=" + page + "&limit=" + limit);
    };
    UserService.prototype.createUser = function (userName) {
        return this.http.post(src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].sldAli + "/users", {
            userName: userName
        });
    };
    UserService.prototype.deleteUser = function (userId) {
        return this.http.delete(src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].sldAli + "/users/" + userId);
    };
    UserService.prototype.setLock = function (user) {
        var endpoint = src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].sldAli + "/users/lock/" + user.userId;
        return user.blocked ? this.http.delete(endpoint) : this.http.put(endpoint, {});
    };
    UserService.prototype.update = function (user) {
        return this.http.put(src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].sldAli + "/users/" + user.userId, {
            roles: user.roles
        });
    };
    UserService.prototype.getRoles = function () {
        return this.http.get(src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].sldAli + "/roles");
    };
    UserService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], UserService);
    return UserService;
}());



/***/ }),

/***/ "./src/app/water-analysis/adapters/water-sample-adapter.ts":
/*!*****************************************************************!*\
  !*** ./src/app/water-analysis/adapters/water-sample-adapter.ts ***!
  \*****************************************************************/
/*! exports provided: WaterSampleAdapter */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WaterSampleAdapter", function() { return WaterSampleAdapter; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var WaterSampleAdapter = /** @class */ (function () {
    function WaterSampleAdapter() {
    }
    WaterSampleAdapter.prototype.adapt = function (item) {
        var ret = {
            id: item.id,
            sampleId: item.sampleId,
            serviceCenter: item.serviceCenter,
            salesRep: item.salesRep,
            tsRep: item.tsRep,
            labAnalyst: item.labAnalyst,
            analysisMethod: item.analysisMethod,
            ph: item.ph,
            isH2SPresent: item.isH2SPresent,
            pAlkanity: item.pAlkanity,
            tAlkanity: item.tAlkanity,
            hydroxide: item.hydroxide,
            carbonate: item.carbonate,
            bicarbonate: item.bicarbonate,
            chloride: item.chloride,
            sulfate: item.sulfate,
            calcium: item.calcium,
            iron: item.iron,
            magnesium: item.magnesium,
            sodium: item.sodium,
            remainingVolume: item.remainingVolume,
            colour: item.colour,
            appearance: item.appearance,
            odour: item.odour,
            notes: item.notes,
            withinSpecs: item.withinSpecs,
            labSample: item.labSample,
            analyzedDate: new Date(item.analyzedDate),
            createdOn: item.createdOn,
            createdBy: item.createdBy,
            modifiedOn: item.modifiedOn,
            modifiedBy: item.modifiedBy
        };
        return ret;
    };
    WaterSampleAdapter = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        })
    ], WaterSampleAdapter);
    return WaterSampleAdapter;
}());



/***/ }),

/***/ "./src/app/water-analysis/services/water-analysis.service.ts":
/*!*******************************************************************!*\
  !*** ./src/app/water-analysis/services/water-analysis.service.ts ***!
  \*******************************************************************/
/*! exports provided: WaterAnalysisService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WaterAnalysisService", function() { return WaterAnalysisService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _adapters_water_sample_adapter__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../adapters/water-sample-adapter */ "./src/app/water-analysis/adapters/water-sample-adapter.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var src_app_core_utils_file_download_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/utils/file-download.service */ "./src/app/core/utils/file-download.service.ts");
/* harmony import */ var http_status_codes__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! http-status-codes */ "./node_modules/http-status-codes/index.js");
/* harmony import */ var http_status_codes__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(http_status_codes__WEBPACK_IMPORTED_MODULE_7__);








var WaterAnalysisService = /** @class */ (function () {
    function WaterAnalysisService(http, waterSampleAdapter, fileDownloadService) {
        this.http = http;
        this.waterSampleAdapter = waterSampleAdapter;
        this.fileDownloadService = fileDownloadService;
        this.serviceUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].sldAli + "/wateranalysis";
    }
    WaterAnalysisService.prototype.getWaterSamples = function (page, limit, filters, orderBy, orderDirection) {
        var url = "" + this.serviceUrl;
        var filterQuery = [];
        filters.forEach(function (value, key) {
            key.replace(':', '\:');
            value.replace(':', '\:');
            filterQuery.push(key + ":" + value);
        });
        var q = filterQuery.join('&&');
        var queryParams = [];
        if (page) {
            queryParams.push("page=" + page);
        }
        if (limit) {
            queryParams.push("limit=" + limit);
        }
        if (orderBy) {
            queryParams.push("orderBy=" + orderBy);
        }
        if (orderDirection) {
            queryParams.push("orderDirection=" + orderDirection);
        }
        if (q) {
            queryParams.push("q=" + encodeURIComponent(q));
        }
        var queryString = queryParams.join('&');
        if (queryString) {
            url = url.concat('?', queryString);
        }
        return this.http.get(url);
    };
    WaterAnalysisService.prototype.getWaterSample = function (id) {
        var _this = this;
        var url = this.serviceUrl + "/" + id;
        return this.http.get(url)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(function (response) { return _this.waterSampleAdapter.adapt(response); }));
    };
    WaterAnalysisService.prototype.getWaterSamplesBySampleId = function (sampleid) {
        var url = this.serviceUrl + "/sample/" + sampleid;
        return this.http.get(url).subscribe(function (data) { return true; }, function (error) { if (error.status === http_status_codes__WEBPACK_IMPORTED_MODULE_7__["NOT_FOUND"]) {
            return false;
        } });
    };
    WaterAnalysisService.prototype.saveWaterSample = function (waterSample) {
        var url = "" + this.serviceUrl;
        return this.http.post(url, waterSample);
    };
    WaterAnalysisService.prototype.updateWaterSample = function (id, waterSample) {
        var url = this.serviceUrl + "/" + id;
        return this.http.put(url, waterSample);
    };
    WaterAnalysisService.prototype.downloadChart = function (id) {
        var url = this.serviceUrl + "/" + id + "/chartcreator";
        return this.fileDownloadService.downloadFile(url);
    };
    WaterAnalysisService.prototype.downloadResult = function (id) {
        var url = this.serviceUrl + "/" + id + "/chartresult";
        return this.fileDownloadService.downloadFile(url);
    };
    WaterAnalysisService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"],
            _adapters_water_sample_adapter__WEBPACK_IMPORTED_MODULE_4__["WaterSampleAdapter"],
            src_app_core_utils_file_download_service__WEBPACK_IMPORTED_MODULE_6__["FileDownloadService"]])
    ], WaterAnalysisService);
    return WaterAnalysisService;
}());



/***/ })

}]);
//# sourceMappingURL=common.js.map