(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["lab-request-lab-request-module"],{

/***/ "./src/app/core/utils/library.service.ts":
/*!***********************************************!*\
  !*** ./src/app/core/utils/library.service.ts ***!
  \***********************************************/
/*! exports provided: LibraryService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LibraryService", function() { return LibraryService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var LibraryService = /** @class */ (function () {
    function LibraryService() {
    }
    LibraryService.prototype.titleCaseToStatement = function (strValue) {
        var template = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        var strArray = strValue.split('');
        strArray.forEach(function (value, indx) {
            if (template.includes(value)) {
                strArray.splice(indx, 1, " " + value);
            }
        });
        return strArray.join('');
    };
    LibraryService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], LibraryService);
    return LibraryService;
}());



/***/ }),

/***/ "./src/app/lab-request/adapters/lab-request-adapter.ts":
/*!*************************************************************!*\
  !*** ./src/app/lab-request/adapters/lab-request-adapter.ts ***!
  \*************************************************************/
/*! exports provided: LabRequestAdapter */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LabRequestAdapter", function() { return LabRequestAdapter; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _models_lab_request__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../models/lab-request */ "./src/app/lab-request/models/lab-request.ts");
/* harmony import */ var _models_blend__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../models/blend */ "./src/app/lab-request/models/blend.ts");
/* harmony import */ var _models_additive__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../models/additive */ "./src/app/lab-request/models/additive.ts");
/* harmony import */ var _models_well__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../models/well */ "./src/app/lab-request/models/well.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");






var LabRequestAdapter = /** @class */ (function () {
    function LabRequestAdapter() {
    }
    LabRequestAdapter.prototype.adapt = function (item) {
        var additives = [];
        for (var _i = 0, _a = item.blend.additives; _i < _a.length; _i++) {
            var additive = _a[_i];
            additives.push(new _models_additive__WEBPACK_IMPORTED_MODULE_3__["Additive"](additive.name, additive.concentration, additive.blendBase));
        }
        return new _models_lab_request__WEBPACK_IMPORTED_MODULE_1__["LabRequest"](item.id, item.businessId, item.version, item.iterationId, item.createdBy, item.status, new Date(item.createdOn), item.modifiedBy, new Date(item.modifiedOn), item.type, item.jobType, new Date(item.dateRequired), item.programNumber, item.comment, new _models_blend__WEBPACK_IMPORTED_MODULE_2__["Blend"](item.blend.name, item.blend.base, additives), item.density, item.bhct, item.bhst, item.mixWater, item.waterLoginNo, item.salt, item.saltConcentration, item.cementSource, item.cementLoginNo, item.specificGravity, item.loadAndGo, item.opr, item.sgSlurry, item.sgPowder, item.clientName, item.clientServiceRepresentative, item.clientServiceRepresentativeEmail, item.technicalServiceRepresentative, item.technicalServiceRepresentativeEmail, new _models_well__WEBPACK_IMPORTED_MODULE_4__["Well"](item.well.name, item.well.servicePoint, item.well.downholeLocation, item.well.surfaceLocation, item.well.tmd, item.well.tvd, item.well.pressure), item.tests, item.iterations);
    };
    LabRequestAdapter = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Injectable"])({
            providedIn: 'root'
        })
    ], LabRequestAdapter);
    return LabRequestAdapter;
}());



/***/ }),

/***/ "./src/app/lab-request/components/lab-request-detail/lab-request-detail.component.html":
/*!*********************************************************************************************!*\
  !*** ./src/app/lab-request/components/lab-request-detail/lab-request-detail.component.html ***!
  \*********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">\r\n    <div class=\"col-12\">\r\n        <div *ngIf=\"model\" class=\"card\" [ngClass]=\"{'sld-card-warning': model.status === 'New', 'sld-card-info':  model.status === 'InProgress', 'sld-card-success':  model.status === 'Completed', 'sld-card-danger':  model.status === 'Cancelled'}\">\r\n            <div class=\"card-body\">\r\n                <div class=\"row\">\r\n                    <div class=\"col-12\">\r\n                        <div class=\"row\">\r\n                            <div class=\"col-lg-10 col-md-12\">\r\n                                <h4 class=\"card-title mb-0 text-primary\">\r\n                                    <fa-icon icon=\"vial\" [ngClass]=\"{'text-warning': model.status === 'New', 'text-info': model.status === 'InProgress', 'text-success': model.status === 'Completed', 'text-danger': model.status === 'Cancelled'}\">\r\n                                    </fa-icon>\r\n                                    Lab Request <span class=\"font-weight-bold\">{{ model.businessId }}</span>\r\n\r\n                                    <span [hidden]=\"statusChange\" class=\"badge ml-2\" (click)=\"toggleState();\" [ngClass]=\"{'badge-warning': model.status === 'New', 'badge-info': model.status === 'InProgress', 'badge-success': model.status === 'Completed', 'badge-danger': model.status === 'Cancelled'}\">{{model.status}}</span>\r\n                                    <div class=\"keep-in-line col-md-4\">\r\n                                        <ng-select [hidden]=\"!statusChange\" class=\"small ml-4\" [items]=\"stateList\" [(ngModel)]='model.status' (change)='onStateChanged()'>\r\n                                        </ng-select>\r\n                                    </div>\r\n                                </h4>\r\n\r\n                                <div class=\"small text-muted\">Created on {{ model.createdOn | date }} by {{ model.createdBy }}, last updated on {{ model.modifiedOn | date }} by {{ model.modifiedBy }}</div>\r\n                            </div>\r\n                            <div class=\"col-lg-2 col-md-12\">\r\n                                <div class=\"btn-toolbar float-right\" role=\"toolbar\" aria-label=\"Toolbar\">\r\n                                    <a *ngIf=\"!isExperimentalMode\" class=\"btn btn-sm btn-outline-primary ml-1 mt-1\" [routerLink]=\"[ '/lab-requests' ]\">\r\n                                        <fa-icon icon=\"arrow-circle-left\"></fa-icon> Return to list\r\n                                    </a>\r\n                                    <a *ngIf=\"isExperimentalMode\" class=\"btn btn-sm btn-outline-primary ml-1 mt-1\" [routerLink]=\"[ '/experimental' ]\">\r\n                                        <fa-icon icon=\"arrow-circle-left\"></fa-icon> Return to list\r\n                                    </a>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <hr>\r\n                <div class=\"row\">\r\n                    <div class=\"col-12\">\r\n                        <ngb-tabset [activeId]=\"tab\">\r\n                            <ngb-tab [id]=\"0\">\r\n                                <ng-template ngbTabTitle><span class=\"text-primary\">\r\n                    <fa-icon icon=\"info-circle\"></fa-icon> General\r\n                  </span></ng-template>\r\n                                <ng-template ngbTabContent>\r\n                                    <form #labRequestForm=\"ngForm\" autocomplete=\"off\">\r\n                                        <div class=\"row\">\r\n                                            <div class=\"col-12\">\r\n                                                <div *ngIf=\"readonly && isInRole(['admin', 'Lab_Team', 'Lab_Manager'])\" class=\"btn-toolbar float-right mb-2\" role=\"toolbar\" aria-label=\"Toolbar\">\r\n                                                    <button type=\"button\" class=\"btn btn-sm btn-outline-primary ml-1\" (click)=\"edit()\">\r\n                            <fa-icon icon=\"edit\"></fa-icon> Edit\r\n                          </button>\r\n                                                </div>\r\n                                                <div [hidden]=\"readonly\" class=\"btn-toolbar float-right mb-2\" role=\"toolbar\" aria-label=\"Toolbar\">\r\n                                                    <span (mouseenter)=\"mouseoverSave=true\" (mouseleave)=\"mouseoverSave=false\">\r\n                            <button [disabled]=\"labRequestForm.invalid\" [hidden]=\"!newrequest\" type=\"button\" class=\"btn btn-sm btn-success ml-1\" (click)=\"nextTab()\">\r\n                              <fa-icon icon=\"angle-right\"></fa-icon> Next\r\n                            </button></span>\r\n                                                    <button [hidden]=\"newrequest\" type=\"button\" class=\"btn btn-sm btn-success ml-1\" (click)=\"save()\">\r\n                            <fa-icon icon=\"save\"></fa-icon> Save\r\n                          </button>\r\n                                                    <button type=\"button\" class=\"btn btn-sm btn-outline-primary ml-1\" (click)=\"cancel()\">\r\n                            <fa-icon icon=\"times-circle\"></fa-icon> Cancel\r\n                          </button>\r\n                                                </div>\r\n                                            </div>\r\n                                        </div>\r\n                                        <div class=\"form-row\">\r\n                                            <div class=\"form-group col-sm-12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"programNumber\">\r\n                          <fa-icon icon=\"hashtag\"></fa-icon> Program Number\r\n                        </label>\r\n                                                <input autofocus [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"programNumber\" type=\"text\" [(ngModel)]=\"model.programNumber\" name=\"programNumber\">\r\n                                            </div>\r\n                                            <div class=\"form-group col-sm12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"name\">\r\n                          <fa-icon icon=\"calendar-alt\"></fa-icon> Date Required\r\n                        </label>\r\n                                                <div class=\"input-group\">\r\n                                                    <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" name=\"dateRequired\" [(ngModel)]=\"model.dateRequired\" ngbDatepicker #d=\"ngbDatepicker\">\r\n                                                    <div [hidden]=\"readonly\" class=\"input-group-append\">\r\n                                                        <button class=\"btn btn-sm btn-outline-secondary\" (click)=\"d.toggle()\" type=\"button\">\r\n                              <fa-icon icon=\"calendar-alt\"></fa-icon>\r\n                            </button>\r\n                                                    </div>\r\n                                                </div>\r\n                                            </div>\r\n                                            <div class=\"form-group col-sm-12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"clientName\">\r\n                          <fa-icon icon=\"industry\"></fa-icon> Client\r\n                        </label>\r\n                                                <input [hidden]=\"!readonly\" readonly [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"clientName\" type=\"text\" [(ngModel)]=\"model.clientName\" name=\"clientName\">\r\n                                                <ng-select [hidden]=\"readonly\" [items]=\"clientList\" [typeahead]=\"selectClientInput\" [loading]=\"selectClientPreLoading\" bindLabel=\"company_name\" bindValue=\"company_name\" [(ngModel)]=\"model.clientName\" name=\"clientName\">\r\n                                                </ng-select>\r\n                                            </div>\r\n                                            <div class=\"form-group col-sm12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"clientServiceRepresentative\">\r\n                          <fa-icon icon=\"address-card\"></fa-icon> CS Rep\r\n                        </label>\r\n                                                <input [hidden]=\"!readonly\" readonly [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"clientServiceRepresentative\" type=\"text\" [(ngModel)]=\"model.clientServiceRepresentative\" name=\"clientServiceRepresentative\">\r\n                                                <ng-select [hidden]=\"readonly\" [items]=\"staffList\" [typeahead]=\"selectStaffInput\" [loading]=\"selectStaffPreLoading\" bindLabel=\"userName\" bindValue=\"userName\" [(ngModel)]=\"model.clientServiceRepresentative\" name=\"clientServiceRepresentative\">\r\n                                                </ng-select>\r\n                                            </div>\r\n                                        </div>\r\n                                        <div class=\"form-row\">\r\n                                            <div class=\"form-group col-sm12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"well.name\">\r\n                          <fa-icon icon=\"arrow-circle-down\"></fa-icon> Well Name\r\n                        </label>\r\n                                                <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"well.name\" type=\"text\" [(ngModel)]=\"model.well.name\" name=\"well.name\">\r\n                                            </div>\r\n                                            <div class=\"form-group col-sm-12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"well.downholeLocation\">\r\n                          <fa-icon icon=\"map-marker-alt\"></fa-icon> LSD\r\n                        </label>\r\n                                                <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"well.downholeLocation\" type=\"text\" [(ngModel)]=\"model.well.downholeLocation\" name=\"well.downholeLocation\">\r\n                                            </div>\r\n\r\n                                            <div class=\"form-group col-sm-12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"blend.name\">\r\n                          <fa-icon icon=\"blender\"></fa-icon> Blend Source\r\n                        </label>\r\n                                                <em *ngIf=\"labRequestForm.controls.blendname?.invalid && (labRequestForm.controls.blendname?.touched || mouseoverSave)\">Required</em>\r\n                                                <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"blend.name\" type=\"text\" [(ngModel)]=\"model.blend.name\" name=\"blendname\" required>\r\n                                            </div>\r\n                                            <div class=\"form-group col-sm-12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"jobType\">Job Type</label>\r\n                                                <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"jobType\" type=\"text\" [(ngModel)]=\"model.jobType\" name=\"jobType\">\r\n                                            </div>\r\n                                        </div>\r\n                                        <div class=\"form-row\">\r\n\r\n                                            <div class=\"form-group col-sm-12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"bhct\">BHCT</label>\r\n                                                <em *ngIf=\"labRequestForm.controls.bhct?.invalid && (labRequestForm.controls.bhct?.touched || mouseoverSave)\">Required</em>\r\n                                                <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"bhct\" type=\"number\" [(ngModel)]=\"model.bhct\" name=\"bhct\" required>\r\n                                            </div>\r\n                                            <div class=\"form-group col-sm-12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"bhst\">BHST</label>\r\n                                                <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"bhst\" type=\"number\" [(ngModel)]=\"model.bhst\" name=\"bhst\">\r\n                                            </div>\r\n                                            <div class=\"form-group col-sm-12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"blend.base\">\r\n                          <fa-icon icon=\"blender\"></fa-icon> Blend Base\r\n                        </label>\r\n                                                <em *ngIf=\"labRequestForm.controls.base?.invalid && (labRequestForm.controls.base?.touched || mouseoverSave)\">Required</em>\r\n                                                <input [hidden]=\"!(readonly || notIncludedInEdit)\" class=\"form-control-plaintext\" type=\"text\" [(ngModel)]=\"model.blend.base\" name=\"blend.base\">\r\n                                                <ng-select [hidden]=\"readonly || notIncludedInEdit\" [items]=\"baseBlendList\" [typeahead]=\"selectBaseBlendInput\" [loading]=\"selectBaseBlendPreLoading\" bindLabel=\"name\" bindValue=\"name\" [(ngModel)]=\"model.blend.base\" name=\"base\" required>\r\n                                                </ng-select>\r\n                                            </div>\r\n                                            <div class=\"form-group col-sm-12 col-md-2\">\r\n                                            </div>\r\n                                        </div>\r\n\r\n                                        <div class=\"form-row\">\r\n                                            <div class=\"form-group col-sm-12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"well.pressure\">\r\n                          Pressure\r\n                        </label>\r\n                                                <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"well.pressure\" type=\"number\" [(ngModel)]=\"model.well.pressure\" name=\"well.pressure\">\r\n                                            </div>\r\n                                            <div class=\"form-group col-sm-12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"well.tmd\">\r\n                          TMD\r\n                        </label>\r\n                                                <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"well.tmd\" type=\"numer\" [(ngModel)]=\"model.well.tmd \" name=\"well.tmd\"> </div>\r\n                                            <div class=\"form-group col-sm-12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"well.tvd\">\r\n                          TVD\r\n                        </label>\r\n                                                <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"well.tvd\" type=\"number\" [(ngModel)]=\"model.well.tvd\" name=\"well.tvd\"> </div>\r\n                                        </div>\r\n                                        <div class=\"form-row\">\r\n\r\n                                            <div class=\"form-group col-sm-12 col-md-3\">\r\n                                            </div>\r\n                                        </div>\r\n                                        <div *ngIf=\"!isExperimentalMode\" class=\"form-row\">\r\n                                            <div class=\"form-group col-sm-12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"well.servicePoint\">\r\n                          <fa-icon icon=\"location-arrow\"></fa-icon> District (service point)\r\n                        </label>\r\n                                                <input [hidden]=\"!readonly\" class=\"form-control-plaintext\" type=\"text\" [(ngModel)]=\"model.well.servicePoint\" name=\"well.servicePoint.readonly\">\r\n                                                <ng-select [hidden]=\"readonly\" [items]=\"servicePointList\" [typeahead]=\"selectServicePointInput\" [loading]=\"selectservicePointPreLoading\" bindLabel=\"name\" bindValue=\"name\" [(ngModel)]=\"model.well.servicePoint\" name=\"well.servicePoint\">\r\n                                                </ng-select>\r\n                                            </div>\r\n                                            <div class=\"form-group col-sm12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"technicalServiceRepresentative\">\r\n                          <fa-icon icon=\"address-card\"></fa-icon> TS Rep\r\n                        </label>\r\n                                                <input [hidden]=\"!readonly\" readonly [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"technicalServiceRepresentative\" type=\"text\" [(ngModel)]=\"model.technicalServiceRepresentative\" name=\"technicalServiceRepresentative\">\r\n                                                <ng-select [hidden]=\"readonly\" [items]=\"staffList\" [typeahead]=\"selectStaffInput\" [loading]=\"selectStaffPreLoading\" bindLabel=\"userName\" bindValue=\"userName\" [(ngModel)]=\"model.technicalServiceRepresentative\" name=\"technicalServiceRepresentative\">\r\n                                                </ng-select>\r\n                                            </div>\r\n                                            <div class=\"form-group col-sm-12 col-md-3\">\r\n                                                <div class=\"row\">\r\n                                                    <div class=\"col-3\">\r\n                                                        <label [hidden]=\"!readonly\" class=\"switch switch-label switch-success small ml-1\" onclick=\"return false;\">\r\n                              <input class=\"switch-input\" type=\"checkbox\" [(ngModel)]=\"model.loadAndGo\" (change)=\"makeReadOnly('specificGravity')\" name=\"loadAndGo\">\r\n                              <span class=\"switch-slider\" data-checked=\"Yes\" data-unchecked=\"No\"></span>\r\n                            </label>\r\n                                                        <label [hidden]=\"readonly\" class=\"switch switch-label switch-success small ml-1\">\r\n                              <input class=\"switch-input\" type=\"checkbox\" [(ngModel)]=\"model.loadAndGo\" name=\"loadAndGo\">\r\n                              <span class=\"switch-slider\" data-checked=\"Yes\" data-unchecked=\"No\"></span>\r\n                            </label>\r\n                                                    </div>\r\n                                                    <div class=\"col-9\">\r\n                                                        <label class=\"small font-weight-bold\">Land and Go</label>\r\n                                                    </div>\r\n                                                </div>\r\n                                            </div>\r\n                                            <div class=\"form-group col-sm-12 col-md-3\">\r\n                                                <div class=\"row\">\r\n                                                    <div class=\"col-3\">\r\n                                                        <label [hidden]=\"!readonly\" class=\"switch switch-label switch-success small ml-1\" onclick=\"return false;\">\r\n                              <input class=\"switch-input\" type=\"checkbox\" [(ngModel)]=\"model.opr\" (change)=\"makeReadOnly('opr')\" name=\"opr\">\r\n                              <span class=\"switch-slider\" data-checked=\"Yes\" data-unchecked=\"No\"></span>\r\n                            </label>\r\n                                                        <label [hidden]=\"readonly\" class=\"switch switch-label switch-success small ml-1\">\r\n                              <input class=\"switch-input\" type=\"checkbox\" [(ngModel)]=\"model.opr\" name=\"opr\">\r\n                              <span class=\"switch-slider\" data-checked=\"Yes\" data-unchecked=\"No\"></span>\r\n                            </label>\r\n                                                    </div>\r\n                                                    <div class=\"col-9\">\r\n                                                        <label class=\"small font-weight-bold\">One Page Report</label>\r\n                                                    </div>\r\n                                                </div>\r\n                                            </div>\r\n                                        </div>\r\n                                    </form>\r\n                                </ng-template>\r\n                            </ngb-tab>\r\n                            <ngb-tab [id]=\"1\">\r\n                                <ng-template ngbTabTitle><span class=\"text-primary\">\r\n                    <fa-icon icon=\"vials\"></fa-icon> Test Iterations\r\n                  </span></ng-template>\r\n                                <ng-template ngbTabContent>\r\n                                    <form #iterationForm=\"ngForm\" autocomplete=\"off\">\r\n                                        <div class=\"row\">\r\n                                            <div class=\"col-12\">\r\n                                                <div [hidden]=\"!iterationEdit\" class=\"btn-toolbar float-right mb-2\" role=\"toolbar\" aria-label=\"Toolbar\">\r\n                                                    <div class=\"dropdown\">\r\n                                                        <button [disabled]=\"downloadChartStatus\" class=\"btn btn-sm btn-outline-primary dropdown-toggle\" type=\"button\" id=\"dropdownMenuButton\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">\r\n                              <fa-icon [hidden]=\"downloadChartStatus\" icon=\"download\"></fa-icon>\r\n                              <fa-icon [hidden]=\"!downloadChartStatus\" icon=\"circle-notch\" [spin]=\"true\">\r\n                              </fa-icon>\r\n                              Download Chart Creator\r\n                            </button>\r\n                                                        <div class=\"dropdown-menu\" aria-labelledby=\"dropdownMenuButton\">\r\n                                                            <button *ngFor=\"let template of templates\" class=\"dropdown-item\" (click)=\"downloadChart(template.labTestType)\"> {{ titleCaseToStatement(template.name) }} </button>\r\n                                                        </div>\r\n                                                    </div>\r\n                                                    <button type=\"button\" [disabled]=\"isDownloading\" class=\"btn btn-sm btn-outline-primary ml-1\" (click)=\"download()\">\r\n                            <fa-icon [hidden]=\"isDownloading\" icon=\"download\"></fa-icon>\r\n                            <fa-icon [hidden]=\"!isDownloading\" icon=\"circle-notch\" [spin]=\"true\"></fa-icon> Download WSC\r\n                          </button>\r\n                                                    <button *ngIf=\"isInRole(['admin', 'Lab_Team', 'Lab_Manager'])\" type=\"button\" class=\"btn btn-sm btn-outline-primary ml-1\" (click)=\"editIteration()\">\r\n                            <fa-icon icon=\"edit\"></fa-icon> Edit\r\n                          </button>\r\n                                                    <button *ngIf=\"isInRole(['admin', 'Lab_Team', 'Lab_Manager'])\" type=\"button\" class=\"btn btn-sm btn-outline-primary ml-1\" (click)=\"cloneIteration()\">\r\n                            <fa-icon icon=\"copy\"></fa-icon> Clone\r\n                          </button>\r\n                                                </div>\r\n                                                <div [hidden]=\"iterationEdit\" class=\"btn-toolbar float-right mb-2\" role=\"toolbar\" aria-label=\"Toolbar\">\r\n                                                    <span (mouseenter)=\"mouseoverSave=true\" (mouseleave)=\"mouseoverSave=false\">\r\n                            <button [disabled]=\"iterationForm.invalid\" [hidden]=\"!newrequest\"  type=\"button\" class=\"btn btn-sm  btn-success ml-1\" (click)=\"save()\">\r\n                              <fa-icon icon=\"save\"></fa-icon> Save\r\n                            </button>\r\n                            <button [disabled]=\"iterationForm.invalid\" [hidden]=\"newrequest\" type=\"button\" class=\"btn btn-sm  btn-success ml-1\" (click)=\"saveIteration()\">\r\n                              <fa-icon icon=\"save\"></fa-icon> Save\r\n                            </button></span>\r\n                                                    <button type=\"button\" class=\"btn btn-sm btn-outline-primary ml-1\" (click)=\"cancelEditIteration()\">\r\n                            <fa-icon icon=\"times-circle\"></fa-icon> Cancel\r\n                          </button>\r\n                                                </div>\r\n                                            </div>\r\n                                        </div>\r\n                                        <div class=\"row\">\r\n                                            <div class=\"col-2\">\r\n                                                <div class=\"list-group list-group-flush\" id=\"list-tab\">\r\n                                                    <button *ngFor=\"let iteration of model.iterations\" class=\"list-group-item list-group-item-action\" [ngClass]=\"{'active': model.version === iteration.version}\" [id]=\"'iteration-master' + iteration\" href=\"#\" role=\"tab\" aria-controls=\"home\" (click)=\"loadIteration(iteration.version)\">\r\n                            <fa-icon icon=\"code-branch\" class=\"float-right\"></fa-icon>iteration {{iteration.version}}\r\n                          </button>\r\n                                                </div>\r\n                                            </div>\r\n                                            <div class=\"col-10\">\r\n                                                <div class=\"card\">\r\n                                                    <div class=\"card-body\">\r\n                                                        <div class=\"form-row\">\r\n                                                            <div class=\"col-sm-6 col-md-2 col-form-label font-weight-bold\">\r\n                                                                <span class=\"font-weight-bold mt-1\">Target Density:</span>\r\n                                                            </div>\r\n                                                            <div class=\"col-sm-6 col-md-2\">\r\n                                                                <em *ngIf=\"iterationForm.controls.density?.invalid && (iterationForm.controls.density?.touched || mouseoverSave)\">Required</em>\r\n                                                                <input [readonly]=\"iterationReadonly\" [ngClass]=\"iterationReadonly ? 'form-control-plaintext' : 'form-control'\" id=\"density\" type=\"text\" [(ngModel)]=\"model.density\" name=\"density\" required>\r\n                                                            </div>\r\n                                                            <div class=\"form-group col-sm-6 col-md-2 col-form-label\">\r\n                                                                <span class=\"font-weight-bold  mt-1\">SG Slurry:</span>\r\n                                                            </div>\r\n                                                            <div class=\"form-group col-sm-6 col-md-2\">\r\n                                                                <label [hidden]=\"!iterationReadonly\" class=\"switch switch-label switch-success small ml-1 float-right\" onclick=\"return false;\">\r\n                                  <input class=\"switch-input\" type=\"checkbox\" [(ngModel)]=\"model.sgSlurry\" (change)=\"makeReadOnly('sgSlurry')\" name=\"sgSlurry\">\r\n                                  <span class=\"switch-slider\" data-checked=\"Yes\" data-unchecked=\"No\"></span>\r\n                                </label>\r\n                                                                <label [hidden]=\"iterationReadonly\" class=\"switch switch-label switch-success small ml-1 float-right\">\r\n                                  <input class=\"switch-input\" type=\"checkbox\" [(ngModel)]=\"model.sgSlurry\" name=\"sgSlurry\">\r\n                                  <span class=\"switch-slider\" data-checked=\"Yes\" data-unchecked=\"No\"></span>\r\n                                </label>\r\n                                                            </div>\r\n                                                            <div class=\"form-group col-sm-12 col-md-4 col-form-label\">\r\n                                                                <span class=\"font-weight-bold mt-1\">SG Powder:</span>\r\n                                                            </div>\r\n                                                        </div>\r\n                                                        <div class=\"form-row\">\r\n                                                            <label for=\"staticEmail\" class=\"col-sm-6 col-md-2 col-form-label font-weight-bold\">Salt:</label>\r\n                                                            <div class=\"col-sm-6 col-md-2\">\r\n                                                                <input [hidden]=\"!iterationReadonly\" readonly=\"true\" class=\"form-control-plaintext\" id=\"salt\" type=\"text\" [(ngModel)]=\"model.salt\" name=\"salt\">\r\n                                                                <ng-select [hidden]=\"iterationReadonly\" [items]=\"saltList\" [(ngModel)]=\"model.salt\" name=\"salt\">\r\n                                                                </ng-select>\r\n                                                            </div>\r\n                                                            <div class=\"form-group col-sm-12 col-md-4 col-form-label\">\r\n                                                                <span class=\"font-weight-bold mt-1\">Salt Concentration:</span>\r\n                                                                <input class=\"switch switch-label switch-success ml-1 float-right text-right\" [readonly]=\"iterationReadonly\" [ngClass]=\"iterationReadonly ? 'form-control-plaintext' : 'form-control'\" id=\"saltConcentration\" type=\"text\" [(ngModel)]=\"model.saltConcentration\"\r\n                                                                    name=\"saltConcentration\">\r\n                                                            </div>\r\n                                                        </div>\r\n                                                        <div class=\"form-row mb-2\">\r\n                                                            <label for=\"cementSource\" class=\"col-sm-6 col-md-2 col-form-label font-weight-bold\">Cement Source:</label>\r\n                                                            <div class=\"col-sm-6 col-md-2\">\r\n                                                                <em *ngIf=\"iterationForm.controls.cementSource?.invalid && (iterationForm.controls.cementSource?.touched || mouseoverSave)\">Required</em>\r\n\r\n                                                                <input [hidden]=\"!iterationEdit\" class=\"form-control-plaintext\" type=\"text\" [(ngModel)]=\"model.cementSource\" name=\"cementSource\">\r\n\r\n                                                                <ng-select [hidden]=\"iterationEdit\" [items]=\"cementTypeList\" [(ngModel)]=\"model.cementSource\" name=\"cementSource\" required>\r\n                                                                </ng-select>\r\n                                                            </div>\r\n                                                            <div class=\"col-sm-6 col-md-2 col-form-label\">\r\n                                                                <span class=\"font-weight-bold mt-1\">Cement Login #:</span>\r\n                                                            </div>\r\n                                                            <div class=\"col-sm-6 col-md-2\">\r\n                                                                <input class=\"text-right\" [hidden]=\"!iterationEdit\" readonly [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"cementLoginNo\" type=\"text\" [(ngModel)]=\"model.cementLoginNo\" name=\"cementLoginNo\">\r\n                                                                <ng-select [hidden]=\"iterationEdit\" [items]=\"loginList\" [(ngModel)]=\"model.cementLoginNo\" name=\"cementLoginNo\">\r\n                                                                </ng-select>\r\n                                                            </div>\r\n                                                        </div>\r\n                                                        <div class=\"form-row\">\r\n                                                            <label for=\"staticEmail\" class=\"col-sm-6 col-md-2 col-form-label font-weight-bold\">Water Source:</label>\r\n                                                            <div class=\"col-sm-6 col-md-2\">\r\n                                                                <input [hidden]=\"!iterationEdit\" class=\"form-control-plaintext\" type=\"text\" [(ngModel)]=\"model.mixWater\" name=\"mixWater.readonly\">\r\n                                                                <ng-select [hidden]=\"iterationEdit\" [items]=\"waterTypeList\" [(ngModel)]=\"model.mixWater\" name=\"mixWater\">\r\n                                                                </ng-select>\r\n                                                            </div>\r\n                                                            <div class=\"col-sm-6 col-md-2 col-form-label\">\r\n                                                                <span class=\"font-weight-bold mt-1\">Water Login #:</span>\r\n                                                            </div>\r\n                                                            <div class=\"col-sm-6 col-md-2\">\r\n                                                                <input class=\"text-right\" [hidden]=\"!iterationEdit\" readonly [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"cementLoginNo\" type=\"text\" [(ngModel)]=\"model.waterLoginNo\" name=\"waterLoginNo\">\r\n                                                                <ng-select [hidden]=\"iterationEdit\" [items]=\"loginList\" bindLabel=\"loginNo\" bindValue=\"loginNo\" [(ngModel)]=\"model.waterLoginNo\" name=\"waterLoginNo\">\r\n                                                                </ng-select>\r\n                                                            </div>\r\n                                                        </div>\r\n\r\n                                                    </div>\r\n                                                </div>\r\n                                                <div class=\"card-deck\">\r\n                                                    <div class=\"card\">\r\n                                                        <div class=\"card-header\">Additives</div>\r\n                                                        <ul class=\"list-group list-group-flush\">\r\n                                                            <li class=\"list-group-item\">\r\n                                                                <div class=\"row\">\r\n                                                                    <div [hidden]=\"iterationReadonly\" class=\"col-{{colSize[0]}}\"></div>\r\n                                                                    <div class=\"col-{{colSize[1]}}\">\r\n                                                                        <span class=\"font-weight-bold\">Name</span></div>\r\n                                                                    <div class=\"col-{{colSize[2]}}\">\r\n                                                                        <span class=\"font-weight-bold\">Concentration</span></div>\r\n                                                                    <div [hidden]=\"!isExperimentalMode\" class=\"col-{{colSize[3]}}\">\r\n                                                                        <span class=\"font-weight-bold float-right\">Base</span></div>\r\n                                                                </div>\r\n                                                            </li>\r\n                                                            <li class=\"list-group-item\" *ngFor=\"let additive of model.blend.additives; let idx = index\">\r\n                                                                <div class=\"row\">\r\n                                                                    <div [hidden]=\"iterationReadonly\" class=\"col-{{colSize[0]}}\">\r\n                                                                        <button type=\"button\" class=\"btn btn-sm btn-danger\" (click)=\"removeAdditive(idx)\">\r\n                                      <fa-icon icon=\"minus\"></fa-icon>\r\n                                    </button>\r\n                                                                    </div>\r\n                                                                    <div class=\"col-{{colSize[1]}}\">\r\n                                                                        <input [hidden]=\"!iterationReadonly\" [readonly]=\"iterationReadonly\" class=\"form-control-plaintext\" [id]=\"'additive_name_' + idx\" type=\"text\" [(ngModel)]=\"additive.name\" [name]=\"'additive_name_' + idx\">\r\n                                                                        <ng-select [hidden]=\"iterationReadonly\" [items]=\"additiveList\" [typeahead]=\"selectAdditiveInput\" bindLabel=\"name\" bindValue=\"name\" [(ngModel)]=\"additive.name\" [name]=\"'additive.name' + idx\">\r\n                                                                        </ng-select>\r\n                                                                    </div>\r\n                                                                    <div class=\"col-{{colSize[2]}}\">\r\n                                                                        <input [readonly]=\"iterationReadonly\" [ngClass]=\"iterationReadonly ? 'form-control-plaintext' : 'form-control'\" [id]=\"'concentration_' + idx\" type=\"number\" [(ngModel)]=\"additive.concentration\" [name]=\"'concentration_' + idx\">\r\n                                                                    </div>\r\n                                                                    <div [hidden]=\"!isExperimentalMode\" class=\"col-{{colSize[3]}}\">\r\n                                                                        <label [hidden]=\"!iterationReadonly\" class=\"switch switch-label switch-success small ml-1 float-right\" onclick=\"return false;\">\r\n                                                                            <input class=\"switch-input\" type=\"checkbox\" [(ngModel)]=\"additive.blendBase\" (change)=\"toggleBlendbase('blendBase')\" [name]=\"'blendBase_' + idx\">\r\n                                                                            <span class=\"switch-slider\" data-checked=\"Yes\" data-unchecked=\"No\"></span>\r\n                                                                          </label>\r\n                                                                        <label [hidden]=\"iterationReadonly\" class=\"switch switch-label switch-success small ml-1\">\r\n                                                                            <input class=\"switch-input\" type=\"checkbox\" [(ngModel)]=\"additive.blendBase\" [name]=\"'blendBase_' + idx\">\r\n                                                                            <span class=\"switch-slider\" data-checked=\"Yes\" data-unchecked=\"No\"></span>\r\n                                                                          </label>\r\n                                                                    </div>\r\n                                                                </div>\r\n                                                            </li>\r\n                                                            <li [hidden]=\"iterationReadonly\" class=\"list-group-item\">\r\n                                                                <button type=\"button\" class=\"btn btn-sm btn-success\" (click)=\"addAdditive()\">\r\n                                  <fa-icon icon=\"plus\"></fa-icon>\r\n                                </button>\r\n                                                            </li>\r\n                                                        </ul>\r\n                                                    </div>\r\n                                                    <div class=\"card\">\r\n                                                        <div class=\"card-header\">Tests</div>\r\n                                                        <ul class=\"list-group list-group-flush\">\r\n                                                            <li [hidden]=\"!iterationReadonly\" class=\"list-group-item\" *ngFor=\"let test of model.tests; let idx = index\">\r\n                                                                <span class=\"font-weight-bold\">{{ test.type }}</span>\r\n\r\n                                                                <hr>\r\n                                                                <div class=\"row\" *ngFor=\"let parameter of test.parameters\">\r\n                                                                    <div class=\"col-12 small\"><span class=\"font-weight-bold\">{{ parameter.key }}:</span> {{ parameter.type === 'YesNo' ? ( parameter.value ? 'Yes' : 'No' ) : parameter.value }} </div>\r\n                                                                </div>\r\n                                                            </li>\r\n                                                            <li [hidden]=\"iterationReadonly\" class=\"list-group-item\" *ngFor=\"let test of model.tests; let idx = index\">\r\n\r\n                                                                <div class=\"row\">\r\n                                                                    <div class=\"col-2\">\r\n                                                                        <button type=\"button\" class=\"btn btn-sm btn-danger\" (click)=\"removeTest(idx)\">\r\n                                      <fa-icon icon=\"minus\"></fa-icon>\r\n                                    </button>\r\n                                                                    </div>\r\n                                                                    <div class=\"col-10\">\r\n                                                                        <ng-select [items]=\"testTypeList\" [(ngModel)]=\"test.type\" [name]=\"'type' + idx\" (ngModelChange)=\"displayParam(test.type)\">\r\n                                                                        </ng-select>\r\n                                                                    </div>\r\n                                                                </div>\r\n\r\n                                                                <div class=\"row\" *ngFor=\"let parameter of test.parameters; let idx2 = index\">\r\n                                                                    <div class=\"col-12 small\"><span class=\"font-weight-bold\">{{ parameter.key }}:</span>\r\n                                                                        <div *ngIf=\"parameter.type === 'YesNo'\">\r\n                                                                            <label class=\"switch switch-label switch-success small ml-1\">\r\n                                                                                <input class=\"switch-input\"  [id]=\"'parameter_' + idx + idx2\" type=\"checkbox\" [(ngModel)]=\"parameter.value\" (ngModelChange)=\"onYesNoChanged(idx, idx2, $event)\" [name]=\"'parameter_' + idx + idx2\">\r\n                                                                                <span class=\"switch-slider\" data-checked=\"Yes\" data-unchecked=\"No\"></span>\r\n                                                                              </label>\r\n                                                                        </div>\r\n                                                                        <div *ngIf=\"parameter.type !== 'YesNo'\">\r\n                                                                            <input [readonly]=\"parameter.readonly\" class=\"form-control form-control-sm\" [id]=\"'parameter_' + idx + idx2\" type=\"text\" [(ngModel)]=\"parameter.value\" [name]=\"'parameter_' + idx + idx2\"></div>\r\n\r\n                                                                    </div>\r\n                                                                </div>\r\n                                                            </li>\r\n                                                            <li *ngIf=\"!iterationReadonly && testTypeList.length !== 0\" class=\"list-group-item\">\r\n                                                                <button type=\"button\" class=\"btn btn-sm btn-success\" (click)=\"addTest()\">\r\n                                  <fa-icon icon=\"plus\"></fa-icon>\r\n                                </button>\r\n                                                            </li>\r\n                                                        </ul>\r\n                                                    </div>\r\n                                                </div>\r\n                                                <div class=\"card mt-2\">\r\n                                                    <div class=\"card-header\">\r\n                                                        <fa-icon icon=\"comment\"></fa-icon> Comments\r\n                                                    </div>\r\n                                                    <div class=\"card-body\">\r\n                                                        <textarea [readonly]=\"iterationEdit\" [ngClass]=\"iterationReadonly ? 'form-control-plaintext' : 'form-control'\" id=\"comment\" type=\"textbox\" [(ngModel)]=\"model.comment\" name=\"comment\" class=\"commentTextArea\"></textarea>\r\n                                                    </div>\r\n                                                </div>\r\n                                            </div>\r\n                                        </div>\r\n                                    </form>\r\n                                </ng-template>\r\n                            </ngb-tab>\r\n                            <ngb-tab [id]=\"2\" *ngIf=\"!newrequest\">\r\n                                <ng-template ngbTabTitle><span class=\"text-primary\">\r\n                    <fa-icon icon=\"poll\"></fa-icon> Test Results\r\n                  </span></ng-template>\r\n                                <ng-template ngbTabContent>\r\n                                    <div class=\"row\">\r\n                                        <div class=\"col-2\">\r\n                                            <div class=\"list-group list-group-flush\" id=\"list-tab\">\r\n                                                <button *ngFor=\"let iteration of model.iterations\" class=\"list-group-item list-group-item-action\" [ngClass]=\"{'active': model.version === iteration.version}\" [id]=\"'iteration-master' + iteration\" href=\"#\" role=\"tab\" aria-controls=\"home\" (click)=\"loadIteration(iteration.version)\">\r\n                          <fa-icon icon=\"code-branch\" class=\"float-right\"></fa-icon>iteration {{iteration.version}}\r\n                        </button>\r\n                                            </div>\r\n\r\n                                        </div>\r\n                                        <div class=\"col-10\">\r\n                                            <app-result-detail [iterationId]=\"model.iterationId\" [blendName]=\"model.blend.base\"></app-result-detail>\r\n                                        </div>\r\n                                    </div>\r\n                                </ng-template>\r\n                            </ngb-tab>\r\n                        </ngb-tabset>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>"

/***/ }),

/***/ "./src/app/lab-request/components/lab-request-detail/lab-request-detail.component.scss":
/*!*********************************************************************************************!*\
  !*** ./src/app/lab-request/components/lab-request-detail/lab-request-detail.component.scss ***!
  \*********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".commentTextArea {\n  min-height: 400px; }\n\n.keep-in-line {\n  float: none !important;\n  display: inline-block !important; }\n\nem {\n  float: right;\n  color: #E05C65;\n  padding-left: 10px; }\n\n.error input {\n  background-color: #E3C3C5; }\n\n.error ::-webkit-input-placeholder {\n  color: #999; }\n\n.error ::-moz-placeholder {\n  color: #999; }\n\n.error :-moz-placeholder {\n  color: #999; }\n\n.error :-ms-input-placeholder {\n  color: #999; }\n\n.form-wdith {\n  width: 100%; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbGFiLXJlcXVlc3QvY29tcG9uZW50cy9sYWItcmVxdWVzdC1kZXRhaWwvRTpcXGZyb250ZW5kMS9zcmNcXGFwcFxcbGFiLXJlcXVlc3RcXGNvbXBvbmVudHNcXGxhYi1yZXF1ZXN0LWRldGFpbFxcbGFiLXJlcXVlc3QtZGV0YWlsLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksaUJBQWlCLEVBQUE7O0FBR3JCO0VBQ0ksc0JBQXNCO0VBQ3RCLGdDQUFnQyxFQUFBOztBQUdwQztFQUNJLFlBQVk7RUFDWixjQUFjO0VBQ2Qsa0JBQWtCLEVBQUE7O0FBR3RCO0VBQ0kseUJBQXlCLEVBQUE7O0FBRzdCO0VBQ0ksV0FBVyxFQUFBOztBQUdmO0VBQ0ksV0FBVyxFQUFBOztBQUdmO0VBQ0ksV0FBVyxFQUFBOztBQUdmO0VBQ0ksV0FBVyxFQUFBOztBQUdmO0VBQ0ksV0FBVyxFQUFBIiwiZmlsZSI6InNyYy9hcHAvbGFiLXJlcXVlc3QvY29tcG9uZW50cy9sYWItcmVxdWVzdC1kZXRhaWwvbGFiLXJlcXVlc3QtZGV0YWlsLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNvbW1lbnRUZXh0QXJlYSB7XHJcbiAgICBtaW4taGVpZ2h0OiA0MDBweDtcclxufVxyXG5cclxuLmtlZXAtaW4tbGluZSB7XHJcbiAgICBmbG9hdDogbm9uZSAhaW1wb3J0YW50O1xyXG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmVtIHtcclxuICAgIGZsb2F0OiByaWdodDtcclxuICAgIGNvbG9yOiAjRTA1QzY1O1xyXG4gICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xyXG59XHJcblxyXG4uZXJyb3IgaW5wdXQge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0UzQzNDNTtcclxufVxyXG5cclxuLmVycm9yIDo6LXdlYmtpdC1pbnB1dC1wbGFjZWhvbGRlciB7XHJcbiAgICBjb2xvcjogIzk5OTtcclxufVxyXG5cclxuLmVycm9yIDo6LW1vei1wbGFjZWhvbGRlciB7XHJcbiAgICBjb2xvcjogIzk5OTtcclxufVxyXG5cclxuLmVycm9yIDotbW96LXBsYWNlaG9sZGVyIHtcclxuICAgIGNvbG9yOiAjOTk5O1xyXG59XHJcblxyXG4uZXJyb3IgOi1tcy1pbnB1dC1wbGFjZWhvbGRlciB7XHJcbiAgICBjb2xvcjogIzk5OTtcclxufVxyXG5cclxuLmZvcm0td2RpdGgge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbn0iXX0= */"

/***/ }),

/***/ "./src/app/lab-request/components/lab-request-detail/lab-request-detail.component.ts":
/*!*******************************************************************************************!*\
  !*** ./src/app/lab-request/components/lab-request-detail/lab-request-detail.component.ts ***!
  \*******************************************************************************************/
/*! exports provided: LabRequestDetailComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LabRequestDetailComponent", function() { return LabRequestDetailComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _services_lab_request_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/lab-request.service */ "./src/app/lab-request/services/lab-request.service.ts");
/* harmony import */ var _models_lab_request__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../models/lab-request */ "./src/app/lab-request/models/lab-request.ts");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var src_app_master_data_services_base_blend_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/master-data/services/base-blend.service */ "./src/app/master-data/services/base-blend.service.ts");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _models_additive__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../models/additive */ "./src/app/lab-request/models/additive.ts");
/* harmony import */ var src_app_master_data_services_additive_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/master-data/services/additive.service */ "./src/app/master-data/services/additive.service.ts");
/* harmony import */ var src_app_master_data_services_service_point_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/master-data/services/service-point.service */ "./src/app/master-data/services/service-point.service.ts");
/* harmony import */ var src_app_master_data_services_lookup_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/master-data/services/lookup.service */ "./src/app/master-data/services/lookup.service.ts");
/* harmony import */ var _models_test_parameter__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../models/test-parameter */ "./src/app/lab-request/models/test-parameter.ts");
/* harmony import */ var _models_lab_test__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../models/lab-test */ "./src/app/lab-request/models/lab-test.ts");
/* harmony import */ var src_app_master_data_services_lab_test_spec_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/master-data/services/lab-test-spec.service */ "./src/app/master-data/services/lab-test-spec.service.ts");
/* harmony import */ var src_app_core_utils_file_download_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! src/app/core/utils/file-download.service */ "./src/app/core/utils/file-download.service.ts");
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ngx-toastr */ "./node_modules/ngx-toastr/fesm5/ngx-toastr.js");
/* harmony import */ var _models_iteration_create_request__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../models/iteration-create-request */ "./src/app/lab-request/models/iteration-create-request.ts");
/* harmony import */ var src_app_lab_result_services_lab_result_service__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! src/app/lab-result/services/lab-result.service */ "./src/app/lab-result/services/lab-result.service.ts");
/* harmony import */ var _models_well__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../../models/well */ "./src/app/lab-request/models/well.ts");
/* harmony import */ var _models_blend__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../../models/blend */ "./src/app/lab-request/models/blend.ts");
/* harmony import */ var src_app_lab_sample_services_lab_sample_service__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! src/app/lab-sample/services/lab-sample.service */ "./src/app/lab-sample/services/lab-sample.service.ts");
/* harmony import */ var src_app_user_services_user_service__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! src/app/user/services/user.service */ "./src/app/user/services/user.service.ts");
/* harmony import */ var src_app_core_security_authentication_service__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! src/app/core/security/authentication.service */ "./src/app/core/security/authentication.service.ts");
/* harmony import */ var src_app_core_security_role_enum__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! src/app/core/security/role.enum */ "./src/app/core/security/role.enum.ts");
/* harmony import */ var src_app_core_utils_library_service__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! src/app/core/utils/library.service */ "./src/app/core/utils/library.service.ts");



























var LabRequestDetailComponent = /** @class */ (function () {
    function LabRequestDetailComponent(route, labRequestService, baseBlendService, additiveService, userService, servicePointService, lookupService, labTestSpecService, fileDownloadService, toastrService, labResultService, labSampleService, libraryService, authenticationService, router) {
        this.route = route;
        this.labRequestService = labRequestService;
        this.baseBlendService = baseBlendService;
        this.additiveService = additiveService;
        this.userService = userService;
        this.servicePointService = servicePointService;
        this.lookupService = lookupService;
        this.labTestSpecService = labTestSpecService;
        this.fileDownloadService = fileDownloadService;
        this.toastrService = toastrService;
        this.labResultService = labResultService;
        this.labSampleService = labSampleService;
        this.libraryService = libraryService;
        this.authenticationService = authenticationService;
        this.router = router;
        this.readonly = true;
        this.notIncludedInEdit = true;
        this.iterationReadonly = true;
        this.iterationEdit = true;
        this.editCurrentIteration = true;
        this.statusChange = false;
        this.isDownloading = false;
        this.isMaster = true;
        this.newrequest = false;
        this.selectedVersion = 1;
        this.selectBaseBlendPreLoading = false;
        this.selectservicePointPreLoading = false;
        this.selectClientPreLoading = false;
        this.selectLoginPreLoading = false;
        this.selectStaffPreLoading = false;
        this.downloadDisabled = false;
        this.baseBlendList = [];
        this.additiveList = [];
        this.clientList = [];
        this.staffList = [];
        this.servicePointList = [];
        this.waterTypeList = [];
        this.cementTypeList = [];
        this.testTypeList = [];
        this.templates = [];
        this.testTypeListFull = [];
        this.selectBaseBlendInput = new rxjs__WEBPACK_IMPORTED_MODULE_7__["Subject"]();
        this.selectAdditiveInput = new rxjs__WEBPACK_IMPORTED_MODULE_7__["Subject"]();
        this.selectServicePointInput = new rxjs__WEBPACK_IMPORTED_MODULE_7__["Subject"]();
        this.selectClientInput = new rxjs__WEBPACK_IMPORTED_MODULE_7__["Subject"]();
        this.selectStaffInput = new rxjs__WEBPACK_IMPORTED_MODULE_7__["Subject"]();
        this.selectLoginInput = new rxjs__WEBPACK_IMPORTED_MODULE_7__["Subject"]();
        this.testConfig = {};
        this.downloadChartStatus = false;
        this.saltList = ['', 'NaCl', 'KCl'];
        this.typeString = { 1: 'TT', 2: 'UCA', 4: 'RH', 8: 'SGSA', 128: 'WA' };
        this.stateList = ['New', 'InProgress', 'Completed', 'Cancelled'];
        this.currentModelStatus = '';
        this.isExperimentalMode = false;
        this.colSize = [];
    }
    LabRequestDetailComponent.prototype.ngOnInit = function () {
        var _this = this;
        var url = this.router.url;
        this.sub = this.route.queryParamMap
            .subscribe(function (params) {
            _this.tab = +params.get('tab') || 0;
            _this.selectedVersion = +params.get('version') || 1;
        });
        if (url.startsWith('/experimental/new')) {
            this.isExperimentalMode = true;
            this.prepareNewRequest();
        }
        else if (url.startsWith('/lab-requests/new')) {
            this.isExperimentalMode = false;
            this.prepareNewRequest();
        }
        else if (url.startsWith('/experimental/view')) {
            this.isExperimentalMode = true;
            this.getLabRequestId();
            this.getRequest(this.selectedVersion);
        }
        else if (url.startsWith('/lab-requests/view')) {
            this.isExperimentalMode = false;
            this.getLabRequestId();
            this.getRequest(this.selectedVersion);
        }
        else {
            throw new Error('Not sure how you got here!');
        }
        this.initList();
        this.selectBaseBlendInput.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["debounceTime"])(500), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["distinctUntilChanged"])()).subscribe(function (term) {
            _this.selectBaseBlendPreLoading = true;
            _this.lookupBaseBlend(term);
        });
        this.selectAdditiveInput.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["debounceTime"])(500), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["distinctUntilChanged"])()).subscribe(function (term) {
            _this.lookupAdditive(term);
        });
        this.selectServicePointInput.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["debounceTime"])(500), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["distinctUntilChanged"])()).subscribe(function (term) {
            _this.selectservicePointPreLoading = true;
            _this.lookupServicePoint(term);
        });
        this.selectClientInput.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["debounceTime"])(500), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["distinctUntilChanged"])()).subscribe(function (term) {
            _this.selectClientPreLoading = true;
            _this.lookupClient(term);
        });
        this.selectStaffInput.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["debounceTime"])(500), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_8__["distinctUntilChanged"])()).subscribe(function (user) {
            _this.selectStaffPreLoading = true;
            _this.lookupStaff(user);
        });
        this.labSampleService.getLoginList().subscribe(function (response) {
            _this.loginList = response;
        });
    };
    LabRequestDetailComponent.prototype.not = function (state) {
        return !state;
    };
    LabRequestDetailComponent.prototype.getLabRequestId = function () {
        var _this = this;
        this.sub = this.route.params.subscribe(function (params) {
            if (params['id']) {
                _this.id = params['id'];
            }
        });
    };
    LabRequestDetailComponent.prototype.prepareNewRequest = function () {
        this.model = new _models_lab_request__WEBPACK_IMPORTED_MODULE_4__["LabRequest"]();
        this.model.well = new _models_well__WEBPACK_IMPORTED_MODULE_20__["Well"]('', '', '', '', 0, 0, 0);
        this.model.blend = new _models_blend__WEBPACK_IMPORTED_MODULE_21__["Blend"]('', '', []);
        this.model.tests = [];
        this.readonly = false;
        this.notIncludedInEdit = false;
        this.iterationReadonly = false;
        this.newrequest = true;
        this.iterationEdit = this.iterationReadonly && true;
        this.currentModelStatus = 'new';
        this.setRequestType();
        this.setStateAndPostionForAddictives();
    };
    LabRequestDetailComponent.prototype.setStateAndPostionForAddictives = function () {
        for (var i = 0; i < 4; i++) {
            this.colSize[i] = this.setControlSize(i);
        }
    };
    LabRequestDetailComponent.prototype.ngOnDestroy = function () {
        this.sub.unsubscribe();
    };
    LabRequestDetailComponent.prototype.setControlSize = function (position) {
        var size = 0;
        if (this.isExperimentalMode) {
            if (this.iterationReadonly) {
                size = [0, 6, 4, 2][position];
            }
            else {
                size = [1, 5, 4, 2][position];
            }
        }
        else {
            if (this.iterationReadonly) {
                size = [0, 6, 6, 0][position];
            }
            else {
                size = [1, 5, 6, 0][position];
            }
        }
        return size;
    };
    LabRequestDetailComponent.prototype.getRequest = function (versionId) {
        var _this = this;
        this.labRequestService
            .getById(this.id, versionId).subscribe(function (response) {
            _this.model = response;
            _this.currentModelStatus = _this.model.status;
            _this.setStateAndPostionForAddictives();
            _this.setReadonlyState(_this.model.tests);
        });
    };
    LabRequestDetailComponent.prototype.setReadonlyState = function (tests) {
        var skip = 3;
        tests.forEach(function (t) {
            if (t.type === 'ThickeningTime') {
                t.parameters.forEach(function (p) {
                    p.readonly = p.type === 'YesNo' ? p.value : !p.value;
                });
            }
            else if (t.type === 'StaticGelStrengthAnalyzers') {
                t.parameters.forEach(function (p) {
                    if (skip === 0) {
                        p.readonly = p.type === 'YesNo' ? p.value : !p.value;
                    }
                    skip--;
                });
            }
        });
    };
    LabRequestDetailComponent.prototype.createIteration = function () {
        var _this = this;
        this.labRequestService
            .createIteration(this.model.id, new _models_iteration_create_request__WEBPACK_IMPORTED_MODULE_18__["IterationCreateRequest"](this.model.mixWater, this.model.waterLoginNo, this.model.cementSource, this.model.cementLoginNo, this.model.tests, this.model.blend.additives, this.model.density, this.model.sgPowder, this.model.sgSlurry, this.model.comment, this.model.salt, this.model.saltConcentration)).subscribe(function (success) {
            return _this.getRequest(success.versionId);
        });
    };
    LabRequestDetailComponent.prototype.updateIteration = function () {
        var _this = this;
        this.labRequestService
            .updateIteration(this.model.id, this.model.version, new _models_iteration_create_request__WEBPACK_IMPORTED_MODULE_18__["IterationCreateRequest"](this.model.mixWater, this.model.waterLoginNo, this.model.cementSource, this.model.cementLoginNo, this.model.tests, this.model.blend.additives, this.model.density, this.model.sgPowder, this.model.sgSlurry, this.model.comment, this.model.salt, this.model.saltConcentration)).subscribe(function (success) {
            return _this.getRequest(_this.model.version);
        });
    };
    LabRequestDetailComponent.prototype.makeReadOnly = function () {
        this.model.specificGravity = false;
    };
    LabRequestDetailComponent.prototype.toggleBlendbase = function (id) {
    };
    LabRequestDetailComponent.prototype.setRequestType = function () {
        this.model.type = !this.isExperimentalMode ? 'BlendTest' : 'ExperimentalTest';
        this.setStateAndPostionForAddictives();
    };
    LabRequestDetailComponent.prototype.lookupBaseBlend = function (term) {
        var _this = this;
        this.baseBlendService.lookup(term)
            .subscribe(function (response) {
            _this.selectBaseBlendPreLoading = false;
            _this.baseBlendList = response;
        });
    };
    LabRequestDetailComponent.prototype.lookupAdditive = function (term) {
        var _this = this;
        this.additiveService.lookup(term)
            .subscribe(function (response) {
            _this.additiveList = response;
        });
    };
    LabRequestDetailComponent.prototype.lookupServicePoint = function (term) {
        var _this = this;
        this.servicePointService.lookupDistrict(term)
            .subscribe(function (response) {
            _this.selectservicePointPreLoading = false;
            _this.servicePointList = response;
        });
    };
    LabRequestDetailComponent.prototype.lookupClient = function (term) {
        var _this = this;
        this.servicePointService.lookupClient(term)
            .subscribe(function (response) {
            _this.selectClientPreLoading = false;
            _this.clientList = response;
        });
    };
    LabRequestDetailComponent.prototype.lookupStaff = function (user) {
        var _this = this;
        this.userService.search(user)
            .subscribe(function (response) {
            _this.selectStaffPreLoading = false;
            _this.staffList = response;
        });
    };
    LabRequestDetailComponent.prototype.initList = function () {
        var _this = this;
        this.lookupService.getCementSourceList().subscribe(function (response) {
            _this.cementTypeList = response;
        });
        this.lookupService.getLabTestTypeList().subscribe(function (response) {
            _this.testTypeListFull = response;
            _this.testTypeList = response;
        });
        this.lookupService.getMixWaterList().subscribe(function (response) {
            _this.waterTypeList = response;
        });
        this.labTestSpecService.getList().subscribe(function (response) {
            _this.testConfig = response;
        });
        this.labResultService.GetTemplates().subscribe(function (response) {
            _this.templates = response;
        });
    };
    LabRequestDetailComponent.prototype.setTypeList = function () {
        var _this = this;
        this.testTypeList = this.testTypeListFull.filter(function (item) { return !_this.model.tests.some(function (x) { return x.type === item; }); });
    };
    LabRequestDetailComponent.prototype.edit = function () {
        this.readonly = false;
        this.notIncludedInEdit = true;
    };
    LabRequestDetailComponent.prototype.save = function () {
        var _this = this;
        this.readonly = true;
        if (this.newrequest) {
            this.labRequestService.save(this.model).subscribe(function (response) {
                _this.model = response;
                _this.id = _this.model.id;
                _this.iterationReadonly = true;
                _this.iterationEdit = true;
                _this.newrequest = false;
                _this.toastrService.success('Request saved successfully.');
            });
        }
        else {
            this.labRequestService.update(this.model.businessId, this.model).subscribe(function () {
                _this.toastrService.success('Request successfully updated.');
            });
        }
    };
    LabRequestDetailComponent.prototype.cancel = function () {
        this.readonly = true;
        if (!this.newrequest) {
            this.getRequest(this.model.version);
        }
        else {
            this.router.navigate(['/lab-requests']);
        }
    };
    LabRequestDetailComponent.prototype.addAdditive = function () {
        this.model.blend.additives.push(new _models_additive__WEBPACK_IMPORTED_MODULE_9__["Additive"]('', 0, false));
    };
    LabRequestDetailComponent.prototype.removeAdditive = function (index) {
        this.model.blend.additives.splice(index, 1);
    };
    LabRequestDetailComponent.prototype.removeTest = function (index) {
        this.model.tests.splice(index, 1);
        this.setTypeList();
    };
    LabRequestDetailComponent.prototype.addTest = function () {
        this.model.tests.push(new _models_lab_test__WEBPACK_IMPORTED_MODULE_14__["LabTest"]('', []));
        this.setTypeList();
    };
    LabRequestDetailComponent.prototype.displayParam = function (testType) {
        this.setTypeList();
        var index = this.model.tests.find(function (i) { return i.type === testType; });
        index.parameters = [];
        for (var i = 0; i < this.testConfig[testType].length; i++) {
            var item = this.testConfig[testType][i]['key'];
            var type = this.testConfig[testType][i]['value'];
            if (type === 'YesNo') {
                index.parameters.push(new _models_test_parameter__WEBPACK_IMPORTED_MODULE_13__["TestParameter"](item, type, false));
            }
            else {
                index.parameters.push(new _models_test_parameter__WEBPACK_IMPORTED_MODULE_13__["TestParameter"](item, type, ''));
            }
        }
        this.setReadonlyState(this.model.tests);
    };
    /**
     * Download the worksheet for the current version of the request.
     */
    LabRequestDetailComponent.prototype.download = function () {
        var _this = this;
        this.isDownloading = true;
        this.labRequestService.downloadWSC(this.model.id, this.model.version).subscribe(function (success) {
            _this.fileDownloadService
                .emulateDownload(success, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', "WSC_" + _this.model.businessId + "-V" + _this.model.version + ".xlsm");
            _this.isDownloading = false;
        }, function () {
            _this.toastrService.error('Server error while downloading file.');
            _this.isDownloading = false;
        });
    };
    /**
     * Downloads a chart worksheet for the current request version.
     * @param type - the test type
     */
    LabRequestDetailComponent.prototype.downloadChart = function (type) {
        var _this = this;
        this.downloadChartStatus = true;
        this.labRequestService.downloadChart(this.model.id, this.model.version, type).subscribe(function (success) {
            _this.fileDownloadService
                .emulateDownload(success, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', "Chart" + _this.typeString[type] + "_" + _this.model.businessId + "-V" + _this.model.version + ".xlsx");
            _this.downloadChartStatus = false;
        }, function () {
            _this.toastrService.error('Server error while downloading file.');
            _this.downloadChartStatus = false;
        });
    };
    LabRequestDetailComponent.prototype.toggleState = function () {
        if (this.isInRole([src_app_core_security_role_enum__WEBPACK_IMPORTED_MODULE_25__["Role"].ADMIN, src_app_core_security_role_enum__WEBPACK_IMPORTED_MODULE_25__["Role"].LABTEAM, src_app_core_security_role_enum__WEBPACK_IMPORTED_MODULE_25__["Role"].LABMANAGER])) {
            this.statusChange = !this.statusChange;
        }
    };
    LabRequestDetailComponent.prototype.onStateChanged = function () {
        var _this = this;
        if (this.model.status === null) {
            this.model.status = this.currentModelStatus;
        }
        else {
            this.labRequestService.update(this.model.businessId, this.model).subscribe(function (_) { }, function (err) {
                _this.toastrService.error("Status not updated. " + err);
            });
            this.currentModelStatus = this.model.status;
        }
        this.statusChange = !this.statusChange;
    };
    LabRequestDetailComponent.prototype.cloneIteration = function () {
        this.iterationReadonly = false;
        this.iterationEdit = this.iterationReadonly && false;
        this.setStateAndPostionForAddictives();
    };
    LabRequestDetailComponent.prototype.editIteration = function () {
        this.iterationReadonly = true;
        this.iterationEdit = this.iterationReadonly && false;
        this.editCurrentIteration = true;
        this.setStateAndPostionForAddictives();
    };
    LabRequestDetailComponent.prototype.cancelEditIteration = function () {
        this.iterationReadonly = true;
        this.iterationEdit = true;
        this.editCurrentIteration = false;
        if (!this.newrequest) {
            this.getRequest(this.model.version);
        }
        else {
            this.router.navigate(['/lab-requests']);
        }
    };
    LabRequestDetailComponent.prototype.nextTab = function () {
        this.tab++;
    };
    LabRequestDetailComponent.prototype.saveIteration = function () {
        if (this.editCurrentIteration) {
            this.updateIteration();
            this.editCurrentIteration = false;
        }
        else {
            this.createIteration();
        }
        this.iterationReadonly = true;
        this.iterationEdit = true;
    };
    LabRequestDetailComponent.prototype.loadIteration = function (id) {
        this.getRequest(id);
    };
    LabRequestDetailComponent.prototype.isAdmin = function () {
        return this.isInRole(['admin']);
    };
    LabRequestDetailComponent.prototype.isInRole = function (role) {
        return this.authenticationService.hasRole(role);
    };
    LabRequestDetailComponent.prototype.titleCaseToStatement = function (strValue) {
        return this.libraryService.titleCaseToStatement(strValue);
    };
    LabRequestDetailComponent.prototype.onYesNoChanged = function (testIdx, paramIdx, state) {
        if (this.model.tests[testIdx].type === 'ThickeningTime') {
            this.model.tests[testIdx].parameters[paramIdx + 1].readonly = !state;
            this.model.tests[testIdx].parameters[paramIdx + 2].readonly = !state;
            if (!state) {
                this.model.tests[testIdx].parameters[paramIdx + 1].value = '';
                this.model.tests[testIdx].parameters[paramIdx + 2].value = '';
            }
        }
        else if (this.model.tests[testIdx].type === 'StaticGelStrengthAnalyzers') {
            this.model.tests[testIdx].parameters[paramIdx + 1].readonly = !state;
            if (!state) {
                this.model.tests[testIdx].parameters[paramIdx + 1].value = '';
            }
        }
    };
    LabRequestDetailComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-lab-request-detail',
            template: __webpack_require__(/*! ./lab-request-detail.component.html */ "./src/app/lab-request/components/lab-request-detail/lab-request-detail.component.html"),
            providers: [{ provide: _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__["NgbDateAdapter"], useClass: _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__["NgbDateNativeAdapter"] }],
            styles: [__webpack_require__(/*! ./lab-request-detail.component.scss */ "./src/app/lab-request/components/lab-request-detail/lab-request-detail.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
            _services_lab_request_service__WEBPACK_IMPORTED_MODULE_3__["LabRequestService"],
            src_app_master_data_services_base_blend_service__WEBPACK_IMPORTED_MODULE_6__["BaseBlendService"],
            src_app_master_data_services_additive_service__WEBPACK_IMPORTED_MODULE_10__["AdditiveService"],
            src_app_user_services_user_service__WEBPACK_IMPORTED_MODULE_23__["UserService"],
            src_app_master_data_services_service_point_service__WEBPACK_IMPORTED_MODULE_11__["ServicePointService"],
            src_app_master_data_services_lookup_service__WEBPACK_IMPORTED_MODULE_12__["LookupService"],
            src_app_master_data_services_lab_test_spec_service__WEBPACK_IMPORTED_MODULE_15__["LabTestSpecService"],
            src_app_core_utils_file_download_service__WEBPACK_IMPORTED_MODULE_16__["FileDownloadService"],
            ngx_toastr__WEBPACK_IMPORTED_MODULE_17__["ToastrService"],
            src_app_lab_result_services_lab_result_service__WEBPACK_IMPORTED_MODULE_19__["LabResultService"],
            src_app_lab_sample_services_lab_sample_service__WEBPACK_IMPORTED_MODULE_22__["LabSampleService"],
            src_app_core_utils_library_service__WEBPACK_IMPORTED_MODULE_26__["LibraryService"],
            src_app_core_security_authentication_service__WEBPACK_IMPORTED_MODULE_24__["AuthenticationService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], LabRequestDetailComponent);
    return LabRequestDetailComponent;
}());



/***/ }),

/***/ "./src/app/lab-request/components/lab-request-list/lab-request-list.component.html":
/*!*****************************************************************************************!*\
  !*** ./src/app/lab-request/components/lab-request-list/lab-request-list.component.html ***!
  \*****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">\r\n    <div class=\"col-12\">\r\n        <div class=\"card\">\r\n            <div class=\"card-header\">\r\n                <fa-icon icon=\"vial\"></fa-icon> Lab Request<a *ngIf=\"isExperimentalMode && isInRole(['admin', 'Lab_Team', 'Lab_Manager'])\" class=\"btn btn-primary float-right\" [routerLink]=\"['/experimental/new']\" role=\"button\">New Request</a><a *ngIf=\"!isExperimentalMode && isInRole(['admin', 'Lab_Team', 'Lab_Manager'])\"\r\n                    class=\"btn btn-primary float-right\" [routerLink]=\"['/lab-requests/new']\" role=\"button\">New Request</a>\r\n            </div>\r\n            <div class=\"card-body\">\r\n                <div style=\"position: relative; top: 150px\">\r\n                    <ngx-ui-loader [loaderId]=\"'grid-loader'\"></ngx-ui-loader>\r\n                </div>\r\n                <ngx-datatable class=\"bootstrap\" [rows]=\"tableState.data\" [loadingIndicator]=\"tableState.loading\" [columnMode]=\"'force'\" [rowHeight]=\"'auto'\" [summaryRow]=\"true\" [summaryPosition]=\"'bottom'\" [footerHeight]=\"40\" [externalPaging]=\"true\" [externalSorting]=\"true\"\r\n                    [count]=\"tableState.count\" [offset]=\"tableState.page - 1\" [limit]=\"tableState.limit\" (page)='setPage($event)' (sort)=\"onSort($event)\">\r\n\r\n                    <ngx-datatable-column name=\"Request Id\" prop=\"id\" [width]=\"70\">\r\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\r\n                            <span class=\"datatable-header-cell-wrapper\">\r\n                <span class=\"datatable-header-cell-label draggable\" (click)=\"sort(column.prop)\" [ngClass]=\"{'font-weight-bold': tableState.orderBy === column.prop}\">{{ column.name }}</span>\r\n                            <fa-icon [icon]=\"tableState.orderDirection === 'asc' ? 'sort-up' : 'sort-down'\" class=\"float-right\" *ngIf=\"tableState.orderBy === column.prop\"></fa-icon>\r\n                            <input [ngbTypeahead]=\"columnSearch(column.prop)\" type=\"text\" class=\"form-control form-control-sm\" name=\"\" id=\"\" aria-describedby=\"helpId\" placeholder=\"\">\r\n                            </span>\r\n                        </ng-template>\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            <a [hidden]=\"!isExperimentalMode\" class=\"text-primary small\" [routerLink]=\"[ '/experimental/view/' + value ]\">\r\n                {{value}}\r\n              </a>\r\n                            <a [hidden]=\"isExperimentalMode\" class=\"text-primary small\" [routerLink]=\"[ '/lab-requests/view/' + value ]\">\r\n                {{value}}\r\n              </a>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"Blend\" prop=\"blendBase\">\r\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\r\n                            <span class=\"datatable-header-cell-wrapper\">\r\n                <span class=\"datatable-header-cell-label draggable\" (click)=\"sort(column.prop)\" [ngClass]=\"{'font-weight-bold': tableState.orderBy === column.prop}\">{{ column.name }}</span>\r\n                            <fa-icon [icon]=\"tableState.orderDirection === 'asc' ? 'sort-up' : 'sort-down'\" class=\"float-right\" *ngIf=\"tableState.orderBy === column.prop\"></fa-icon>\r\n                            <input [ngbTypeahead]=\"columnSearch(column.prop)\" type=\"text\" class=\"form-control form-control-sm\" name=\"\" id=\"\" aria-describedby=\"helpId\" placeholder=\"\">\r\n                            </span>\r\n                        </ng-template>\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            <span class=\"small\">{{ value }}</span>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"Client Name\" prop=\"clientName\">\r\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\r\n                            <span class=\"datatable-header-cell-wrapper\">\r\n                <span class=\"datatable-header-cell-label draggable\" (click)=\"sort(column.prop)\" [ngClass]=\"{'font-weight-bold': tableState.orderBy === column.prop}\">{{ column.name }}</span>\r\n                            <fa-icon [icon]=\"tableState.orderDirection === 'asc' ? 'sort-up' : 'sort-down'\" class=\"float-right\" *ngIf=\"tableState.orderBy === column.prop\"></fa-icon>\r\n                            <input [ngbTypeahead]=\"columnSearch(column.prop)\" type=\"text\" class=\"form-control form-control-sm\" name=\"\" id=\"\" aria-describedby=\"helpId\" placeholder=\"\">\r\n                            </span>\r\n                        </ng-template>\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            <span class=\"small\">{{ value }}</span>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"Program No\" prop=\"programNumber\" [width]=\"50\">\r\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\r\n                            <span class=\"datatable-header-cell-wrapper\">\r\n                <span class=\"datatable-header-cell-label draggable\" (click)=\"sort(column.prop)\" [ngClass]=\"{'font-weight-bold': tableState.orderBy === column.prop}\">{{ column.name }}</span>\r\n                            <fa-icon [icon]=\"tableState.orderDirection === 'asc' ? 'sort-up' : 'sort-down'\" class=\"float-right\" *ngIf=\"tableState.orderBy === column.prop\"></fa-icon>\r\n                            <input [ngbTypeahead]=\"columnSearch(column.prop)\" type=\"text\" class=\"form-control form-control-sm\" name=\"\" id=\"\" aria-describedby=\"helpId\" placeholder=\"\">\r\n                            </span>\r\n                        </ng-template>\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            <span class=\"small\">{{ value }}</span>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"Requested On\" prop=\"createdDate\" [width]=\"60\">\r\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\r\n                            <span class=\"datatable-header-cell-wrapper\">\r\n                <span class=\"datatable-header-cell-label draggable\" (click)=\"sort(column.prop)\" [ngClass]=\"{'font-weight-bold': tableState.orderBy === column.prop}\">{{ column.name }}</span>\r\n                            <fa-icon [icon]=\"tableState.orderDirection === 'asc' ? 'sort-up' : 'sort-down'\" class=\"float-right\" *ngIf=\"tableState.orderBy === column.prop\"></fa-icon>\r\n                            </span>\r\n                        </ng-template>\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            <span class=\"small\">{{ value | date }}</span>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"Date Required\" prop=\"dateRequired\" [width]=\"60\">\r\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\r\n                            <span class=\"datatable-header-cell-wrapper\">\r\n                <span class=\"datatable-header-cell-label draggable\" (click)=\"sort(column.prop)\" [ngClass]=\"{'font-weight-bold': tableState.orderBy === column.prop}\">{{ column.name }}</span>\r\n                            <fa-icon [icon]=\"tableState.orderDirection === 'asc' ? 'sort-up' : 'sort-down'\" class=\"float-right\" *ngIf=\"tableState.orderBy === column.prop\"></fa-icon>\r\n                            </span>\r\n                        </ng-template>\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            <span class=\"small\">{{ value | date }}</span>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"Requested By\" prop=\"createdBy\" [width]=\"60\">\r\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\r\n                            <span class=\"datatable-header-cell-wrapper\">\r\n                <span class=\"datatable-header-cell-label draggable\" (click)=\"sort(column.prop)\" [ngClass]=\"{'font-weight-bold': tableState.orderBy === column.prop}\">{{ column.name }}</span>\r\n                            <fa-icon [icon]=\"tableState.orderDirection === 'asc' ? 'sort-up' : 'sort-down'\" class=\"float-right\" *ngIf=\"tableState.orderBy === column.prop\"></fa-icon>\r\n                            <input [ngbTypeahead]=\"columnSearch(column.prop)\" type=\"text\" class=\"form-control form-control-sm\" name=\"\" id=\"\" aria-describedby=\"helpId\" placeholder=\"\">\r\n                            </span>\r\n                            <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                                <span class=\"small\">{{ value }}</span>\r\n                            </ng-template>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"status\" [width]=\"35\">\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            <span class=\"badge\" [ngClass]=\"{'badge-warning': value === 'New', 'badge-info': value === 'InProgress', 'badge-success': value === 'Completed', 'badge-danger': value === 'Cancelled'}\">{{value}}</span>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                </ngx-datatable>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>"

/***/ }),

/***/ "./src/app/lab-request/components/lab-request-list/lab-request-list.component.scss":
/*!*****************************************************************************************!*\
  !*** ./src/app/lab-request/components/lab-request-list/lab-request-list.component.scss ***!
  \*****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2xhYi1yZXF1ZXN0L2NvbXBvbmVudHMvbGFiLXJlcXVlc3QtbGlzdC9sYWItcmVxdWVzdC1saXN0LmNvbXBvbmVudC5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/lab-request/components/lab-request-list/lab-request-list.component.ts":
/*!***************************************************************************************!*\
  !*** ./src/app/lab-request/components/lab-request-list/lab-request-list.component.ts ***!
  \***************************************************************************************/
/*! exports provided: LabRequestListComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LabRequestListComponent", function() { return LabRequestListComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_lab_request_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/lab-request.service */ "./src/app/lab-request/services/lab-request.service.ts");
/* harmony import */ var src_app_core_datatable_table_state__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/datatable/table-state */ "./src/app/core/datatable/table-state.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var ngx_ui_loader__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ngx-ui-loader */ "./node_modules/ngx-ui-loader/fesm5/ngx-ui-loader.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var src_app_core_security_authentication_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/security/authentication.service */ "./src/app/core/security/authentication.service.ts");








var LabRequestListComponent = /** @class */ (function () {
    function LabRequestListComponent(route, labRequestService, ngxService, router, authenticationService) {
        this.route = route;
        this.labRequestService = labRequestService;
        this.ngxService = ngxService;
        this.router = router;
        this.authenticationService = authenticationService;
        this.isExperimentalMode = false;
        this.tableState = new src_app_core_datatable_table_state__WEBPACK_IMPORTED_MODULE_3__["TableState"]();
    }
    LabRequestListComponent.prototype.ngOnInit = function () {
        this.isExperimentalMode = this.router.url === '/experimental';
        if (this.isExperimentalMode) {
            this.getLabRequestsExp();
        }
        else {
            this.getLabRequests();
        }
    };
    LabRequestListComponent.prototype.getLabRequests = function () {
        var _this = this;
        this.ngxService.startLoader('grid-loader');
        this.labRequestService.getLabRequests(this.isExperimentalMode, this.tableState.page, this.tableState.limit, this.tableState.filters, this.tableState.orderBy, this.tableState.orderDirection).subscribe(function (response) {
            _this.tableState.attachResponse(response);
            _this.ngxService.stopLoader('grid-loader');
        });
    };
    LabRequestListComponent.prototype.getLabRequestsExp = function () {
        var _this = this;
        this.ngxService.startLoader('grid-loader');
        this.labRequestService.getLabRequestsExp(this.tableState.page, this.tableState.limit, this.tableState.filters, this.tableState.orderBy, this.tableState.orderDirection).subscribe(function (response) {
            _this.tableState.attachResponse(response);
            _this.ngxService.stopLoader('grid-loader');
        });
    };
    LabRequestListComponent.prototype.setPage = function (pageInfo) {
        this.tableState.page = pageInfo.offset + 1;
        this.getLabRequests();
    };
    LabRequestListComponent.prototype.onSort = function (event) {
        this.tableState.setOrdering(event.column.prop);
        this.getLabRequests();
    };
    LabRequestListComponent.prototype.sort = function (columnName) {
        this.tableState.setOrdering(columnName);
        this.getLabRequests();
    };
    LabRequestListComponent.prototype.showMe = function (row) {
    };
    LabRequestListComponent.prototype.columnSearch = function (columName$) {
        var _this = this;
        // Create a function that considers the specified $index parameter value
        var func = function (text$) {
            return text$.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["debounceTime"])(300), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["distinctUntilChanged"])(), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(function (term) {
                _this.tableState.setFilter(columName$, term);
                _this.getLabRequests();
            }));
        };
        return func;
    };
    LabRequestListComponent.prototype.isAdmin = function () {
        return this.isInRole(['admin']);
    };
    LabRequestListComponent.prototype.isInRole = function (role) {
        return this.authenticationService.hasRole(role);
    };
    LabRequestListComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-lab-request-list',
            template: __webpack_require__(/*! ./lab-request-list.component.html */ "./src/app/lab-request/components/lab-request-list/lab-request-list.component.html"),
            styles: [__webpack_require__(/*! ./lab-request-list.component.scss */ "./src/app/lab-request/components/lab-request-list/lab-request-list.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_6__["ActivatedRoute"],
            _services_lab_request_service__WEBPACK_IMPORTED_MODULE_2__["LabRequestService"],
            ngx_ui_loader__WEBPACK_IMPORTED_MODULE_5__["NgxUiLoaderService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"],
            src_app_core_security_authentication_service__WEBPACK_IMPORTED_MODULE_7__["AuthenticationService"]])
    ], LabRequestListComponent);
    return LabRequestListComponent;
}());



/***/ }),

/***/ "./src/app/lab-request/components/result-detail/result-detail.component.html":
/*!***********************************************************************************!*\
  !*** ./src/app/lab-request/components/result-detail/result-detail.component.html ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div *ngIf=\"results\">\r\n    <div *ngFor=\"let result of results.results\" class=\"row\">\r\n        <div class=\"col-12\">\r\n            <div class=\"card\">\r\n                <div class=\"card-header\">\r\n                    {{ titleCaseToStatement(result.testType) }} Results - {{ blendName }}\r\n                </div>\r\n                <div class=\"card-body\">\r\n                    <div class=\"row\">\r\n                        <div class=\"col-6\">\r\n                            <dl class=\"row\">\r\n                                <dt class=\"col-sm-3\">Date:</dt>\r\n                                <dd class=\"col-sm-9\">{{ result.date | date }}</dd>\r\n                                <dt class=\"col-sm-3\">Instrument:</dt>\r\n                                <dd class=\"col-sm-9\">{{ result.instrumentId }}</dd>\r\n                                <dt class=\"col-sm-3\">Schedule</dt>\r\n                                <dd class=\"col-sm-9\">{{ result.schedule }}</dd>\r\n                                <dt class=\"col-sm-3\">Result file</dt>\r\n                                <dd class=\"col-sm-9\">\r\n                                    <button type=\"button\" class=\"btn btn-link\" (click)=\"download(result.resultFileInfo)\">{{ result.resultFileInfo.name }}</button>\r\n                                </dd>\r\n                            </dl>\r\n                        </div>\r\n                        <div class=\"col-6\">\r\n                            <div *ngFor=\"let groups of result.resultOutputs\">\r\n                                <table class=\"table table-responsive-sm table-hover table-outline mb-0\">\r\n                                    <thead class=\"thead-light\">\r\n                                        <tr>\r\n                                            <th class=\"text-center\">\r\n                                                Label\r\n                                            </th>\r\n                                            <th class=\"text-center\">\r\n                                                Value\r\n                                            </th>\r\n                                        </tr>\r\n                                    </thead>\r\n                                    <tbody>\r\n                                        <tr *ngFor=\"let item of groups\">\r\n                                            <td>\r\n                                                <span class=\"font-weight-bold\">{{ item.label }}</span>\r\n                                            </td>\r\n                                            <td class=\"text-center\">\r\n                                                {{ timeConvert(item.value, item.unit) }} {{ item.unit }}\r\n                                            </td>\r\n                                        </tr>\r\n                                    </tbody>\r\n                                </table>\r\n                                <div class=\"col-xs-12\" style=\"height:50px;\"></div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>"

/***/ }),

/***/ "./src/app/lab-request/components/result-detail/result-detail.component.scss":
/*!***********************************************************************************!*\
  !*** ./src/app/lab-request/components/result-detail/result-detail.component.scss ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2xhYi1yZXF1ZXN0L2NvbXBvbmVudHMvcmVzdWx0LWRldGFpbC9yZXN1bHQtZGV0YWlsLmNvbXBvbmVudC5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/lab-request/components/result-detail/result-detail.component.ts":
/*!*********************************************************************************!*\
  !*** ./src/app/lab-request/components/result-detail/result-detail.component.ts ***!
  \*********************************************************************************/
/*! exports provided: ResultDetailComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ResultDetailComponent", function() { return ResultDetailComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_lab_result_services_lab_result_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/lab-result/services/lab-result.service */ "./src/app/lab-result/services/lab-result.service.ts");
/* harmony import */ var src_app_core_utils_file_download_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/utils/file-download.service */ "./src/app/core/utils/file-download.service.ts");
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ngx-toastr */ "./node_modules/ngx-toastr/fesm5/ngx-toastr.js");
/* harmony import */ var src_app_core_utils_library_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/utils/library.service */ "./src/app/core/utils/library.service.ts");






var ResultDetailComponent = /** @class */ (function () {
    function ResultDetailComponent(labResultService, fileDownloadService, libraryService, toastrService) {
        this.labResultService = labResultService;
        this.fileDownloadService = fileDownloadService;
        this.libraryService = libraryService;
        this.toastrService = toastrService;
        this.hasResult = false;
    }
    Object.defineProperty(ResultDetailComponent.prototype, "iterationId", {
        set: function (iterationId) {
            this.getResults(iterationId);
        },
        enumerable: true,
        configurable: true
    });
    ResultDetailComponent.prototype.ngOnInit = function () {
    };
    ResultDetailComponent.prototype.getResults = function (iterationId) {
        var _this = this;
        this.labResultService.GetResults(iterationId).subscribe(function (success) {
            _this.results = success;
            _this.hasResult = true;
        });
    };
    /**
   * Download the worksheet for the current version of the request.
   */
    ResultDetailComponent.prototype.download = function (fileInfo) {
        var _this = this;
        this.labResultService.downloadFileResult(fileInfo.id).subscribe(function (success) {
            _this.fileDownloadService
                .emulateDownload(success, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', fileInfo.name);
        }, function (err) {
            _this.toastrService.error('Server error while downloading file.');
        });
    };
    ResultDetailComponent.prototype.timeConvert = function (tm, unit) {
        if (unit === 'minutes') {
            var rhours = Math.floor(tm / 60);
            var rminutes = Math.round((tm / 60 - rhours) * 60);
            return rhours + ':' + rminutes;
        }
        else {
            return tm;
        }
    };
    ResultDetailComponent.prototype.titleCaseToStatement = function (strValue) {
        return this.libraryService.titleCaseToStatement(strValue);
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], ResultDetailComponent.prototype, "blendName", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [String])
    ], ResultDetailComponent.prototype, "iterationId", null);
    ResultDetailComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-result-detail',
            template: __webpack_require__(/*! ./result-detail.component.html */ "./src/app/lab-request/components/result-detail/result-detail.component.html"),
            styles: [__webpack_require__(/*! ./result-detail.component.scss */ "./src/app/lab-request/components/result-detail/result-detail.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_lab_result_services_lab_result_service__WEBPACK_IMPORTED_MODULE_2__["LabResultService"],
            src_app_core_utils_file_download_service__WEBPACK_IMPORTED_MODULE_3__["FileDownloadService"],
            src_app_core_utils_library_service__WEBPACK_IMPORTED_MODULE_5__["LibraryService"],
            ngx_toastr__WEBPACK_IMPORTED_MODULE_4__["ToastrService"]])
    ], ResultDetailComponent);
    return ResultDetailComponent;
}());



/***/ }),

/***/ "./src/app/lab-request/lab-request-routing.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/lab-request/lab-request-routing.module.ts ***!
  \***********************************************************/
/*! exports provided: LabRequestRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LabRequestRoutingModule", function() { return LabRequestRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _components_lab_request_list_lab_request_list_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/lab-request-list/lab-request-list.component */ "./src/app/lab-request/components/lab-request-list/lab-request-list.component.ts");
/* harmony import */ var _components_lab_request_detail_lab_request_detail_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/lab-request-detail/lab-request-detail.component */ "./src/app/lab-request/components/lab-request-detail/lab-request-detail.component.ts");





var routes = [
    {
        path: '',
        component: _components_lab_request_list_lab_request_list_component__WEBPACK_IMPORTED_MODULE_3__["LabRequestListComponent"]
    },
    {
        path: 'view/:id',
        component: _components_lab_request_detail_lab_request_detail_component__WEBPACK_IMPORTED_MODULE_4__["LabRequestDetailComponent"]
    },
    {
        path: 'new',
        component: _components_lab_request_detail_lab_request_detail_component__WEBPACK_IMPORTED_MODULE_4__["LabRequestDetailComponent"]
    }
];
var LabRequestRoutingModule = /** @class */ (function () {
    function LabRequestRoutingModule() {
    }
    LabRequestRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], LabRequestRoutingModule);
    return LabRequestRoutingModule;
}());



/***/ }),

/***/ "./src/app/lab-request/lab-request.module.ts":
/*!***************************************************!*\
  !*** ./src/app/lab-request/lab-request.module.ts ***!
  \***************************************************/
/*! exports provided: LabRequestModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LabRequestModule", function() { return LabRequestModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _lab_request_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./lab-request-routing.module */ "./src/app/lab-request/lab-request-routing.module.ts");
/* harmony import */ var _components_lab_request_list_lab_request_list_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/lab-request-list/lab-request-list.component */ "./src/app/lab-request/components/lab-request-list/lab-request-list.component.ts");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @swimlane/ngx-datatable */ "./node_modules/@swimlane/ngx-datatable/release/index.js");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _fortawesome_angular_fontawesome__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @fortawesome/angular-fontawesome */ "./node_modules/@fortawesome/angular-fontawesome/fesm5/angular-fontawesome.js");
/* harmony import */ var _fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @fortawesome/fontawesome-svg-core */ "./node_modules/@fortawesome/fontawesome-svg-core/index.es.js");
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @fortawesome/free-solid-svg-icons */ "./node_modules/@fortawesome/free-solid-svg-icons/index.es.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var ngx_ui_loader__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ngx-ui-loader */ "./node_modules/ngx-ui-loader/fesm5/ngx-ui-loader.js");
/* harmony import */ var _components_lab_request_detail_lab_request_detail_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./components/lab-request-detail/lab-request-detail.component */ "./src/app/lab-request/components/lab-request-detail/lab-request-detail.component.ts");
/* harmony import */ var _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ng-select/ng-select */ "./node_modules/@ng-select/ng-select/fesm5/ng-select.js");
/* harmony import */ var _components_result_detail_result_detail_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./components/result-detail/result-detail.component */ "./src/app/lab-request/components/result-detail/result-detail.component.ts");















var LabRequestModule = /** @class */ (function () {
    function LabRequestModule() {
        _fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_7__["library"].add(_fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faVial"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faSortUp"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faSortDown"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faCalendarAlt"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faBlender"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faHashtag"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faIndustry"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faAddressCard"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faLocationArrow"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faMapMarkerAlt"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faArrowCircleDown"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faInfoCircle"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faVials"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faComment"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faAngleRight"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faArrowCircleLeft"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faDownload"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faCopy"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faCircleNotch"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faEdit"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faTimesCircle"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faSave"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faPlus"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faMinus"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faCodeBranch"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faStar"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faPoll"]);
    }
    LabRequestModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_components_lab_request_list_lab_request_list_component__WEBPACK_IMPORTED_MODULE_4__["LabRequestListComponent"], _components_lab_request_detail_lab_request_detail_component__WEBPACK_IMPORTED_MODULE_12__["LabRequestDetailComponent"], _components_result_detail_result_detail_component__WEBPACK_IMPORTED_MODULE_14__["ResultDetailComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_10__["FormsModule"],
                _lab_request_routing_module__WEBPACK_IMPORTED_MODULE_3__["LabRequestRoutingModule"],
                _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_5__["NgxDatatableModule"],
                _fortawesome_angular_fontawesome__WEBPACK_IMPORTED_MODULE_6__["FontAwesomeModule"],
                _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_9__["NgbModule"],
                ngx_ui_loader__WEBPACK_IMPORTED_MODULE_11__["NgxUiLoaderModule"],
                _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_13__["NgSelectModule"]
            ]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], LabRequestModule);
    return LabRequestModule;
}());



/***/ }),

/***/ "./src/app/lab-request/models/additive.ts":
/*!************************************************!*\
  !*** ./src/app/lab-request/models/additive.ts ***!
  \************************************************/
/*! exports provided: Additive */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Additive", function() { return Additive; });
var Additive = /** @class */ (function () {
    function Additive(name, concentration, blendBase) {
        if (blendBase === void 0) { blendBase = false; }
        this.name = name;
        this.concentration = concentration;
        this.blendBase = blendBase;
    }
    return Additive;
}());



/***/ }),

/***/ "./src/app/lab-request/models/blend.ts":
/*!*********************************************!*\
  !*** ./src/app/lab-request/models/blend.ts ***!
  \*********************************************/
/*! exports provided: Blend */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Blend", function() { return Blend; });
var Blend = /** @class */ (function () {
    function Blend(name, base, additives) {
        this.name = name;
        this.base = base;
        this.additives = additives;
    }
    return Blend;
}());



/***/ }),

/***/ "./src/app/lab-request/models/iteration-create-request.ts":
/*!****************************************************************!*\
  !*** ./src/app/lab-request/models/iteration-create-request.ts ***!
  \****************************************************************/
/*! exports provided: IterationCreateRequest */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IterationCreateRequest", function() { return IterationCreateRequest; });
var IterationCreateRequest = /** @class */ (function () {
    function IterationCreateRequest(mixWater, waterLoginNo, cementSource, cementLoginNo, tests, additives, density, sGPowder, sGSlurry, comment, salt, saltConcentration) {
        this.tests = tests;
        this.mixWater = mixWater,
            this.waterLoginNo = waterLoginNo,
            this.cementLoginNo = cementLoginNo,
            this.cementSource = cementSource,
            this.additives = additives;
        this.density = density;
        this.sGPowder = sGPowder;
        this.sGSlurry = sGSlurry;
        this.comment = comment;
        this.salt = salt;
        this.saltConcentration = saltConcentration;
    }
    return IterationCreateRequest;
}());



/***/ }),

/***/ "./src/app/lab-request/models/lab-request.ts":
/*!***************************************************!*\
  !*** ./src/app/lab-request/models/lab-request.ts ***!
  \***************************************************/
/*! exports provided: LabRequest */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LabRequest", function() { return LabRequest; });
var LabRequest = /** @class */ (function () {
    function LabRequest(id, businessId, version, iterationId, createdBy, status, createdOn, modifiedBy, modifiedOn, type, jobType, dateRequired, programNumber, comment, blend, density, bhct, bhst, mixWater, waterLoginNo, salt, saltConcentration, cementSource, cementLoginNo, specificGravity, loadAndGo, opr, sgSlurry, sgPowder, clientName, clientServiceRepresentative, clientServiceRepresentativeEmail, technicalServiceRepresentative, technicalServiceRepresentativeEmail, well, tests, iterations) {
        this.id = id;
        this.businessId = businessId;
        this.version = version;
        this.createdBy = createdBy;
        this.status = status;
        this.createdOn = createdOn;
        this.modifiedBy = modifiedBy;
        this.modifiedOn = modifiedOn;
        this.type = type;
        this.jobType = jobType;
        this.dateRequired = dateRequired;
        this.programNumber = programNumber;
        this.comment = comment;
        this.blend = blend;
        this.density = density;
        this.bhct = bhct;
        this.bhst = bhst;
        this.mixWater = mixWater;
        this.waterLoginNo = waterLoginNo;
        this.salt = salt;
        this.saltConcentration = saltConcentration;
        this.cementSource = cementSource;
        this.cementLoginNo = cementLoginNo;
        this.specificGravity = specificGravity;
        this.loadAndGo = loadAndGo;
        this.opr = opr;
        this.sgSlurry = sgSlurry;
        this.sgPowder = sgPowder;
        this.clientName = clientName;
        this.clientServiceRepresentative = clientServiceRepresentative;
        this.clientServiceRepresentativeEmail = clientServiceRepresentativeEmail;
        this.technicalServiceRepresentative = technicalServiceRepresentative;
        this.technicalServiceRepresentativeEmail = technicalServiceRepresentativeEmail;
        this.well = well;
        this.tests = this.rationalizedTests(tests);
        this.iterations = iterations;
        this.iterationId = iterationId;
    }
    LabRequest.prototype.rationalizedTests = function (tests) {
        if (tests === undefined) {
            return tests;
        }
        tests.forEach(function (t) {
            t.parameters.forEach(function (p) {
                if (p.type === 'YesNo') {
                    p.value = (p.value === 'true' || p.value === 'Yes');
                }
            });
        });
        return tests;
    };
    return LabRequest;
}());



/***/ }),

/***/ "./src/app/lab-request/models/lab-test.ts":
/*!************************************************!*\
  !*** ./src/app/lab-request/models/lab-test.ts ***!
  \************************************************/
/*! exports provided: LabTest */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LabTest", function() { return LabTest; });
var LabTest = /** @class */ (function () {
    function LabTest(type, parameters) {
        this.type = type;
        this.parameters = parameters;
    }
    return LabTest;
}());



/***/ }),

/***/ "./src/app/lab-request/models/test-parameter.ts":
/*!******************************************************!*\
  !*** ./src/app/lab-request/models/test-parameter.ts ***!
  \******************************************************/
/*! exports provided: TestParameter */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TestParameter", function() { return TestParameter; });
var TestParameter = /** @class */ (function () {
    function TestParameter(key, type, value) {
        this.key = key;
        this.value = value;
        this.type = type;
    }
    return TestParameter;
}());



/***/ }),

/***/ "./src/app/lab-request/models/well.ts":
/*!********************************************!*\
  !*** ./src/app/lab-request/models/well.ts ***!
  \********************************************/
/*! exports provided: Well */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Well", function() { return Well; });
var Well = /** @class */ (function () {
    function Well(name, servicePoint, downholeLocation, surfaceLocation, tmd, tvd, pressure) {
        this.name = name;
        this.servicePoint = servicePoint;
        this.downholeLocation = downholeLocation;
        this.surfaceLocation = surfaceLocation;
        this.tmd = tmd;
        this.tvd = tvd;
        this.pressure = pressure;
    }
    return Well;
}());



/***/ }),

/***/ "./src/app/lab-request/services/lab-request.service.ts":
/*!*************************************************************!*\
  !*** ./src/app/lab-request/services/lab-request.service.ts ***!
  \*************************************************************/
/*! exports provided: LabRequestService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LabRequestService", function() { return LabRequestService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _adapters_lab_request_adapter__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../adapters/lab-request-adapter */ "./src/app/lab-request/adapters/lab-request-adapter.ts");
/* harmony import */ var src_app_core_utils_file_download_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/utils/file-download.service */ "./src/app/core/utils/file-download.service.ts");







var LabRequestService = /** @class */ (function () {
    function LabRequestService(http, labRequestAdapter, fileDownloadService) {
        this.http = http;
        this.labRequestAdapter = labRequestAdapter;
        this.fileDownloadService = fileDownloadService;
        this.serviceUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].sldAli + "/labRequests";
    }
    /**
     * Returns a lab request
     * @param id - request Id
     * @param versionId - versionId
     *
     * @returns
     * A lab request
     */
    LabRequestService.prototype.getById = function (id, versionId) {
        var _this = this;
        var url = this.serviceUrl + "/" + id + "?versionId=" + versionId;
        return this.http
            .get(url)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(function (response) { return _this.labRequestAdapter.adapt(response); }));
    };
    /**
     * Creates a new iteration for the request
     * @param id the request Id
     */
    LabRequestService.prototype.createIteration = function (id, iterationCreateRequest) {
        var url = this.serviceUrl + "/" + id + "/iteration";
        return this.http.post(url, iterationCreateRequest);
    };
    LabRequestService.prototype.updateIteration = function (id, version, iterationRequest) {
        var url = this.serviceUrl + "/" + id + "/" + version + "/iteration";
        return this.http.put(url, iterationRequest);
    };
    /**
     * Updates a request
     * @param id - a request id
     * @param labRequest - the content to be updated
     */
    LabRequestService.prototype.update = function (id, labRequest) {
        var url = this.serviceUrl + "/" + id;
        return this.http.put(url, labRequest);
    };
    LabRequestService.prototype.save = function (labRequest) {
        var _this = this;
        var url = "" + this.serviceUrl;
        return this.http.post(url, labRequest)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(function (response) { return _this.labRequestAdapter.adapt(response); }));
    };
    /**
     * Downloads the WorksheetCreator excel doc
     * @param id - the request Id
     * @param versionId - the version of the request
     */
    LabRequestService.prototype.downloadWSC = function (id, versionId) {
        var url = this.serviceUrl + "/" + id + "/worksheetcreator?versionId=" + versionId;
        return this.fileDownloadService.downloadFile(url);
    };
    /**
     * Downloads the WorksheetCreator excel doc
     * @param id - the request Id
     * @param versionId - the version of the request
     */
    LabRequestService.prototype.downloadChart = function (id, versionId, type) {
        var url = this.serviceUrl + "/" + id + "/chartcreator?versionId=" + versionId + "&type=" + type;
        return this.fileDownloadService.downloadFile(url);
    };
    /**
     * Returns a list of requests
     * @param page - the index of the page
     * @param limit - the limit of records to be returned
     * @param filters - a filter expression
     * @param orderBy - a field
     * @param orderDirection - the order direction asc or desc
     */
    LabRequestService.prototype.getLabRequests = function (isExperimental, page, limit, filters, orderBy, orderDirection) {
        var url = "" + this.serviceUrl;
        var filterQuery = [];
        filters.forEach(function (value, key) {
            key.replace(':', '\:');
            value.replace(':', '\:');
            filterQuery.push(key + ":" + value);
        });
        var q = filterQuery.join('&&');
        var queryParams = [];
        var indx = null;
        if (isExperimental) {
            indx = queryParams.push('Q=id:E2');
        }
        else {
            indx = queryParams.push('Q=id:B1');
        }
        if (q) {
            queryParams[indx - 1] += encodeURIComponent('&&') + encodeURIComponent(q);
        }
        if (page) {
            queryParams.push("page=" + page);
        }
        if (limit) {
            queryParams.push("limit=" + limit);
        }
        if (orderBy) {
            queryParams.push("orderBy=" + orderBy);
        }
        if (orderDirection) {
            queryParams.push("orderDirection=" + orderDirection);
        }
        var queryString = queryParams.join('&');
        if (queryString) {
            url = url.concat('?', queryString);
        }
        return this.http.get(url);
    };
    LabRequestService.prototype.getLabRequestsExp = function (page, limit, filters, orderBy, orderDirection) {
        var url = "" + this.serviceUrl;
        var filterQuery = [];
        filters.forEach(function (value, key) {
            key.replace(':', '\:');
            value.replace(':', '\:');
            filterQuery.push(key + ":" + value);
        });
        var q = filterQuery.join('&&');
        var queryParams = [];
        queryParams.push('Q=id:E2');
        if (page) {
            queryParams.push("page=" + page);
        }
        if (limit) {
            queryParams.push("limit=" + limit);
        }
        if (orderBy) {
            queryParams.push("orderBy=" + orderBy);
        }
        if (orderDirection) {
            queryParams.push("orderDirection=" + orderDirection);
        }
        if (q) {
            queryParams.push("q=" + encodeURIComponent(q));
        }
        var queryString = queryParams.join('&');
        if (queryString) {
            url = url.concat('?', queryString);
        }
        return this.http.get(url);
    };
    LabRequestService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"],
            _adapters_lab_request_adapter__WEBPACK_IMPORTED_MODULE_5__["LabRequestAdapter"],
            src_app_core_utils_file_download_service__WEBPACK_IMPORTED_MODULE_6__["FileDownloadService"]])
    ], LabRequestService);
    return LabRequestService;
}());



/***/ }),

/***/ "./src/app/master-data/services/additive.service.ts":
/*!**********************************************************!*\
  !*** ./src/app/master-data/services/additive.service.ts ***!
  \**********************************************************/
/*! exports provided: AdditiveService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdditiveService", function() { return AdditiveService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");




var AdditiveService = /** @class */ (function () {
    function AdditiveService(http) {
        this.http = http;
    }
    AdditiveService.prototype.lookup = function (filter) {
        var url = src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].sldAli + "/additives?filter=" + filter;
        return this.http
            .get(url);
    };
    AdditiveService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], AdditiveService);
    return AdditiveService;
}());



/***/ }),

/***/ "./src/app/master-data/services/base-blend.service.ts":
/*!************************************************************!*\
  !*** ./src/app/master-data/services/base-blend.service.ts ***!
  \************************************************************/
/*! exports provided: BaseBlendService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BaseBlendService", function() { return BaseBlendService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");




var BaseBlendService = /** @class */ (function () {
    function BaseBlendService(http) {
        this.http = http;
    }
    BaseBlendService.prototype.lookup = function (filter) {
        var url = src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].sldAli + "/baseBlends?filter=" + filter;
        return this.http
            .get(url);
    };
    BaseBlendService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]])
    ], BaseBlendService);
    return BaseBlendService;
}());



/***/ }),

/***/ "./src/app/master-data/services/lab-test-spec.service.ts":
/*!***************************************************************!*\
  !*** ./src/app/master-data/services/lab-test-spec.service.ts ***!
  \***************************************************************/
/*! exports provided: LabTestSpecService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LabTestSpecService", function() { return LabTestSpecService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");




var LabTestSpecService = /** @class */ (function () {
    function LabTestSpecService(http) {
        this.http = http;
    }
    LabTestSpecService.prototype.getList = function () {
        var url = src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].sldAli + "/labTestSpec";
        return this.http.get(url);
    };
    LabTestSpecService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], LabTestSpecService);
    return LabTestSpecService;
}());



/***/ }),

/***/ "./src/app/master-data/services/lookup.service.ts":
/*!********************************************************!*\
  !*** ./src/app/master-data/services/lookup.service.ts ***!
  \********************************************************/
/*! exports provided: LookupService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LookupService", function() { return LookupService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");




var LookupService = /** @class */ (function () {
    function LookupService(http) {
        this.http = http;
    }
    LookupService.prototype.getList = function (type) {
        var url = src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].sldAli + "/lookups/" + type;
        return this.http
            .get(url);
    };
    LookupService.prototype.getLabTestTypeList = function () {
        return this.getList('labTestType');
    };
    LookupService.prototype.getMixWaterList = function () {
        return this.getList('mixWater');
    };
    LookupService.prototype.getCementSourceList = function () {
        return this.getList('cementSource');
    };
    LookupService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], LookupService);
    return LookupService;
}());



/***/ })

}]);
//# sourceMappingURL=lab-request-lab-request-module.js.map