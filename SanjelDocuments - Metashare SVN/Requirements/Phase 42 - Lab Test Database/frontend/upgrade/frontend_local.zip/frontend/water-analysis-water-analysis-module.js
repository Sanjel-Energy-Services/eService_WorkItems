(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["water-analysis-water-analysis-module"],{

/***/ "./node_modules/balanced-match/index.js":
/*!**********************************************!*\
  !*** ./node_modules/balanced-match/index.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

module.exports = balanced;
function balanced(a, b, str) {
  if (a instanceof RegExp) a = maybeMatch(a, str);
  if (b instanceof RegExp) b = maybeMatch(b, str);

  var r = range(a, b, str);

  return r && {
    start: r[0],
    end: r[1],
    pre: str.slice(0, r[0]),
    body: str.slice(r[0] + a.length, r[1]),
    post: str.slice(r[1] + b.length)
  };
}

function maybeMatch(reg, str) {
  var m = str.match(reg);
  return m ? m[0] : null;
}

balanced.range = range;
function range(a, b, str) {
  var begs, beg, left, right, result;
  var ai = str.indexOf(a);
  var bi = str.indexOf(b, ai + 1);
  var i = ai;

  if (ai >= 0 && bi > 0) {
    begs = [];
    left = str.length;

    while (i >= 0 && !result) {
      if (i == ai) {
        begs.push(i);
        ai = str.indexOf(a, i + 1);
      } else if (begs.length == 1) {
        result = [ begs.pop(), bi ];
      } else {
        beg = begs.pop();
        if (beg < left) {
          left = beg;
          right = bi;
        }

        bi = str.indexOf(b, i + 1);
      }

      i = ai < bi && ai >= 0 ? ai : bi;
    }

    if (begs.length) {
      result = [ left, right ];
    }
  }

  return result;
}


/***/ }),

/***/ "./node_modules/brace-expansion/index.js":
/*!***********************************************!*\
  !*** ./node_modules/brace-expansion/index.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var concatMap = __webpack_require__(/*! concat-map */ "./node_modules/concat-map/index.js");
var balanced = __webpack_require__(/*! balanced-match */ "./node_modules/balanced-match/index.js");

module.exports = expandTop;

var escSlash = '\0SLASH'+Math.random()+'\0';
var escOpen = '\0OPEN'+Math.random()+'\0';
var escClose = '\0CLOSE'+Math.random()+'\0';
var escComma = '\0COMMA'+Math.random()+'\0';
var escPeriod = '\0PERIOD'+Math.random()+'\0';

function numeric(str) {
  return parseInt(str, 10) == str
    ? parseInt(str, 10)
    : str.charCodeAt(0);
}

function escapeBraces(str) {
  return str.split('\\\\').join(escSlash)
            .split('\\{').join(escOpen)
            .split('\\}').join(escClose)
            .split('\\,').join(escComma)
            .split('\\.').join(escPeriod);
}

function unescapeBraces(str) {
  return str.split(escSlash).join('\\')
            .split(escOpen).join('{')
            .split(escClose).join('}')
            .split(escComma).join(',')
            .split(escPeriod).join('.');
}


// Basically just str.split(","), but handling cases
// where we have nested braced sections, which should be
// treated as individual members, like {a,{b,c},d}
function parseCommaParts(str) {
  if (!str)
    return [''];

  var parts = [];
  var m = balanced('{', '}', str);

  if (!m)
    return str.split(',');

  var pre = m.pre;
  var body = m.body;
  var post = m.post;
  var p = pre.split(',');

  p[p.length-1] += '{' + body + '}';
  var postParts = parseCommaParts(post);
  if (post.length) {
    p[p.length-1] += postParts.shift();
    p.push.apply(p, postParts);
  }

  parts.push.apply(parts, p);

  return parts;
}

function expandTop(str) {
  if (!str)
    return [];

  // I don't know why Bash 4.3 does this, but it does.
  // Anything starting with {} will have the first two bytes preserved
  // but *only* at the top level, so {},a}b will not expand to anything,
  // but a{},b}c will be expanded to [a}c,abc].
  // One could argue that this is a bug in Bash, but since the goal of
  // this module is to match Bash's rules, we escape a leading {}
  if (str.substr(0, 2) === '{}') {
    str = '\\{\\}' + str.substr(2);
  }

  return expand(escapeBraces(str), true).map(unescapeBraces);
}

function identity(e) {
  return e;
}

function embrace(str) {
  return '{' + str + '}';
}
function isPadded(el) {
  return /^-?0\d/.test(el);
}

function lte(i, y) {
  return i <= y;
}
function gte(i, y) {
  return i >= y;
}

function expand(str, isTop) {
  var expansions = [];

  var m = balanced('{', '}', str);
  if (!m || /\$$/.test(m.pre)) return [str];

  var isNumericSequence = /^-?\d+\.\.-?\d+(?:\.\.-?\d+)?$/.test(m.body);
  var isAlphaSequence = /^[a-zA-Z]\.\.[a-zA-Z](?:\.\.-?\d+)?$/.test(m.body);
  var isSequence = isNumericSequence || isAlphaSequence;
  var isOptions = m.body.indexOf(',') >= 0;
  if (!isSequence && !isOptions) {
    // {a},b}
    if (m.post.match(/,.*\}/)) {
      str = m.pre + '{' + m.body + escClose + m.post;
      return expand(str);
    }
    return [str];
  }

  var n;
  if (isSequence) {
    n = m.body.split(/\.\./);
  } else {
    n = parseCommaParts(m.body);
    if (n.length === 1) {
      // x{{a,b}}y ==> x{a}y x{b}y
      n = expand(n[0], false).map(embrace);
      if (n.length === 1) {
        var post = m.post.length
          ? expand(m.post, false)
          : [''];
        return post.map(function(p) {
          return m.pre + n[0] + p;
        });
      }
    }
  }

  // at this point, n is the parts, and we know it's not a comma set
  // with a single entry.

  // no need to expand pre, since it is guaranteed to be free of brace-sets
  var pre = m.pre;
  var post = m.post.length
    ? expand(m.post, false)
    : [''];

  var N;

  if (isSequence) {
    var x = numeric(n[0]);
    var y = numeric(n[1]);
    var width = Math.max(n[0].length, n[1].length)
    var incr = n.length == 3
      ? Math.abs(numeric(n[2]))
      : 1;
    var test = lte;
    var reverse = y < x;
    if (reverse) {
      incr *= -1;
      test = gte;
    }
    var pad = n.some(isPadded);

    N = [];

    for (var i = x; test(i, y); i += incr) {
      var c;
      if (isAlphaSequence) {
        c = String.fromCharCode(i);
        if (c === '\\')
          c = '';
      } else {
        c = String(i);
        if (pad) {
          var need = width - c.length;
          if (need > 0) {
            var z = new Array(need + 1).join('0');
            if (i < 0)
              c = '-' + z + c.slice(1);
            else
              c = z + c;
          }
        }
      }
      N.push(c);
    }
  } else {
    N = concatMap(n, function(el) { return expand(el, false) });
  }

  for (var j = 0; j < N.length; j++) {
    for (var k = 0; k < post.length; k++) {
      var expansion = pre + N[j] + post[k];
      if (!isTop || isSequence || expansion)
        expansions.push(expansion);
    }
  }

  return expansions;
}



/***/ }),

/***/ "./node_modules/concat-map/index.js":
/*!******************************************!*\
  !*** ./node_modules/concat-map/index.js ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = function (xs, fn) {
    var res = [];
    for (var i = 0; i < xs.length; i++) {
        var x = fn(xs[i], i);
        if (isArray(x)) res.push.apply(res, x);
        else res.push(x);
    }
    return res;
};

var isArray = Array.isArray || function (xs) {
    return Object.prototype.toString.call(xs) === '[object Array]';
};


/***/ }),

/***/ "./node_modules/inherits/inherits_browser.js":
/*!***************************************************!*\
  !*** ./node_modules/inherits/inherits_browser.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

if (typeof Object.create === 'function') {
  // implementation from standard node.js 'util' module
  module.exports = function inherits(ctor, superCtor) {
    ctor.super_ = superCtor
    ctor.prototype = Object.create(superCtor.prototype, {
      constructor: {
        value: ctor,
        enumerable: false,
        writable: true,
        configurable: true
      }
    });
  };
} else {
  // old school shim for old browsers
  module.exports = function inherits(ctor, superCtor) {
    ctor.super_ = superCtor
    var TempCtor = function () {}
    TempCtor.prototype = superCtor.prototype
    ctor.prototype = new TempCtor()
    ctor.prototype.constructor = ctor
  }
}


/***/ }),

/***/ "./node_modules/minimatch/minimatch.js":
/*!*********************************************!*\
  !*** ./node_modules/minimatch/minimatch.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = minimatch
minimatch.Minimatch = Minimatch

var path = { sep: '/' }
try {
  path = __webpack_require__(/*! path */ "./node_modules/path/path.js")
} catch (er) {}

var GLOBSTAR = minimatch.GLOBSTAR = Minimatch.GLOBSTAR = {}
var expand = __webpack_require__(/*! brace-expansion */ "./node_modules/brace-expansion/index.js")

var plTypes = {
  '!': { open: '(?:(?!(?:', close: '))[^/]*?)'},
  '?': { open: '(?:', close: ')?' },
  '+': { open: '(?:', close: ')+' },
  '*': { open: '(?:', close: ')*' },
  '@': { open: '(?:', close: ')' }
}

// any single thing other than /
// don't need to escape / when using new RegExp()
var qmark = '[^/]'

// * => any number of characters
var star = qmark + '*?'

// ** when dots are allowed.  Anything goes, except .. and .
// not (^ or / followed by one or two dots followed by $ or /),
// followed by anything, any number of times.
var twoStarDot = '(?:(?!(?:\\\/|^)(?:\\.{1,2})($|\\\/)).)*?'

// not a ^ or / followed by a dot,
// followed by anything, any number of times.
var twoStarNoDot = '(?:(?!(?:\\\/|^)\\.).)*?'

// characters that need to be escaped in RegExp.
var reSpecials = charSet('().*{}+?[]^$\\!')

// "abc" -> { a:true, b:true, c:true }
function charSet (s) {
  return s.split('').reduce(function (set, c) {
    set[c] = true
    return set
  }, {})
}

// normalizes slashes.
var slashSplit = /\/+/

minimatch.filter = filter
function filter (pattern, options) {
  options = options || {}
  return function (p, i, list) {
    return minimatch(p, pattern, options)
  }
}

function ext (a, b) {
  a = a || {}
  b = b || {}
  var t = {}
  Object.keys(b).forEach(function (k) {
    t[k] = b[k]
  })
  Object.keys(a).forEach(function (k) {
    t[k] = a[k]
  })
  return t
}

minimatch.defaults = function (def) {
  if (!def || !Object.keys(def).length) return minimatch

  var orig = minimatch

  var m = function minimatch (p, pattern, options) {
    return orig.minimatch(p, pattern, ext(def, options))
  }

  m.Minimatch = function Minimatch (pattern, options) {
    return new orig.Minimatch(pattern, ext(def, options))
  }

  return m
}

Minimatch.defaults = function (def) {
  if (!def || !Object.keys(def).length) return Minimatch
  return minimatch.defaults(def).Minimatch
}

function minimatch (p, pattern, options) {
  if (typeof pattern !== 'string') {
    throw new TypeError('glob pattern string required')
  }

  if (!options) options = {}

  // shortcut: comments match nothing.
  if (!options.nocomment && pattern.charAt(0) === '#') {
    return false
  }

  // "" only matches ""
  if (pattern.trim() === '') return p === ''

  return new Minimatch(pattern, options).match(p)
}

function Minimatch (pattern, options) {
  if (!(this instanceof Minimatch)) {
    return new Minimatch(pattern, options)
  }

  if (typeof pattern !== 'string') {
    throw new TypeError('glob pattern string required')
  }

  if (!options) options = {}
  pattern = pattern.trim()

  // windows support: need to use /, not \
  if (path.sep !== '/') {
    pattern = pattern.split(path.sep).join('/')
  }

  this.options = options
  this.set = []
  this.pattern = pattern
  this.regexp = null
  this.negate = false
  this.comment = false
  this.empty = false

  // make the set of regexps etc.
  this.make()
}

Minimatch.prototype.debug = function () {}

Minimatch.prototype.make = make
function make () {
  // don't do it more than once.
  if (this._made) return

  var pattern = this.pattern
  var options = this.options

  // empty patterns and comments match nothing.
  if (!options.nocomment && pattern.charAt(0) === '#') {
    this.comment = true
    return
  }
  if (!pattern) {
    this.empty = true
    return
  }

  // step 1: figure out negation, etc.
  this.parseNegate()

  // step 2: expand braces
  var set = this.globSet = this.braceExpand()

  if (options.debug) this.debug = console.error

  this.debug(this.pattern, set)

  // step 3: now we have a set, so turn each one into a series of path-portion
  // matching patterns.
  // These will be regexps, except in the case of "**", which is
  // set to the GLOBSTAR object for globstar behavior,
  // and will not contain any / characters
  set = this.globParts = set.map(function (s) {
    return s.split(slashSplit)
  })

  this.debug(this.pattern, set)

  // glob --> regexps
  set = set.map(function (s, si, set) {
    return s.map(this.parse, this)
  }, this)

  this.debug(this.pattern, set)

  // filter out everything that didn't compile properly.
  set = set.filter(function (s) {
    return s.indexOf(false) === -1
  })

  this.debug(this.pattern, set)

  this.set = set
}

Minimatch.prototype.parseNegate = parseNegate
function parseNegate () {
  var pattern = this.pattern
  var negate = false
  var options = this.options
  var negateOffset = 0

  if (options.nonegate) return

  for (var i = 0, l = pattern.length
    ; i < l && pattern.charAt(i) === '!'
    ; i++) {
    negate = !negate
    negateOffset++
  }

  if (negateOffset) this.pattern = pattern.substr(negateOffset)
  this.negate = negate
}

// Brace expansion:
// a{b,c}d -> abd acd
// a{b,}c -> abc ac
// a{0..3}d -> a0d a1d a2d a3d
// a{b,c{d,e}f}g -> abg acdfg acefg
// a{b,c}d{e,f}g -> abdeg acdeg abdeg abdfg
//
// Invalid sets are not expanded.
// a{2..}b -> a{2..}b
// a{b}c -> a{b}c
minimatch.braceExpand = function (pattern, options) {
  return braceExpand(pattern, options)
}

Minimatch.prototype.braceExpand = braceExpand

function braceExpand (pattern, options) {
  if (!options) {
    if (this instanceof Minimatch) {
      options = this.options
    } else {
      options = {}
    }
  }

  pattern = typeof pattern === 'undefined'
    ? this.pattern : pattern

  if (typeof pattern === 'undefined') {
    throw new TypeError('undefined pattern')
  }

  if (options.nobrace ||
    !pattern.match(/\{.*\}/)) {
    // shortcut. no need to expand.
    return [pattern]
  }

  return expand(pattern)
}

// parse a component of the expanded set.
// At this point, no pattern may contain "/" in it
// so we're going to return a 2d array, where each entry is the full
// pattern, split on '/', and then turned into a regular expression.
// A regexp is made at the end which joins each array with an
// escaped /, and another full one which joins each regexp with |.
//
// Following the lead of Bash 4.1, note that "**" only has special meaning
// when it is the *only* thing in a path portion.  Otherwise, any series
// of * is equivalent to a single *.  Globstar behavior is enabled by
// default, and can be disabled by setting options.noglobstar.
Minimatch.prototype.parse = parse
var SUBPARSE = {}
function parse (pattern, isSub) {
  if (pattern.length > 1024 * 64) {
    throw new TypeError('pattern is too long')
  }

  var options = this.options

  // shortcuts
  if (!options.noglobstar && pattern === '**') return GLOBSTAR
  if (pattern === '') return ''

  var re = ''
  var hasMagic = !!options.nocase
  var escaping = false
  // ? => one single character
  var patternListStack = []
  var negativeLists = []
  var stateChar
  var inClass = false
  var reClassStart = -1
  var classStart = -1
  // . and .. never match anything that doesn't start with .,
  // even when options.dot is set.
  var patternStart = pattern.charAt(0) === '.' ? '' // anything
  // not (start or / followed by . or .. followed by / or end)
  : options.dot ? '(?!(?:^|\\\/)\\.{1,2}(?:$|\\\/))'
  : '(?!\\.)'
  var self = this

  function clearStateChar () {
    if (stateChar) {
      // we had some state-tracking character
      // that wasn't consumed by this pass.
      switch (stateChar) {
        case '*':
          re += star
          hasMagic = true
        break
        case '?':
          re += qmark
          hasMagic = true
        break
        default:
          re += '\\' + stateChar
        break
      }
      self.debug('clearStateChar %j %j', stateChar, re)
      stateChar = false
    }
  }

  for (var i = 0, len = pattern.length, c
    ; (i < len) && (c = pattern.charAt(i))
    ; i++) {
    this.debug('%s\t%s %s %j', pattern, i, re, c)

    // skip over any that are escaped.
    if (escaping && reSpecials[c]) {
      re += '\\' + c
      escaping = false
      continue
    }

    switch (c) {
      case '/':
        // completely not allowed, even escaped.
        // Should already be path-split by now.
        return false

      case '\\':
        clearStateChar()
        escaping = true
      continue

      // the various stateChar values
      // for the "extglob" stuff.
      case '?':
      case '*':
      case '+':
      case '@':
      case '!':
        this.debug('%s\t%s %s %j <-- stateChar', pattern, i, re, c)

        // all of those are literals inside a class, except that
        // the glob [!a] means [^a] in regexp
        if (inClass) {
          this.debug('  in class')
          if (c === '!' && i === classStart + 1) c = '^'
          re += c
          continue
        }

        // if we already have a stateChar, then it means
        // that there was something like ** or +? in there.
        // Handle the stateChar, then proceed with this one.
        self.debug('call clearStateChar %j', stateChar)
        clearStateChar()
        stateChar = c
        // if extglob is disabled, then +(asdf|foo) isn't a thing.
        // just clear the statechar *now*, rather than even diving into
        // the patternList stuff.
        if (options.noext) clearStateChar()
      continue

      case '(':
        if (inClass) {
          re += '('
          continue
        }

        if (!stateChar) {
          re += '\\('
          continue
        }

        patternListStack.push({
          type: stateChar,
          start: i - 1,
          reStart: re.length,
          open: plTypes[stateChar].open,
          close: plTypes[stateChar].close
        })
        // negation is (?:(?!js)[^/]*)
        re += stateChar === '!' ? '(?:(?!(?:' : '(?:'
        this.debug('plType %j %j', stateChar, re)
        stateChar = false
      continue

      case ')':
        if (inClass || !patternListStack.length) {
          re += '\\)'
          continue
        }

        clearStateChar()
        hasMagic = true
        var pl = patternListStack.pop()
        // negation is (?:(?!js)[^/]*)
        // The others are (?:<pattern>)<type>
        re += pl.close
        if (pl.type === '!') {
          negativeLists.push(pl)
        }
        pl.reEnd = re.length
      continue

      case '|':
        if (inClass || !patternListStack.length || escaping) {
          re += '\\|'
          escaping = false
          continue
        }

        clearStateChar()
        re += '|'
      continue

      // these are mostly the same in regexp and glob
      case '[':
        // swallow any state-tracking char before the [
        clearStateChar()

        if (inClass) {
          re += '\\' + c
          continue
        }

        inClass = true
        classStart = i
        reClassStart = re.length
        re += c
      continue

      case ']':
        //  a right bracket shall lose its special
        //  meaning and represent itself in
        //  a bracket expression if it occurs
        //  first in the list.  -- POSIX.2 2.8.3.2
        if (i === classStart + 1 || !inClass) {
          re += '\\' + c
          escaping = false
          continue
        }

        // handle the case where we left a class open.
        // "[z-a]" is valid, equivalent to "\[z-a\]"
        if (inClass) {
          // split where the last [ was, make sure we don't have
          // an invalid re. if so, re-walk the contents of the
          // would-be class to re-translate any characters that
          // were passed through as-is
          // TODO: It would probably be faster to determine this
          // without a try/catch and a new RegExp, but it's tricky
          // to do safely.  For now, this is safe and works.
          var cs = pattern.substring(classStart + 1, i)
          try {
            RegExp('[' + cs + ']')
          } catch (er) {
            // not a valid class!
            var sp = this.parse(cs, SUBPARSE)
            re = re.substr(0, reClassStart) + '\\[' + sp[0] + '\\]'
            hasMagic = hasMagic || sp[1]
            inClass = false
            continue
          }
        }

        // finish up the class.
        hasMagic = true
        inClass = false
        re += c
      continue

      default:
        // swallow any state char that wasn't consumed
        clearStateChar()

        if (escaping) {
          // no need
          escaping = false
        } else if (reSpecials[c]
          && !(c === '^' && inClass)) {
          re += '\\'
        }

        re += c

    } // switch
  } // for

  // handle the case where we left a class open.
  // "[abc" is valid, equivalent to "\[abc"
  if (inClass) {
    // split where the last [ was, and escape it
    // this is a huge pita.  We now have to re-walk
    // the contents of the would-be class to re-translate
    // any characters that were passed through as-is
    cs = pattern.substr(classStart + 1)
    sp = this.parse(cs, SUBPARSE)
    re = re.substr(0, reClassStart) + '\\[' + sp[0]
    hasMagic = hasMagic || sp[1]
  }

  // handle the case where we had a +( thing at the *end*
  // of the pattern.
  // each pattern list stack adds 3 chars, and we need to go through
  // and escape any | chars that were passed through as-is for the regexp.
  // Go through and escape them, taking care not to double-escape any
  // | chars that were already escaped.
  for (pl = patternListStack.pop(); pl; pl = patternListStack.pop()) {
    var tail = re.slice(pl.reStart + pl.open.length)
    this.debug('setting tail', re, pl)
    // maybe some even number of \, then maybe 1 \, followed by a |
    tail = tail.replace(/((?:\\{2}){0,64})(\\?)\|/g, function (_, $1, $2) {
      if (!$2) {
        // the | isn't already escaped, so escape it.
        $2 = '\\'
      }

      // need to escape all those slashes *again*, without escaping the
      // one that we need for escaping the | character.  As it works out,
      // escaping an even number of slashes can be done by simply repeating
      // it exactly after itself.  That's why this trick works.
      //
      // I am sorry that you have to see this.
      return $1 + $1 + $2 + '|'
    })

    this.debug('tail=%j\n   %s', tail, tail, pl, re)
    var t = pl.type === '*' ? star
      : pl.type === '?' ? qmark
      : '\\' + pl.type

    hasMagic = true
    re = re.slice(0, pl.reStart) + t + '\\(' + tail
  }

  // handle trailing things that only matter at the very end.
  clearStateChar()
  if (escaping) {
    // trailing \\
    re += '\\\\'
  }

  // only need to apply the nodot start if the re starts with
  // something that could conceivably capture a dot
  var addPatternStart = false
  switch (re.charAt(0)) {
    case '.':
    case '[':
    case '(': addPatternStart = true
  }

  // Hack to work around lack of negative lookbehind in JS
  // A pattern like: *.!(x).!(y|z) needs to ensure that a name
  // like 'a.xyz.yz' doesn't match.  So, the first negative
  // lookahead, has to look ALL the way ahead, to the end of
  // the pattern.
  for (var n = negativeLists.length - 1; n > -1; n--) {
    var nl = negativeLists[n]

    var nlBefore = re.slice(0, nl.reStart)
    var nlFirst = re.slice(nl.reStart, nl.reEnd - 8)
    var nlLast = re.slice(nl.reEnd - 8, nl.reEnd)
    var nlAfter = re.slice(nl.reEnd)

    nlLast += nlAfter

    // Handle nested stuff like *(*.js|!(*.json)), where open parens
    // mean that we should *not* include the ) in the bit that is considered
    // "after" the negated section.
    var openParensBefore = nlBefore.split('(').length - 1
    var cleanAfter = nlAfter
    for (i = 0; i < openParensBefore; i++) {
      cleanAfter = cleanAfter.replace(/\)[+*?]?/, '')
    }
    nlAfter = cleanAfter

    var dollar = ''
    if (nlAfter === '' && isSub !== SUBPARSE) {
      dollar = '$'
    }
    var newRe = nlBefore + nlFirst + nlAfter + dollar + nlLast
    re = newRe
  }

  // if the re is not "" at this point, then we need to make sure
  // it doesn't match against an empty path part.
  // Otherwise a/* will match a/, which it should not.
  if (re !== '' && hasMagic) {
    re = '(?=.)' + re
  }

  if (addPatternStart) {
    re = patternStart + re
  }

  // parsing just a piece of a larger pattern.
  if (isSub === SUBPARSE) {
    return [re, hasMagic]
  }

  // skip the regexp for non-magical patterns
  // unescape anything in it, though, so that it'll be
  // an exact match against a file etc.
  if (!hasMagic) {
    return globUnescape(pattern)
  }

  var flags = options.nocase ? 'i' : ''
  try {
    var regExp = new RegExp('^' + re + '$', flags)
  } catch (er) {
    // If it was an invalid regular expression, then it can't match
    // anything.  This trick looks for a character after the end of
    // the string, which is of course impossible, except in multi-line
    // mode, but it's not a /m regex.
    return new RegExp('$.')
  }

  regExp._glob = pattern
  regExp._src = re

  return regExp
}

minimatch.makeRe = function (pattern, options) {
  return new Minimatch(pattern, options || {}).makeRe()
}

Minimatch.prototype.makeRe = makeRe
function makeRe () {
  if (this.regexp || this.regexp === false) return this.regexp

  // at this point, this.set is a 2d array of partial
  // pattern strings, or "**".
  //
  // It's better to use .match().  This function shouldn't
  // be used, really, but it's pretty convenient sometimes,
  // when you just want to work with a regex.
  var set = this.set

  if (!set.length) {
    this.regexp = false
    return this.regexp
  }
  var options = this.options

  var twoStar = options.noglobstar ? star
    : options.dot ? twoStarDot
    : twoStarNoDot
  var flags = options.nocase ? 'i' : ''

  var re = set.map(function (pattern) {
    return pattern.map(function (p) {
      return (p === GLOBSTAR) ? twoStar
      : (typeof p === 'string') ? regExpEscape(p)
      : p._src
    }).join('\\\/')
  }).join('|')

  // must match entire pattern
  // ending in a * or ** will make it less strict.
  re = '^(?:' + re + ')$'

  // can match anything, as long as it's not this.
  if (this.negate) re = '^(?!' + re + ').*$'

  try {
    this.regexp = new RegExp(re, flags)
  } catch (ex) {
    this.regexp = false
  }
  return this.regexp
}

minimatch.match = function (list, pattern, options) {
  options = options || {}
  var mm = new Minimatch(pattern, options)
  list = list.filter(function (f) {
    return mm.match(f)
  })
  if (mm.options.nonull && !list.length) {
    list.push(pattern)
  }
  return list
}

Minimatch.prototype.match = match
function match (f, partial) {
  this.debug('match', f, this.pattern)
  // short-circuit in the case of busted things.
  // comments, etc.
  if (this.comment) return false
  if (this.empty) return f === ''

  if (f === '/' && partial) return true

  var options = this.options

  // windows: need to use /, not \
  if (path.sep !== '/') {
    f = f.split(path.sep).join('/')
  }

  // treat the test path as a set of pathparts.
  f = f.split(slashSplit)
  this.debug(this.pattern, 'split', f)

  // just ONE of the pattern sets in this.set needs to match
  // in order for it to be valid.  If negating, then just one
  // match means that we have failed.
  // Either way, return on the first hit.

  var set = this.set
  this.debug(this.pattern, 'set', set)

  // Find the basename of the path by looking for the last non-empty segment
  var filename
  var i
  for (i = f.length - 1; i >= 0; i--) {
    filename = f[i]
    if (filename) break
  }

  for (i = 0; i < set.length; i++) {
    var pattern = set[i]
    var file = f
    if (options.matchBase && pattern.length === 1) {
      file = [filename]
    }
    var hit = this.matchOne(file, pattern, partial)
    if (hit) {
      if (options.flipNegate) return true
      return !this.negate
    }
  }

  // didn't get any hits.  this is success if it's a negative
  // pattern, failure otherwise.
  if (options.flipNegate) return false
  return this.negate
}

// set partial to true to test if, for example,
// "/a/b" matches the start of "/*/b/*/d"
// Partial means, if you run out of file before you run
// out of pattern, then that's fine, as long as all
// the parts match.
Minimatch.prototype.matchOne = function (file, pattern, partial) {
  var options = this.options

  this.debug('matchOne',
    { 'this': this, file: file, pattern: pattern })

  this.debug('matchOne', file.length, pattern.length)

  for (var fi = 0,
      pi = 0,
      fl = file.length,
      pl = pattern.length
      ; (fi < fl) && (pi < pl)
      ; fi++, pi++) {
    this.debug('matchOne loop')
    var p = pattern[pi]
    var f = file[fi]

    this.debug(pattern, p, f)

    // should be impossible.
    // some invalid regexp stuff in the set.
    if (p === false) return false

    if (p === GLOBSTAR) {
      this.debug('GLOBSTAR', [pattern, p, f])

      // "**"
      // a/**/b/**/c would match the following:
      // a/b/x/y/z/c
      // a/x/y/z/b/c
      // a/b/x/b/x/c
      // a/b/c
      // To do this, take the rest of the pattern after
      // the **, and see if it would match the file remainder.
      // If so, return success.
      // If not, the ** "swallows" a segment, and try again.
      // This is recursively awful.
      //
      // a/**/b/**/c matching a/b/x/y/z/c
      // - a matches a
      // - doublestar
      //   - matchOne(b/x/y/z/c, b/**/c)
      //     - b matches b
      //     - doublestar
      //       - matchOne(x/y/z/c, c) -> no
      //       - matchOne(y/z/c, c) -> no
      //       - matchOne(z/c, c) -> no
      //       - matchOne(c, c) yes, hit
      var fr = fi
      var pr = pi + 1
      if (pr === pl) {
        this.debug('** at the end')
        // a ** at the end will just swallow the rest.
        // We have found a match.
        // however, it will not swallow /.x, unless
        // options.dot is set.
        // . and .. are *never* matched by **, for explosively
        // exponential reasons.
        for (; fi < fl; fi++) {
          if (file[fi] === '.' || file[fi] === '..' ||
            (!options.dot && file[fi].charAt(0) === '.')) return false
        }
        return true
      }

      // ok, let's see if we can swallow whatever we can.
      while (fr < fl) {
        var swallowee = file[fr]

        this.debug('\nglobstar while', file, fr, pattern, pr, swallowee)

        // XXX remove this slice.  Just pass the start index.
        if (this.matchOne(file.slice(fr), pattern.slice(pr), partial)) {
          this.debug('globstar found match!', fr, fl, swallowee)
          // found a match.
          return true
        } else {
          // can't swallow "." or ".." ever.
          // can only swallow ".foo" when explicitly asked.
          if (swallowee === '.' || swallowee === '..' ||
            (!options.dot && swallowee.charAt(0) === '.')) {
            this.debug('dot detected!', file, fr, pattern, pr)
            break
          }

          // ** swallows a segment, and continue.
          this.debug('globstar swallow a segment, and continue')
          fr++
        }
      }

      // no match was found.
      // However, in partial mode, we can't say this is necessarily over.
      // If there's more *pattern* left, then
      if (partial) {
        // ran out of file
        this.debug('\n>>> no match, partial?', file, fr, pattern, pr)
        if (fr === fl) return true
      }
      return false
    }

    // something other than **
    // non-magic patterns just have to match exactly
    // patterns with magic have been turned into regexps.
    var hit
    if (typeof p === 'string') {
      if (options.nocase) {
        hit = f.toLowerCase() === p.toLowerCase()
      } else {
        hit = f === p
      }
      this.debug('string match', p, f, hit)
    } else {
      hit = f.match(p)
      this.debug('pattern match', p, f, hit)
    }

    if (!hit) return false
  }

  // Note: ending in / means that we'll get a final ""
  // at the end of the pattern.  This can only match a
  // corresponding "" at the end of the file.
  // If the file ends in /, then it can only match a
  // a pattern that ends in /, unless the pattern just
  // doesn't have any more for it. But, a/b/ should *not*
  // match "a/b/*", even though "" matches against the
  // [^/]*? pattern, except in partial mode, where it might
  // simply not be reached yet.
  // However, a/b/ should still satisfy a/*

  // now either we fell off the end of the pattern, or we're done.
  if (fi === fl && pi === pl) {
    // ran out of pattern and filename at the same time.
    // an exact hit!
    return true
  } else if (fi === fl) {
    // ran out of file, but still had pattern left.
    // this is ok if we're doing the match as part of
    // a glob fs traversal.
    return partial
  } else if (pi === pl) {
    // ran out of pattern, still have file left.
    // this is only acceptable if we're on the very last
    // empty segment of a file with a trailing slash.
    // a/* should match a/b/
    var emptyFileEnd = (fi === fl - 1) && (file[fi] === '')
    return emptyFileEnd
  }

  // should be unreachable.
  throw new Error('wtf?')
}

// replace stuff like \* with *
function globUnescape (s) {
  return s.replace(/\\(.)/g, '$1')
}

function regExpEscape (s) {
  return s.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&')
}


/***/ }),

/***/ "./node_modules/object-mapper/index.js":
/*!*********************************************!*\
  !*** ./node_modules/object-mapper/index.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/*

 The MIT License (MIT)
 =====================

 Copyright (c) 2012 Daniel L. VerWeire

 Permission is hereby granted, free of charge, to any person obtaining
 a copy of this software and associated documentation files (the
 "Software"), to deal in the Software without restriction, including
 without limitation the rights to use, copy, modify, merge, publish,
 distribute, sublicense, and/or sell copies of the Software, and to
 permit persons to whom the Software is furnished to do so, subject to
 the following conditions:

 The above copyright notice and this permission notice shall be
 included in all copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
 CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 */

module.exports = __webpack_require__(/*! ./src/object-mapper */ "./node_modules/object-mapper/src/object-mapper.js");

/***/ }),

/***/ "./node_modules/object-mapper/src/get-key-value.js":
/*!*********************************************************!*\
  !*** ./node_modules/object-mapper/src/get-key-value.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var minimatch = __webpack_require__(/*! minimatch */ "./node_modules/minimatch/minimatch.js");

/**
 * Make the get of a value with the key in the passed object
 * @param fromObject
 * @param fromKey
 * @constructor
 * @returns {*}
 */
function GetKeyValue(fromObject, fromKey) {
  var regFinishArray = /.+(\[\])/g
    , keys
    , key
    , result
    , lastValue
    , merged = []
    ;

  // matches only unescaped dots
  var regDot = /([^\\])(\\\\)*\./g;
  var keys = fromKey.split(regDot);
  for (var i = 0; i < keys.length; i++) {
    if ((i - 1) % 3 === 0) {
      // Every third match is the character of
      // the first group [^\\] which
      // is the last character of the key.
      // Merge it in again.
      var tmpKey = keys[i - 1] + keys[i];
      if (keys[i + 1]) {
        // If second group is found, this means
        // that the backslash itself is escaped.
        // Retain unchanged as well.
        tmpKey += keys[i + 1];
      }
      merged.push(tmpKey.replace(/\\\./g, "."));
    }
    // Add part after last dot
    if (i === keys.length - 1) {
      merged.push(keys[i].replace(/\\\./g, "."));
    }
  }
  keys = merged;
  key = keys.splice(0, 1);
  lastValue = fromKey.match(regFinishArray);
  if(lastValue != null && lastValue[0] === fromKey){
    fromKey = fromKey.slice(0,-2);
  }else{
    lastValue = null;
  }
  result = _getValue(fromObject, key[0], keys);

  if (Array.isArray(result) && !lastValue) {
    if (result.length) {
      result = result.reduce(function (a, b) {
        if (Array.isArray(a) && Array.isArray(b)) {
          return a.concat(b);
        } else if (Array.isArray(a)) {
          a.push(b);
          return a;
        } else {
          return [a, b];
        }
      });
    }
    if (!Array.isArray(result)) {
      result = [result];
    }
  }

  return result;
}
module.exports = GetKeyValue;

/**
 * Get the value of key within passed object, considering if there is a array or object
 * @param fromObject
 * @param key
 * @param keys
 * @returns {*}
 * @private
 * @recursive
 */
function _getValue(fromObject, key, keys) {
  var regArray = /(\[\]|\[(.*)\])$/g
    , match
    , arrayIndex
    , isValueArray = false
    , result
    ;

  if (!fromObject) {
    return;
  }

  match = regArray.exec(key);
  if (match) {
    key = key.replace(regArray, '');
    isValueArray = (key !== '');
    arrayIndex = match[2];
  }

  if (keys.length === 0) {
    if (isValueArray) {
      if (typeof arrayIndex === 'undefined' || fromObject[key] === undefined) {
        result = fromObject[key];
      } else {
        result = fromObject[key][arrayIndex];
      }
    } else if (Array.isArray(fromObject)) {
      if (key === '') {
        if (typeof arrayIndex === 'undefined') {
          result = fromObject;
        } else {
          result = fromObject[arrayIndex];
        }
      } else {
        result = fromObject.map(function (item) {
          return item[key];
        })
      }
    } else {
      if (fromObject[key] === undefined) {
        result = _getGlobValues(fromObject, key, keys);
      } else {
        result = fromObject[key];
      }
    }
  } else {
    if (isValueArray) {
      if (Array.isArray(fromObject[key])) {
        if (typeof arrayIndex === 'undefined') {
          result = fromObject[key].map(function (item) {
            return _getValue(item, keys[0], keys.slice(1));
          });
        } else {
          result = _getValue(fromObject[key][arrayIndex], keys[0], keys.slice(1));
        }
      } else {
        if (typeof arrayIndex === 'undefined') {
          result = _getValue(fromObject[key], keys[0], keys.slice(1));
        } else {
          result = _getValue(fromObject[key][arrayIndex], keys[0], keys.slice(1));
        }
      }
    } else if (Array.isArray(fromObject)) {
      if (key === '') {
        if (typeof arrayIndex === 'undefined') {
          result = _getValue(fromObject, keys[0], keys.slice(1));
        } else {
          result = _getValue(fromObject[arrayIndex], keys[0], keys.slice(1));
        }
      } else {
        result = fromObject.map(function (item) {
          result = _getValue(item, keys[0], keys.slice(1));
        })
      }
      if (typeof arrayIndex === 'undefined') {
        result = fromObject.map(function (item) {
          return _getValue(item, keys[0], keys.slice(1));
        });
      } else {

        result = _getValue(fromObject[arrayIndex], keys[0], keys.slice(1));
      }
    } else {
      if (fromObject[key] === undefined) {
        result = _getGlobValues(fromObject, key, keys);
      } else {
        result = _getValue(fromObject[key], keys[0], keys.slice(1));
      }
    }
  }

  return result;
}

/**
 * Keeps recursing _getValue method with glob matching.
 * @param fromObject
 * @param key
 * @param keys
 * @returns {*}
 * @private
 */
function _getGlobValues(fromObject, key, keys) {
  var currentKeys = Object.keys(fromObject);
  var results = [];

  for (var i = 0; i < currentKeys.length; i++) {
    var currentKey = currentKeys[i];
    if (minimatch(currentKey, key)) {
      var value = keys.length ? _getValue(fromObject[currentKey], keys[0], keys.slice(1)) : fromObject[currentKey];
      if (value !== undefined) {
        results.push(value);
      }
    }
  }

  return results.length ? results : undefined;
}


/***/ }),

/***/ "./node_modules/object-mapper/src/object-mapper.js":
/*!*********************************************************!*\
  !*** ./node_modules/object-mapper/src/object-mapper.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var getKeyValue = __webpack_require__(/*! ./get-key-value */ "./node_modules/object-mapper/src/get-key-value.js")
  , setKeyValue = __webpack_require__(/*! ./set-key-value */ "./node_modules/object-mapper/src/set-key-value.js")
  , _undefined
  ;


/**
 * Map a object to another using the passed map
 * @param fromObject
 * @param toObject
 * @param propertyMap
 * @returns {*}
 * @constructor
 */
function ObjectMapper(fromObject, toObject, propertyMap) {
  var propertyKeys;

  if (typeof propertyMap === 'undefined') {
    propertyMap = toObject;
    toObject = _undefined;
  }

  if (typeof toObject === 'undefined') {
    toObject = {};
  }

  propertyKeys = Object.keys(propertyMap);

  return _map(fromObject, toObject, propertyMap, propertyKeys);
}
module.exports = ObjectMapper;
module.exports.merge = ObjectMapper;
module.exports.getKeyValue = getKeyValue;
module.exports.setKeyValue = setKeyValue;

/**
 * Function that handle each key from map
 * @param fromObject
 * @param toObject
 * @param propertyMap
 * @param propertyKeys
 * @returns {*}
 * @private
 * @recursive
 */
function _map(fromObject, toObject, propertyMap, propertyKeys) {
  var fromKey
    , toKey
    ;

  if (propertyKeys.length) {
    fromKey = propertyKeys.splice(0, 1)[0];
    if (propertyMap.hasOwnProperty(fromKey)) {
      toKey = propertyMap[fromKey];

      toObject = _mapKey(fromObject, fromKey, toObject, toKey);
    } else {
      toObject = null;
    }
    return _map(fromObject, toObject, propertyMap, propertyKeys);
  } else {
    return toObject;
  }
}

/**
 * Function that calls get and set key values
 * @param fromObject
 * @param fromKey
 * @param toObject
 * @param toKey
 * @private
 * @recursive
 */
function _mapKey(fromObject, fromKey, toObject, toKey) {
  var fromValue
    , restToKeys
    , _default = null
    , transform
    ;

  if (Array.isArray(toKey) && toKey.length) {
    toKey = toKey.slice();
    restToKeys = toKey.splice(1);
    toKey = toKey[0];
  }

  if (_isObject(toKey)) {
    _default = toKey.default || null;
    transform = toKey.transform;
    toKey = toKey.key;
  }

  if (Array.isArray(toKey)) {
    transform = toKey[1];
    _default = toKey[2] || null;
    toKey = toKey[0];
  }

  if (typeof _default === 'function') {
    _default = _default(fromObject, fromKey, toObject, toKey);
  }

  fromValue = getKeyValue(fromObject, fromKey);
  if (typeof fromValue === 'undefined' || fromValue === null) {
    fromValue = _default;
  }

  if (typeof fromValue !== 'undefined' && typeof transform === 'function') {
    fromValue = transform(fromValue, fromObject, toObject, fromKey, toKey);
  }

  if (typeof fromValue === 'undefined' || typeof toKey === 'undefined') {
    return toObject;
  }

  toObject = setKeyValue(toObject, toKey, fromValue);

  if (Array.isArray(restToKeys) && restToKeys.length) {
    toObject = _mapKey(fromObject, fromKey, toObject, restToKeys);
  }

  return toObject;
}

function _isObject (item) {
  return (typeof item === "object" && !Array.isArray(item) && item !== null)
}


/***/ }),

/***/ "./node_modules/object-mapper/src/set-key-value.js":
/*!*********************************************************!*\
  !*** ./node_modules/object-mapper/src/set-key-value.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * Make the set of a value withing the key in the passed object
 * @param baseObject
 * @param destinationKey
 * @param fromValue
 * @returns {*|{}}
 */
function SetKeyValue(baseObject, destinationKey, fromValue) {
  var merged = [];
  // matches only unescaped dots
  var regDot = /([^\\])(\\\\)*\./g;
  var keys = destinationKey.split(regDot);
  for (var i = 0; i < keys.length; i++) {
    if ((i - 1) % 3 === 0) {
      // Every third match is the character of
      // the first group [^\\] which
      // is the last character of the key.
      // Merge it in again.
      var tmpKey = keys[i - 1] + keys[i];
      if (keys[i + 1]) {
        // If second group is found, this means
        // that the backslash itself is escaped.
        // Retain unchanged as well.
        tmpKey += keys[i + 1];
      }
      merged.push(tmpKey.replace(/\\\./g, "."));
    }
    // Add part after last dot
    if (i === keys.length - 1) {
      merged.push(keys[i].replace(/\\\./g, "."));
    }
  }
  keys = merged;

  var key = keys.splice(0, 1);

  return _setValue(baseObject, key[0], keys, fromValue);
}
module.exports = SetKeyValue;

/**
 * Set the value within the passed object, considering if is a array or object set
 * @param destinationObject
 * @param key
 * @param keys
 * @param fromValue
 * @returns {*}
 * @private
 * @recursive
 */
function _setValue(destinationObject, key, keys, fromValue) {
  var regArray = /(\[\]|\[(.*)\])$/g
    , regAppendArray = /(\[\]|\[(.*)\]\+)$/g
    , regCanBeNull = /(\?)$/g
    , match
    , appendToArray
    , canBeNull
    , arrayIndex = 0
    , valueIndex
    , isPropertyArray = false
    , isValueArray = false
    , value
    ;

  canBeNull = regCanBeNull.test(key);
  if(canBeNull){
    key = key.replace(regCanBeNull, '');
  }

  match = regArray.exec(key);
  appendToArray = regAppendArray.exec(key);
  if (match) {
    isPropertyArray = true;
    key = key.replace(regArray, '');
    isValueArray = (key !== '');
  }

  if (appendToArray) {
    match = appendToArray;
    isPropertyArray = true;
    isValueArray = (key !== '');
    key = key.replace(regAppendArray, '');
  }

  if (_isEmpty(destinationObject)) {
    if (isPropertyArray) {
      arrayIndex = match[2] || 0;
      if (isValueArray) {
        destinationObject = {};
        destinationObject[key] = [];
      } else {
        destinationObject = [];
      }
    } else {
      destinationObject = {};
    }
  } else {
    if (isPropertyArray) {
      arrayIndex = match[2] || 0;
    }
  }
  if (keys.length === 0) {
    if(!canBeNull && (fromValue === null || fromValue === undefined)){
      return destinationObject;
    }
    if (isValueArray) {
      if (Array.isArray(destinationObject[key]) === false) {
        destinationObject[key] = [];
      }
      if(appendToArray){
          destinationObject[key].push(fromValue);
      } else{
        destinationObject[key][arrayIndex] = fromValue;
      }
    } else if (Array.isArray(destinationObject)) {
        destinationObject[arrayIndex] = fromValue;
    } else {
      destinationObject[key] = fromValue;
    }
  } else {
    if (isValueArray) {
      if (Array.isArray(destinationObject[key]) === false) {
        destinationObject[key] = [];
      }
      if (Array.isArray(fromValue) && _isNextArrayProperty(keys) === false) {
        for (valueIndex = 0; valueIndex < fromValue.length; valueIndex++) {
          value = fromValue[valueIndex];
          destinationObject[key][arrayIndex + valueIndex] = _setValue(destinationObject[key][arrayIndex + valueIndex], keys[0], keys.slice(1), value);
        }
      } else {
        destinationObject[key][arrayIndex] = _setValue(destinationObject[key][arrayIndex], keys[0], keys.slice(1), fromValue);
      }
    } else if (Array.isArray(destinationObject)) {
      if (Array.isArray(fromValue)) {
        for (valueIndex = 0; valueIndex < fromValue.length; valueIndex++) {
          value = fromValue[valueIndex];
          destinationObject[arrayIndex + valueIndex] = _setValue(destinationObject[arrayIndex + valueIndex], keys[0], keys.slice(1), value);
        }
      } else {
        destinationObject[arrayIndex] = _setValue(destinationObject[arrayIndex], keys[0], keys.slice(1), fromValue);
      }
    } else {
      destinationObject[key] = _setValue(destinationObject[key], keys[0], keys.slice(1), fromValue);
    }
  }


  return destinationObject;
}

/**
 * Check if next key is a array lookup
 * @param keys
 * @returns {boolean}
 * @private
 */
function _isNextArrayProperty(keys) {
  var regArray = /(\[\]|\[(.*)\])$/g
    ;
  return regArray.test(keys[0]);
}

/**
 * Check if passed object is empty, checking for object and array types
 * @param object
 * @returns {boolean}
 * @private
 */
function _isEmpty(object) {
  var empty = false;
  if (typeof object === 'undefined' || object === null) {
    empty = true;
  } else if (_isEmptyObject(object)) {
    empty = true;
  } else if (_isEmptyArray(object)) {
    empty = true;
  }

  return empty;
}

/**
 * Check if passed object is empty
 * @param object
 * @returns {boolean}
 * @private
 */
function _isEmptyObject(object) {
  return typeof object === 'object'
    && Array.isArray(object) === false
    && Object.keys(object).length === 0
    ;
}

/**
 * Check if passed array is empty or with empty values only
 * @param object
 * @returns {boolean}
 * @private
 */
function _isEmptyArray(object) {
  return Array.isArray(object)
    && (object.length === 0
    || object.join('').length === 0)
    ;
}


/***/ }),

/***/ "./node_modules/path/node_modules/util/support/isBufferBrowser.js":
/*!************************************************************************!*\
  !*** ./node_modules/path/node_modules/util/support/isBufferBrowser.js ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = function isBuffer(arg) {
  return arg && typeof arg === 'object'
    && typeof arg.copy === 'function'
    && typeof arg.fill === 'function'
    && typeof arg.readUInt8 === 'function';
}

/***/ }),

/***/ "./node_modules/path/node_modules/util/util.js":
/*!*****************************************************!*\
  !*** ./node_modules/path/node_modules/util/util.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.

var formatRegExp = /%[sdj%]/g;
exports.format = function(f) {
  if (!isString(f)) {
    var objects = [];
    for (var i = 0; i < arguments.length; i++) {
      objects.push(inspect(arguments[i]));
    }
    return objects.join(' ');
  }

  var i = 1;
  var args = arguments;
  var len = args.length;
  var str = String(f).replace(formatRegExp, function(x) {
    if (x === '%%') return '%';
    if (i >= len) return x;
    switch (x) {
      case '%s': return String(args[i++]);
      case '%d': return Number(args[i++]);
      case '%j':
        try {
          return JSON.stringify(args[i++]);
        } catch (_) {
          return '[Circular]';
        }
      default:
        return x;
    }
  });
  for (var x = args[i]; i < len; x = args[++i]) {
    if (isNull(x) || !isObject(x)) {
      str += ' ' + x;
    } else {
      str += ' ' + inspect(x);
    }
  }
  return str;
};


// Mark that a method should not be used.
// Returns a modified function which warns once by default.
// If --no-deprecation is set, then it is a no-op.
exports.deprecate = function(fn, msg) {
  // Allow for deprecating things in the process of starting up.
  if (isUndefined(global.process)) {
    return function() {
      return exports.deprecate(fn, msg).apply(this, arguments);
    };
  }

  if (process.noDeprecation === true) {
    return fn;
  }

  var warned = false;
  function deprecated() {
    if (!warned) {
      if (process.throwDeprecation) {
        throw new Error(msg);
      } else if (process.traceDeprecation) {
        console.trace(msg);
      } else {
        console.error(msg);
      }
      warned = true;
    }
    return fn.apply(this, arguments);
  }

  return deprecated;
};


var debugs = {};
var debugEnviron;
exports.debuglog = function(set) {
  if (isUndefined(debugEnviron))
    debugEnviron = process.env.NODE_DEBUG || '';
  set = set.toUpperCase();
  if (!debugs[set]) {
    if (new RegExp('\\b' + set + '\\b', 'i').test(debugEnviron)) {
      var pid = process.pid;
      debugs[set] = function() {
        var msg = exports.format.apply(exports, arguments);
        console.error('%s %d: %s', set, pid, msg);
      };
    } else {
      debugs[set] = function() {};
    }
  }
  return debugs[set];
};


/**
 * Echos the value of a value. Trys to print the value out
 * in the best way possible given the different types.
 *
 * @param {Object} obj The object to print out.
 * @param {Object} opts Optional options object that alters the output.
 */
/* legacy: obj, showHidden, depth, colors*/
function inspect(obj, opts) {
  // default options
  var ctx = {
    seen: [],
    stylize: stylizeNoColor
  };
  // legacy...
  if (arguments.length >= 3) ctx.depth = arguments[2];
  if (arguments.length >= 4) ctx.colors = arguments[3];
  if (isBoolean(opts)) {
    // legacy...
    ctx.showHidden = opts;
  } else if (opts) {
    // got an "options" object
    exports._extend(ctx, opts);
  }
  // set default options
  if (isUndefined(ctx.showHidden)) ctx.showHidden = false;
  if (isUndefined(ctx.depth)) ctx.depth = 2;
  if (isUndefined(ctx.colors)) ctx.colors = false;
  if (isUndefined(ctx.customInspect)) ctx.customInspect = true;
  if (ctx.colors) ctx.stylize = stylizeWithColor;
  return formatValue(ctx, obj, ctx.depth);
}
exports.inspect = inspect;


// http://en.wikipedia.org/wiki/ANSI_escape_code#graphics
inspect.colors = {
  'bold' : [1, 22],
  'italic' : [3, 23],
  'underline' : [4, 24],
  'inverse' : [7, 27],
  'white' : [37, 39],
  'grey' : [90, 39],
  'black' : [30, 39],
  'blue' : [34, 39],
  'cyan' : [36, 39],
  'green' : [32, 39],
  'magenta' : [35, 39],
  'red' : [31, 39],
  'yellow' : [33, 39]
};

// Don't use 'blue' not visible on cmd.exe
inspect.styles = {
  'special': 'cyan',
  'number': 'yellow',
  'boolean': 'yellow',
  'undefined': 'grey',
  'null': 'bold',
  'string': 'green',
  'date': 'magenta',
  // "name": intentionally not styling
  'regexp': 'red'
};


function stylizeWithColor(str, styleType) {
  var style = inspect.styles[styleType];

  if (style) {
    return '\u001b[' + inspect.colors[style][0] + 'm' + str +
           '\u001b[' + inspect.colors[style][1] + 'm';
  } else {
    return str;
  }
}


function stylizeNoColor(str, styleType) {
  return str;
}


function arrayToHash(array) {
  var hash = {};

  array.forEach(function(val, idx) {
    hash[val] = true;
  });

  return hash;
}


function formatValue(ctx, value, recurseTimes) {
  // Provide a hook for user-specified inspect functions.
  // Check that value is an object with an inspect function on it
  if (ctx.customInspect &&
      value &&
      isFunction(value.inspect) &&
      // Filter out the util module, it's inspect function is special
      value.inspect !== exports.inspect &&
      // Also filter out any prototype objects using the circular check.
      !(value.constructor && value.constructor.prototype === value)) {
    var ret = value.inspect(recurseTimes, ctx);
    if (!isString(ret)) {
      ret = formatValue(ctx, ret, recurseTimes);
    }
    return ret;
  }

  // Primitive types cannot have properties
  var primitive = formatPrimitive(ctx, value);
  if (primitive) {
    return primitive;
  }

  // Look up the keys of the object.
  var keys = Object.keys(value);
  var visibleKeys = arrayToHash(keys);

  if (ctx.showHidden) {
    keys = Object.getOwnPropertyNames(value);
  }

  // IE doesn't make error fields non-enumerable
  // http://msdn.microsoft.com/en-us/library/ie/dww52sbt(v=vs.94).aspx
  if (isError(value)
      && (keys.indexOf('message') >= 0 || keys.indexOf('description') >= 0)) {
    return formatError(value);
  }

  // Some type of object without properties can be shortcutted.
  if (keys.length === 0) {
    if (isFunction(value)) {
      var name = value.name ? ': ' + value.name : '';
      return ctx.stylize('[Function' + name + ']', 'special');
    }
    if (isRegExp(value)) {
      return ctx.stylize(RegExp.prototype.toString.call(value), 'regexp');
    }
    if (isDate(value)) {
      return ctx.stylize(Date.prototype.toString.call(value), 'date');
    }
    if (isError(value)) {
      return formatError(value);
    }
  }

  var base = '', array = false, braces = ['{', '}'];

  // Make Array say that they are Array
  if (isArray(value)) {
    array = true;
    braces = ['[', ']'];
  }

  // Make functions say that they are functions
  if (isFunction(value)) {
    var n = value.name ? ': ' + value.name : '';
    base = ' [Function' + n + ']';
  }

  // Make RegExps say that they are RegExps
  if (isRegExp(value)) {
    base = ' ' + RegExp.prototype.toString.call(value);
  }

  // Make dates with properties first say the date
  if (isDate(value)) {
    base = ' ' + Date.prototype.toUTCString.call(value);
  }

  // Make error with message first say the error
  if (isError(value)) {
    base = ' ' + formatError(value);
  }

  if (keys.length === 0 && (!array || value.length == 0)) {
    return braces[0] + base + braces[1];
  }

  if (recurseTimes < 0) {
    if (isRegExp(value)) {
      return ctx.stylize(RegExp.prototype.toString.call(value), 'regexp');
    } else {
      return ctx.stylize('[Object]', 'special');
    }
  }

  ctx.seen.push(value);

  var output;
  if (array) {
    output = formatArray(ctx, value, recurseTimes, visibleKeys, keys);
  } else {
    output = keys.map(function(key) {
      return formatProperty(ctx, value, recurseTimes, visibleKeys, key, array);
    });
  }

  ctx.seen.pop();

  return reduceToSingleString(output, base, braces);
}


function formatPrimitive(ctx, value) {
  if (isUndefined(value))
    return ctx.stylize('undefined', 'undefined');
  if (isString(value)) {
    var simple = '\'' + JSON.stringify(value).replace(/^"|"$/g, '')
                                             .replace(/'/g, "\\'")
                                             .replace(/\\"/g, '"') + '\'';
    return ctx.stylize(simple, 'string');
  }
  if (isNumber(value))
    return ctx.stylize('' + value, 'number');
  if (isBoolean(value))
    return ctx.stylize('' + value, 'boolean');
  // For some reason typeof null is "object", so special case here.
  if (isNull(value))
    return ctx.stylize('null', 'null');
}


function formatError(value) {
  return '[' + Error.prototype.toString.call(value) + ']';
}


function formatArray(ctx, value, recurseTimes, visibleKeys, keys) {
  var output = [];
  for (var i = 0, l = value.length; i < l; ++i) {
    if (hasOwnProperty(value, String(i))) {
      output.push(formatProperty(ctx, value, recurseTimes, visibleKeys,
          String(i), true));
    } else {
      output.push('');
    }
  }
  keys.forEach(function(key) {
    if (!key.match(/^\d+$/)) {
      output.push(formatProperty(ctx, value, recurseTimes, visibleKeys,
          key, true));
    }
  });
  return output;
}


function formatProperty(ctx, value, recurseTimes, visibleKeys, key, array) {
  var name, str, desc;
  desc = Object.getOwnPropertyDescriptor(value, key) || { value: value[key] };
  if (desc.get) {
    if (desc.set) {
      str = ctx.stylize('[Getter/Setter]', 'special');
    } else {
      str = ctx.stylize('[Getter]', 'special');
    }
  } else {
    if (desc.set) {
      str = ctx.stylize('[Setter]', 'special');
    }
  }
  if (!hasOwnProperty(visibleKeys, key)) {
    name = '[' + key + ']';
  }
  if (!str) {
    if (ctx.seen.indexOf(desc.value) < 0) {
      if (isNull(recurseTimes)) {
        str = formatValue(ctx, desc.value, null);
      } else {
        str = formatValue(ctx, desc.value, recurseTimes - 1);
      }
      if (str.indexOf('\n') > -1) {
        if (array) {
          str = str.split('\n').map(function(line) {
            return '  ' + line;
          }).join('\n').substr(2);
        } else {
          str = '\n' + str.split('\n').map(function(line) {
            return '   ' + line;
          }).join('\n');
        }
      }
    } else {
      str = ctx.stylize('[Circular]', 'special');
    }
  }
  if (isUndefined(name)) {
    if (array && key.match(/^\d+$/)) {
      return str;
    }
    name = JSON.stringify('' + key);
    if (name.match(/^"([a-zA-Z_][a-zA-Z_0-9]*)"$/)) {
      name = name.substr(1, name.length - 2);
      name = ctx.stylize(name, 'name');
    } else {
      name = name.replace(/'/g, "\\'")
                 .replace(/\\"/g, '"')
                 .replace(/(^"|"$)/g, "'");
      name = ctx.stylize(name, 'string');
    }
  }

  return name + ': ' + str;
}


function reduceToSingleString(output, base, braces) {
  var numLinesEst = 0;
  var length = output.reduce(function(prev, cur) {
    numLinesEst++;
    if (cur.indexOf('\n') >= 0) numLinesEst++;
    return prev + cur.replace(/\u001b\[\d\d?m/g, '').length + 1;
  }, 0);

  if (length > 60) {
    return braces[0] +
           (base === '' ? '' : base + '\n ') +
           ' ' +
           output.join(',\n  ') +
           ' ' +
           braces[1];
  }

  return braces[0] + base + ' ' + output.join(', ') + ' ' + braces[1];
}


// NOTE: These type checking functions intentionally don't use `instanceof`
// because it is fragile and can be easily faked with `Object.create()`.
function isArray(ar) {
  return Array.isArray(ar);
}
exports.isArray = isArray;

function isBoolean(arg) {
  return typeof arg === 'boolean';
}
exports.isBoolean = isBoolean;

function isNull(arg) {
  return arg === null;
}
exports.isNull = isNull;

function isNullOrUndefined(arg) {
  return arg == null;
}
exports.isNullOrUndefined = isNullOrUndefined;

function isNumber(arg) {
  return typeof arg === 'number';
}
exports.isNumber = isNumber;

function isString(arg) {
  return typeof arg === 'string';
}
exports.isString = isString;

function isSymbol(arg) {
  return typeof arg === 'symbol';
}
exports.isSymbol = isSymbol;

function isUndefined(arg) {
  return arg === void 0;
}
exports.isUndefined = isUndefined;

function isRegExp(re) {
  return isObject(re) && objectToString(re) === '[object RegExp]';
}
exports.isRegExp = isRegExp;

function isObject(arg) {
  return typeof arg === 'object' && arg !== null;
}
exports.isObject = isObject;

function isDate(d) {
  return isObject(d) && objectToString(d) === '[object Date]';
}
exports.isDate = isDate;

function isError(e) {
  return isObject(e) &&
      (objectToString(e) === '[object Error]' || e instanceof Error);
}
exports.isError = isError;

function isFunction(arg) {
  return typeof arg === 'function';
}
exports.isFunction = isFunction;

function isPrimitive(arg) {
  return arg === null ||
         typeof arg === 'boolean' ||
         typeof arg === 'number' ||
         typeof arg === 'string' ||
         typeof arg === 'symbol' ||  // ES6 symbol
         typeof arg === 'undefined';
}
exports.isPrimitive = isPrimitive;

exports.isBuffer = __webpack_require__(/*! ./support/isBuffer */ "./node_modules/path/node_modules/util/support/isBufferBrowser.js");

function objectToString(o) {
  return Object.prototype.toString.call(o);
}


function pad(n) {
  return n < 10 ? '0' + n.toString(10) : n.toString(10);
}


var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep',
              'Oct', 'Nov', 'Dec'];

// 26 Feb 16:19:34
function timestamp() {
  var d = new Date();
  var time = [pad(d.getHours()),
              pad(d.getMinutes()),
              pad(d.getSeconds())].join(':');
  return [d.getDate(), months[d.getMonth()], time].join(' ');
}


// log is just a thin wrapper to console.log that prepends a timestamp
exports.log = function() {
  console.log('%s - %s', timestamp(), exports.format.apply(exports, arguments));
};


/**
 * Inherit the prototype methods from one constructor into another.
 *
 * The Function.prototype.inherits from lang.js rewritten as a standalone
 * function (not on Function.prototype). NOTE: If this file is to be loaded
 * during bootstrapping this function needs to be rewritten using some native
 * functions as prototype setup using normal JavaScript does not work as
 * expected during bootstrapping (see mirror.js in r114903).
 *
 * @param {function} ctor Constructor function which needs to inherit the
 *     prototype.
 * @param {function} superCtor Constructor function to inherit prototype from.
 */
exports.inherits = __webpack_require__(/*! inherits */ "./node_modules/inherits/inherits_browser.js");

exports._extend = function(origin, add) {
  // Don't do anything if add isn't an object
  if (!add || !isObject(add)) return origin;

  var keys = Object.keys(add);
  var i = keys.length;
  while (i--) {
    origin[keys[i]] = add[keys[i]];
  }
  return origin;
};

function hasOwnProperty(obj, prop) {
  return Object.prototype.hasOwnProperty.call(obj, prop);
}


/***/ }),

/***/ "./node_modules/path/path.js":
/*!***********************************!*\
  !*** ./node_modules/path/path.js ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.




var isWindows = process.platform === 'win32';
var util = __webpack_require__(/*! util */ "./node_modules/path/node_modules/util/util.js");


// resolves . and .. elements in a path array with directory names there
// must be no slashes or device names (c:\) in the array
// (so also no leading and trailing slashes - it does not distinguish
// relative and absolute paths)
function normalizeArray(parts, allowAboveRoot) {
  var res = [];
  for (var i = 0; i < parts.length; i++) {
    var p = parts[i];

    // ignore empty parts
    if (!p || p === '.')
      continue;

    if (p === '..') {
      if (res.length && res[res.length - 1] !== '..') {
        res.pop();
      } else if (allowAboveRoot) {
        res.push('..');
      }
    } else {
      res.push(p);
    }
  }

  return res;
}

// returns an array with empty elements removed from either end of the input
// array or the original array if no elements need to be removed
function trimArray(arr) {
  var lastIndex = arr.length - 1;
  var start = 0;
  for (; start <= lastIndex; start++) {
    if (arr[start])
      break;
  }

  var end = lastIndex;
  for (; end >= 0; end--) {
    if (arr[end])
      break;
  }

  if (start === 0 && end === lastIndex)
    return arr;
  if (start > end)
    return [];
  return arr.slice(start, end + 1);
}

// Regex to split a windows path into three parts: [*, device, slash,
// tail] windows-only
var splitDeviceRe =
    /^([a-zA-Z]:|[\\\/]{2}[^\\\/]+[\\\/]+[^\\\/]+)?([\\\/])?([\s\S]*?)$/;

// Regex to split the tail part of the above into [*, dir, basename, ext]
var splitTailRe =
    /^([\s\S]*?)((?:\.{1,2}|[^\\\/]+?|)(\.[^.\/\\]*|))(?:[\\\/]*)$/;

var win32 = {};

// Function to split a filename into [root, dir, basename, ext]
function win32SplitPath(filename) {
  // Separate device+slash from tail
  var result = splitDeviceRe.exec(filename),
      device = (result[1] || '') + (result[2] || ''),
      tail = result[3] || '';
  // Split the tail into dir, basename and extension
  var result2 = splitTailRe.exec(tail),
      dir = result2[1],
      basename = result2[2],
      ext = result2[3];
  return [device, dir, basename, ext];
}

function win32StatPath(path) {
  var result = splitDeviceRe.exec(path),
      device = result[1] || '',
      isUnc = !!device && device[1] !== ':';
  return {
    device: device,
    isUnc: isUnc,
    isAbsolute: isUnc || !!result[2], // UNC paths are always absolute
    tail: result[3]
  };
}

function normalizeUNCRoot(device) {
  return '\\\\' + device.replace(/^[\\\/]+/, '').replace(/[\\\/]+/g, '\\');
}

// path.resolve([from ...], to)
win32.resolve = function() {
  var resolvedDevice = '',
      resolvedTail = '',
      resolvedAbsolute = false;

  for (var i = arguments.length - 1; i >= -1; i--) {
    var path;
    if (i >= 0) {
      path = arguments[i];
    } else if (!resolvedDevice) {
      path = process.cwd();
    } else {
      // Windows has the concept of drive-specific current working
      // directories. If we've resolved a drive letter but not yet an
      // absolute path, get cwd for that drive. We're sure the device is not
      // an unc path at this points, because unc paths are always absolute.
      path = process.env['=' + resolvedDevice];
      // Verify that a drive-local cwd was found and that it actually points
      // to our drive. If not, default to the drive's root.
      if (!path || path.substr(0, 3).toLowerCase() !==
          resolvedDevice.toLowerCase() + '\\') {
        path = resolvedDevice + '\\';
      }
    }

    // Skip empty and invalid entries
    if (!util.isString(path)) {
      throw new TypeError('Arguments to path.resolve must be strings');
    } else if (!path) {
      continue;
    }

    var result = win32StatPath(path),
        device = result.device,
        isUnc = result.isUnc,
        isAbsolute = result.isAbsolute,
        tail = result.tail;

    if (device &&
        resolvedDevice &&
        device.toLowerCase() !== resolvedDevice.toLowerCase()) {
      // This path points to another device so it is not applicable
      continue;
    }

    if (!resolvedDevice) {
      resolvedDevice = device;
    }
    if (!resolvedAbsolute) {
      resolvedTail = tail + '\\' + resolvedTail;
      resolvedAbsolute = isAbsolute;
    }

    if (resolvedDevice && resolvedAbsolute) {
      break;
    }
  }

  // Convert slashes to backslashes when `resolvedDevice` points to an UNC
  // root. Also squash multiple slashes into a single one where appropriate.
  if (isUnc) {
    resolvedDevice = normalizeUNCRoot(resolvedDevice);
  }

  // At this point the path should be resolved to a full absolute path,
  // but handle relative paths to be safe (might happen when process.cwd()
  // fails)

  // Normalize the tail path
  resolvedTail = normalizeArray(resolvedTail.split(/[\\\/]+/),
                                !resolvedAbsolute).join('\\');

  return (resolvedDevice + (resolvedAbsolute ? '\\' : '') + resolvedTail) ||
         '.';
};


win32.normalize = function(path) {
  var result = win32StatPath(path),
      device = result.device,
      isUnc = result.isUnc,
      isAbsolute = result.isAbsolute,
      tail = result.tail,
      trailingSlash = /[\\\/]$/.test(tail);

  // Normalize the tail path
  tail = normalizeArray(tail.split(/[\\\/]+/), !isAbsolute).join('\\');

  if (!tail && !isAbsolute) {
    tail = '.';
  }
  if (tail && trailingSlash) {
    tail += '\\';
  }

  // Convert slashes to backslashes when `device` points to an UNC root.
  // Also squash multiple slashes into a single one where appropriate.
  if (isUnc) {
    device = normalizeUNCRoot(device);
  }

  return device + (isAbsolute ? '\\' : '') + tail;
};


win32.isAbsolute = function(path) {
  return win32StatPath(path).isAbsolute;
};

win32.join = function() {
  var paths = [];
  for (var i = 0; i < arguments.length; i++) {
    var arg = arguments[i];
    if (!util.isString(arg)) {
      throw new TypeError('Arguments to path.join must be strings');
    }
    if (arg) {
      paths.push(arg);
    }
  }

  var joined = paths.join('\\');

  // Make sure that the joined path doesn't start with two slashes, because
  // normalize() will mistake it for an UNC path then.
  //
  // This step is skipped when it is very clear that the user actually
  // intended to point at an UNC path. This is assumed when the first
  // non-empty string arguments starts with exactly two slashes followed by
  // at least one more non-slash character.
  //
  // Note that for normalize() to treat a path as an UNC path it needs to
  // have at least 2 components, so we don't filter for that here.
  // This means that the user can use join to construct UNC paths from
  // a server name and a share name; for example:
  //   path.join('//server', 'share') -> '\\\\server\\share\')
  if (!/^[\\\/]{2}[^\\\/]/.test(paths[0])) {
    joined = joined.replace(/^[\\\/]{2,}/, '\\');
  }

  return win32.normalize(joined);
};


// path.relative(from, to)
// it will solve the relative path from 'from' to 'to', for instance:
// from = 'C:\\orandea\\test\\aaa'
// to = 'C:\\orandea\\impl\\bbb'
// The output of the function should be: '..\\..\\impl\\bbb'
win32.relative = function(from, to) {
  from = win32.resolve(from);
  to = win32.resolve(to);

  // windows is not case sensitive
  var lowerFrom = from.toLowerCase();
  var lowerTo = to.toLowerCase();

  var toParts = trimArray(to.split('\\'));

  var lowerFromParts = trimArray(lowerFrom.split('\\'));
  var lowerToParts = trimArray(lowerTo.split('\\'));

  var length = Math.min(lowerFromParts.length, lowerToParts.length);
  var samePartsLength = length;
  for (var i = 0; i < length; i++) {
    if (lowerFromParts[i] !== lowerToParts[i]) {
      samePartsLength = i;
      break;
    }
  }

  if (samePartsLength == 0) {
    return to;
  }

  var outputParts = [];
  for (var i = samePartsLength; i < lowerFromParts.length; i++) {
    outputParts.push('..');
  }

  outputParts = outputParts.concat(toParts.slice(samePartsLength));

  return outputParts.join('\\');
};


win32._makeLong = function(path) {
  // Note: this will *probably* throw somewhere.
  if (!util.isString(path))
    return path;

  if (!path) {
    return '';
  }

  var resolvedPath = win32.resolve(path);

  if (/^[a-zA-Z]\:\\/.test(resolvedPath)) {
    // path is local filesystem path, which needs to be converted
    // to long UNC path.
    return '\\\\?\\' + resolvedPath;
  } else if (/^\\\\[^?.]/.test(resolvedPath)) {
    // path is network UNC path, which needs to be converted
    // to long UNC path.
    return '\\\\?\\UNC\\' + resolvedPath.substring(2);
  }

  return path;
};


win32.dirname = function(path) {
  var result = win32SplitPath(path),
      root = result[0],
      dir = result[1];

  if (!root && !dir) {
    // No dirname whatsoever
    return '.';
  }

  if (dir) {
    // It has a dirname, strip trailing slash
    dir = dir.substr(0, dir.length - 1);
  }

  return root + dir;
};


win32.basename = function(path, ext) {
  var f = win32SplitPath(path)[2];
  // TODO: make this comparison case-insensitive on windows?
  if (ext && f.substr(-1 * ext.length) === ext) {
    f = f.substr(0, f.length - ext.length);
  }
  return f;
};


win32.extname = function(path) {
  return win32SplitPath(path)[3];
};


win32.format = function(pathObject) {
  if (!util.isObject(pathObject)) {
    throw new TypeError(
        "Parameter 'pathObject' must be an object, not " + typeof pathObject
    );
  }

  var root = pathObject.root || '';

  if (!util.isString(root)) {
    throw new TypeError(
        "'pathObject.root' must be a string or undefined, not " +
        typeof pathObject.root
    );
  }

  var dir = pathObject.dir;
  var base = pathObject.base || '';
  if (!dir) {
    return base;
  }
  if (dir[dir.length - 1] === win32.sep) {
    return dir + base;
  }
  return dir + win32.sep + base;
};


win32.parse = function(pathString) {
  if (!util.isString(pathString)) {
    throw new TypeError(
        "Parameter 'pathString' must be a string, not " + typeof pathString
    );
  }
  var allParts = win32SplitPath(pathString);
  if (!allParts || allParts.length !== 4) {
    throw new TypeError("Invalid path '" + pathString + "'");
  }
  return {
    root: allParts[0],
    dir: allParts[0] + allParts[1].slice(0, -1),
    base: allParts[2],
    ext: allParts[3],
    name: allParts[2].slice(0, allParts[2].length - allParts[3].length)
  };
};


win32.sep = '\\';
win32.delimiter = ';';


// Split a filename into [root, dir, basename, ext], unix version
// 'root' is just a slash, or nothing.
var splitPathRe =
    /^(\/?|)([\s\S]*?)((?:\.{1,2}|[^\/]+?|)(\.[^.\/]*|))(?:[\/]*)$/;
var posix = {};


function posixSplitPath(filename) {
  return splitPathRe.exec(filename).slice(1);
}


// path.resolve([from ...], to)
// posix version
posix.resolve = function() {
  var resolvedPath = '',
      resolvedAbsolute = false;

  for (var i = arguments.length - 1; i >= -1 && !resolvedAbsolute; i--) {
    var path = (i >= 0) ? arguments[i] : process.cwd();

    // Skip empty and invalid entries
    if (!util.isString(path)) {
      throw new TypeError('Arguments to path.resolve must be strings');
    } else if (!path) {
      continue;
    }

    resolvedPath = path + '/' + resolvedPath;
    resolvedAbsolute = path[0] === '/';
  }

  // At this point the path should be resolved to a full absolute path, but
  // handle relative paths to be safe (might happen when process.cwd() fails)

  // Normalize the path
  resolvedPath = normalizeArray(resolvedPath.split('/'),
                                !resolvedAbsolute).join('/');

  return ((resolvedAbsolute ? '/' : '') + resolvedPath) || '.';
};

// path.normalize(path)
// posix version
posix.normalize = function(path) {
  var isAbsolute = posix.isAbsolute(path),
      trailingSlash = path && path[path.length - 1] === '/';

  // Normalize the path
  path = normalizeArray(path.split('/'), !isAbsolute).join('/');

  if (!path && !isAbsolute) {
    path = '.';
  }
  if (path && trailingSlash) {
    path += '/';
  }

  return (isAbsolute ? '/' : '') + path;
};

// posix version
posix.isAbsolute = function(path) {
  return path.charAt(0) === '/';
};

// posix version
posix.join = function() {
  var path = '';
  for (var i = 0; i < arguments.length; i++) {
    var segment = arguments[i];
    if (!util.isString(segment)) {
      throw new TypeError('Arguments to path.join must be strings');
    }
    if (segment) {
      if (!path) {
        path += segment;
      } else {
        path += '/' + segment;
      }
    }
  }
  return posix.normalize(path);
};


// path.relative(from, to)
// posix version
posix.relative = function(from, to) {
  from = posix.resolve(from).substr(1);
  to = posix.resolve(to).substr(1);

  var fromParts = trimArray(from.split('/'));
  var toParts = trimArray(to.split('/'));

  var length = Math.min(fromParts.length, toParts.length);
  var samePartsLength = length;
  for (var i = 0; i < length; i++) {
    if (fromParts[i] !== toParts[i]) {
      samePartsLength = i;
      break;
    }
  }

  var outputParts = [];
  for (var i = samePartsLength; i < fromParts.length; i++) {
    outputParts.push('..');
  }

  outputParts = outputParts.concat(toParts.slice(samePartsLength));

  return outputParts.join('/');
};


posix._makeLong = function(path) {
  return path;
};


posix.dirname = function(path) {
  var result = posixSplitPath(path),
      root = result[0],
      dir = result[1];

  if (!root && !dir) {
    // No dirname whatsoever
    return '.';
  }

  if (dir) {
    // It has a dirname, strip trailing slash
    dir = dir.substr(0, dir.length - 1);
  }

  return root + dir;
};


posix.basename = function(path, ext) {
  var f = posixSplitPath(path)[2];
  // TODO: make this comparison case-insensitive on windows?
  if (ext && f.substr(-1 * ext.length) === ext) {
    f = f.substr(0, f.length - ext.length);
  }
  return f;
};


posix.extname = function(path) {
  return posixSplitPath(path)[3];
};


posix.format = function(pathObject) {
  if (!util.isObject(pathObject)) {
    throw new TypeError(
        "Parameter 'pathObject' must be an object, not " + typeof pathObject
    );
  }

  var root = pathObject.root || '';

  if (!util.isString(root)) {
    throw new TypeError(
        "'pathObject.root' must be a string or undefined, not " +
        typeof pathObject.root
    );
  }

  var dir = pathObject.dir ? pathObject.dir + posix.sep : '';
  var base = pathObject.base || '';
  return dir + base;
};


posix.parse = function(pathString) {
  if (!util.isString(pathString)) {
    throw new TypeError(
        "Parameter 'pathString' must be a string, not " + typeof pathString
    );
  }
  var allParts = posixSplitPath(pathString);
  if (!allParts || allParts.length !== 4) {
    throw new TypeError("Invalid path '" + pathString + "'");
  }
  allParts[1] = allParts[1] || '';
  allParts[2] = allParts[2] || '';
  allParts[3] = allParts[3] || '';

  return {
    root: allParts[0],
    dir: allParts[0] + allParts[1].slice(0, -1),
    base: allParts[2],
    ext: allParts[3],
    name: allParts[2].slice(0, allParts[2].length - allParts[3].length)
  };
};


posix.sep = '/';
posix.delimiter = ':';


if (isWindows)
  module.exports = win32;
else /* posix */
  module.exports = posix;

module.exports.posix = posix;
module.exports.win32 = win32;


/***/ }),

/***/ "./src/app/water-analysis/components/water-analysis-detail/water-analysis-detail.component.html":
/*!******************************************************************************************************!*\
  !*** ./src/app/water-analysis/components/water-analysis-detail/water-analysis-detail.component.html ***!
  \******************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">\r\n    <div class=\"col-12\">\r\n        <div *ngIf=\"model\" class=\"card\" [ngClass]=\"{'sld-card-warning': model.status === 'New', 'sld-card-info':  model.status === 'InProgress', 'sld-card-success':  model.status === 'Completed', 'sld-card-danger':  model.status === 'Cancelled'}\">\r\n            <div class=\"card-body\">\r\n                <div class=\"row\">\r\n                    <div class=\"col-12\">\r\n                        <div class=\"row\">\r\n                            <div class=\"col-lg-5 col-md-12\">\r\n                                <h4 class=\"card-title mb-0 text-primary\">\r\n                                    <fa-icon icon=\"tint\" [ngClass]=\"{'text-warning': model.status === 'New', 'text-info': model.status === 'InProgress', 'text-success': model.status === 'Completed', 'text-danger': model.status === 'Cancelled'}\">\r\n                                    </fa-icon>\r\n                                    H<sub>2</sub>O Analysis - <span class=\"font-weight-bold\">{{ model.labSample?.loginNo }}</span>\r\n\r\n                                    <span [hidden]=\"statusChange\" class=\"badge ml-2\" (click)=\"toggleState();\" [ngClass]=\"{'badge-warning': model.status === 'New', 'badge-info': model.status === 'InProgress', 'badge-success': model.status === 'Completed', 'badge-danger': model.status === 'Cancelled'}\">{{model.status}}</span>\r\n                                    <div class=\"keep-in-line col-md-4\">\r\n                                        <ng-select [hidden]=\"!statusChange\" class=\"small ml-4\" [items]=\"stateList\" [(ngModel)]='model.status' (change)='onStateChanged()'>\r\n                                        </ng-select>\r\n                                    </div>\r\n                                </h4>\r\n\r\n                                <div class=\"small text-muted\">Created on {{ model.createdOn | date }} by {{ model.createdBy }}, last updated on {{ model.modifiedOn | date }} by {{ model.modifiedBy }}</div>\r\n                            </div>\r\n                            <div class=\"col-lg-7 col-md-12\">\r\n                                <div class=\"btn-toolbar float-right\" role=\"toolbar\" aria-label=\"Toolbar\">\r\n                                    <a class=\"btn btn-sm btn-outline-primary ml-1 mt-1\" [routerLink]=\"[ '/water-analysis/' ]\">\r\n                                        <fa-icon icon=\"arrow-circle-left\"></fa-icon> Return to list\r\n                                    </a>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <hr>\r\n                <div class=\"row\">\r\n                    <div class=\"col-12\">\r\n                        <ngb-tabset [activeId]=\"tab\">\r\n                            <ngb-tab [id]=\"0\">\r\n\r\n                                <ng-template ngbTabTitle>\r\n\r\n                                    <span class=\"text-primary\">\r\n                    <fa-icon icon=\"info-circle\"></fa-icon> General\r\n                  </span>\r\n                                </ng-template>\r\n                                <ng-template ngbTabContent>\r\n                                    <form #waterAnalForm=\"ngForm\" autocomplete=\"off\" (ngSubmit)=\"save(waterAnalForm.value)\">\r\n                                        <div class=\"row\">\r\n                                            <div class=\"col-12\">\r\n                                                <div *ngIf=\"readonly\" class=\"btn-toolbar float-right mb-2\" role=\"toolbar\" aria-label=\"Toolbar\">\r\n\r\n                                                    <button type=\"button\" class=\"btn btn-sm btn-outline-primary ml-1\" (click)=\"edit()\">\r\n                            <fa-icon icon=\"edit\"></fa-icon> Edit\r\n                          </button>\r\n                                                </div>\r\n                                                <div [hidden]=\"readonly\" class=\"btn-toolbar float-right mb-2\" role=\"toolbar\" aria-label=\"Toolbar\">\r\n                                                    <span (mouseenter)=\"mouseoverSave=true\" (mouseleave)=\"mouseoverSave=false\">\r\n                            <button [disabled]=\"waterAnalForm.invalid\" type=\"submit\" class=\"btn btn-sm btn-success ml-1\">\r\n                              <fa-icon icon=\"save\"></fa-icon> Save\r\n                            </button></span>\r\n                                                    <button type=\"button\" class=\"btn btn-sm btn-outline-primary ml-1\" (click)=\"cancel()\">\r\n                            <fa-icon icon=\"times-circle\"></fa-icon> Cancel\r\n                          </button>\r\n                                                </div>\r\n                                            </div>\r\n                                        </div>\r\n                                        <div class=\"form-row\">\r\n                                            <div class=\"form-group col-sm-12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"clientName\">\r\n                          <fa-icon icon=\"industry\"></fa-icon> sales Rep\r\n                        </label>\r\n                                                <em *ngIf=\"waterAnalForm.controls.salesRep?.invalid && (waterAnalForm.controls.salesRep?.touched || mouseoverSave)\">Required</em>\r\n                                                <input [hidden]=\"!readonly\" readonly [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"salesRep\" type=\"text\" [(ngModel)]=\"model.salesRep\" name=\"salesRep\">\r\n                                                <ng-select autofocus [hidden]=\"readonly\" [items]=\"staffList\" [typeahead]=\"selectStaffInput\" [loading]=\"selectStaffPreLoading\" bindLabel=\"userName\" bindValue=\"userName\" [(ngModel)]=\"model.salesRep\" name=\"salesRep\" required>\r\n                                                </ng-select>\r\n                                            </div>\r\n                                            <div class=\"form-group col-sm12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"labanalyst\">\r\n                          <fa-icon icon=\"calendar-alt\"></fa-icon> Lab Analyst\r\n                        </label>\r\n                                                <em *ngIf=\"waterAnalForm.controls.labAnalyst?.invalid && (waterAnalForm.controls.labAnalyst?.touched || mouseoverSave)\">Required</em>\r\n                                                <input [hidden]=\"!readonly\" readonly [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"labAnalyst\" type=\"text\" [(ngModel)]=\"model.labAnalyst\" name=\"labAnalyst\">\r\n                                                <ng-select [hidden]=\"readonly\" [items]=\"staffList\" [typeahead]=\"selectStaffInput\" [loading]=\"selectStaffPreLoading\" bindLabel=\"userName\" bindValue=\"userName\" [(ngModel)]=\"model.labAnalyst\" name=\"labAnalyst\" required>\r\n                                                </ng-select>\r\n                                            </div>\r\n                                            <div class=\"form-group col-sm-12 col-md-3\">\r\n                                            </div>\r\n                                        </div>\r\n                                        <div class=\"form-row\">\r\n\r\n                                            <div class=\"form-group col-sm-12 col-md-6\">\r\n                                                <label class=\"small font-weight-bold\" for=\"notes\">\r\n                          <fa-icon icon=\"industry\"></fa-icon> Notes\r\n                        </label>\r\n                                                <textarea [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"notes\" type=\"text\" [(ngModel)]=\"model.notes\" name=\"notes\"></textarea>\r\n                                            </div>\r\n                                            <div class=\"form-group col-sm-12 col-md-3\">\r\n\r\n                                            </div>\r\n\r\n                                        </div>\r\n\r\n                                    </form>\r\n                                </ng-template>\r\n\r\n                            </ngb-tab>\r\n                            <ngb-tab [id]=\"1\" *ngIf=\"!newrequest\">\r\n                                <ng-template ngbTabTitle><span class=\"text-primary\">\r\n                    <fa-icon icon=\"info-circle\"></fa-icon> Analysis\r\n                  </span></ng-template>\r\n                                <ng-template ngbTabContent>\r\n                                    <div class=\"row\">\r\n                                        <div class=\"col-12\">\r\n\r\n                                            <div *ngIf=\"readonly\" class=\"btn-toolbar float-right mb-2\" role=\"toolbar\" aria-label=\"Toolbar\">\r\n                                                <button type=\"button\" class=\"btn btn-sm btn-outline-primary ml-1\" (click)=\"downloadChart()\">\r\n                                                            <fa-icon [hidden]=\"isDownloading\" icon=\"download\"></fa-icon>\r\n                                                            <fa-icon [hidden]=\"!isDownloading\" icon=\"circle-notch\" [spin]=\"true\"></fa-icon> Download Chart Creator\r\n                                                          </button>\r\n                                                <button type=\"button\" class=\"btn btn-sm btn-outline-primary ml-1\" (click)=\"download()\">\r\n                                                            <fa-icon [hidden]=\"isDownloading\" icon=\"download\"></fa-icon>\r\n                                                            <fa-icon [hidden]=\"!isDownloading\" icon=\"circle-notch\" [spin]=\"true\"></fa-icon> Download Result\r\n                                                          </button>\r\n                                                <button type=\"button\" class=\"btn btn-sm btn-outline-primary ml-1\" (click)=\"edit()\">\r\n                          <fa-icon icon=\"edit\"></fa-icon> Edit\r\n                        </button>\r\n                                            </div>\r\n                                            <div [hidden]=\"readonly\" class=\"btn-toolbar float-right mb-2\" role=\"toolbar\" aria-label=\"Toolbar\">\r\n                                                <span (mouseenter)=\"mouseoverSave=true\" (mouseleave)=\"mouseoverSave=false\">\r\n                          <button type=\"button\" class=\"btn btn-sm btn-success ml-1\" (click)=\"save()\">\r\n                            <fa-icon icon=\"save\"></fa-icon> Save\r\n                          </button></span>\r\n                                                <button type=\"button\" class=\"btn btn-sm btn-outline-primary ml-1\" (click)=\"cancel()\">\r\n                          <fa-icon icon=\"times-circle\"></fa-icon> Cancel\r\n                        </button>\r\n                                            </div>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div class=\"form-row\">\r\n\r\n                                        <div class=\"form-group col-sm-12 col-md-3\">\r\n                                            <label class=\"small font-weight-bold\" for=\"clientName\">\r\n                        <fa-icon icon=\"industry\"></fa-icon> Analysis Method\r\n                      </label>\r\n                                            <input readonly class=\"form-control-plaintext\" id=\"analysisMethod\" type=\"text\" [(ngModel)]=\"model.analysisMethod\" name=\"analysisMethod\">\r\n                                        </div>\r\n                                        <div class=\"form-group col-sm12 col-md-3\">\r\n                                            <label class=\"small font-weight-bold\" for=\"clientServiceRepresentative\">\r\n                        <fa-icon icon=\"address-card\"></fa-icon> ph\r\n                      </label>\r\n                                            <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"ph\" type=\"number\" [(ngModel)]=\"model.ph\" name=\"ph\">\r\n                                        </div>\r\n                                        <div class=\"form-group col-sm-12 col-md-3\">\r\n                                            <label class=\"small font-weight-bold\" for=\"programNumber\">\r\n                            <fa-icon icon=\"hashtag\"></fa-icon> H<sub>2</sub>S Present\r\n                          </label>\r\n                                            <div class=\"col-3\">\r\n                                                <label [hidden]=\"!readonly\" class=\"switch switch-label switch-success small ml-1\" onclick=\"return false;\">\r\n                              <input class=\"switch-input\" type=\"checkbox\" [(ngModel)]=\"model.isH2SPresent\" (change)=\"makeReadOnly('opr')\" name=\"isH2SPresent\">\r\n                              <span class=\"switch-slider\" data-checked=\"Yes\" data-unchecked=\"No\"></span>\r\n                            </label>\r\n                                                <label [hidden]=\"readonly\" class=\"switch switch-label switch-success small ml-1\">\r\n                              <input class=\"switch-input\" type=\"checkbox\" [(ngModel)]=\"model.isH2SPresent\" name=\"isH2SPresent\">\r\n                              <span class=\"switch-slider\" data-checked=\"Yes\" data-unchecked=\"No\"></span>\r\n                            </label>\r\n                                            </div>\r\n                                        </div>\r\n                                        <div class=\"form-group col-sm12 col-md-3\">\r\n                                            <label class=\"small font-weight-bold\" for=\"name\">\r\n                            <fa-icon icon=\"calendar-alt\"></fa-icon> pAlkanity (mg/L as CaCO3)\r\n                          </label>\r\n                                            <div class=\"input-group\">\r\n                                                <div class=\"d-flex bd-highlight\">\r\n                                                    <div class=\"p-2 flex-grow-1 bd-highlight\">\r\n                                                        <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"pAlkanity\" type=\"number\" [(ngModel)]=\"model.pAlkanity\" name=\"pAlkanity\">\r\n                                                    </div>\r\n                                                    <div class=\"p-2 m-2 bd-highlight small font-weight-bold\"></div>\r\n                                                </div>\r\n\r\n                                            </div>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div class=\"form-row\">\r\n                                        <div class=\"form-group col-sm-12 col-md-3\">\r\n                                            <label class=\"small font-weight-bold\" for=\"clientName\">\r\n                        <fa-icon icon=\"industry\"></fa-icon> tAlkanity (mg/L as CaCO<sub>3</sub>)\r\n                      </label>\r\n                                            <div class=\"input-group\">\r\n                                                <div class=\"d-flex bd-highlight\">\r\n                                                    <div class=\"p-2 flex-grow-1 bd-highlight\">\r\n                                                        <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"tAlkanity\" type=\"text\" [(ngModel)]=\"model.tAlkanity\" name=\"tAlkanity\">\r\n                                                    </div>\r\n                                                    <div class=\"p-2 m-2 bd-highlight small font-weight-bold\"></div>\r\n                                                </div>\r\n                                            </div>\r\n\r\n                                        </div>\r\n                                        <div class=\"form-group col-sm12 col-md-3\">\r\n                                            <label class=\"small font-weight-bold\" for=\"clientServiceRepresentative\">\r\n                        <fa-icon icon=\"address-card\"></fa-icon> hydroxide (mg/L as CaCO<sub>3</sub>)\r\n                      </label>\r\n                                            <div class=\"input-group\">\r\n                                                <div class=\"d-flex bd-highlight\">\r\n                                                    <div class=\"p-2 flex-grow-1 bd-highlight\"><input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"hydroxide\" type=\"number\" [(ngModel)]=\"model.hydroxide\" name=\"hydroxide\"></div>\r\n                                                    <div class=\"p-2 m-2 bd-highlight small font-weight-bold\"></div>\r\n                                                </div>\r\n                                            </div>\r\n\r\n                                        </div>\r\n                                        <div class=\"form-group col-sm-12 col-md-3\">\r\n                                            <label class=\"small font-weight-bold\" for=\"programNumber\">\r\n                            <fa-icon icon=\"hashtag\"></fa-icon> carbonate (mg/L as CaCO<sub>3</sub>)\r\n                          </label>\r\n                                            <div class=\"input-group\">\r\n                                                <div class=\"d-flex bd-highlight\">\r\n                                                    <div class=\"p-2 flex-grow-1 bd-highlight\">\r\n                                                        <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"carbonate\" type=\"number\" [(ngModel)]=\"model.carbonate\" name=\"carbonate\">\r\n                                                    </div>\r\n                                                    <div class=\"p-2 m-2 bd-highlight small font-weight-bold\"></div>\r\n                                                </div>\r\n\r\n                                            </div>\r\n                                        </div>\r\n                                        <div class=\"form-group col-sm12 col-md-3\">\r\n                                            <label class=\"small font-weight-bold\" for=\"name\">\r\n                            <fa-icon icon=\"calendar-alt\"></fa-icon> bicarbonate (mg/L as CaCO<sub>3</sub>)\r\n                          </label>\r\n                                            <div class=\"input-group\">\r\n                                                <div class=\"d-flex bd-highlight\">\r\n                                                    <div class=\"p-2 flex-grow-1 bd-highlight\">\r\n                                                        <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"bicarbonate\" type=\"number\" [(ngModel)]=\"model.bicarbonate\" name=\"bicarbonate\">\r\n                                                    </div>\r\n                                                    <div class=\"p-2 m-2 bd-highlight small font-weight-bold\"></div>\r\n                                                </div>\r\n\r\n                                            </div>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div class=\"form-row\">\r\n                                        <div class=\"form-group col-sm-12 col-md-3\">\r\n                                            <label class=\"small font-weight-bold\" for=\"clientName\">\r\n                        <fa-icon icon=\"industry\"></fa-icon> chloride (mg/L)\r\n                      </label>\r\n                                            <div class=\"input-group\">\r\n                                                <div class=\"d-flex bd-highlight\">\r\n                                                    <div class=\"p-2 flex-grow-1 bd-highlight\">\r\n                                                        <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"chloride\" type=\"text\" [(ngModel)]=\"model.chloride\" name=\"chloride\">\r\n                                                    </div>\r\n                                                    <div class=\"p-2 m-2 bd-highlight small font-weight-bold\"></div>\r\n                                                </div>\r\n                                            </div>\r\n                                        </div>\r\n                                        <div class=\"form-group col-sm12 col-md-3\">\r\n                                            <label class=\"small font-weight-bold\" for=\"clientServiceRepresentative\">\r\n                        <fa-icon icon=\"address-card\"></fa-icon> sulfate (mg/L)\r\n                      </label>\r\n                                            <div class=\"input-group\">\r\n                                                <div class=\"d-flex bd-highlight\">\r\n                                                    <div class=\"p-2 flex-grow-1 bd-highlight\">\r\n                                                        <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"sulfate\" type=\"number\" [(ngModel)]=\"model.sulfate\" name=\"sulfate\">\r\n                                                    </div>\r\n                                                    <div class=\"p-2 m-2 bd-highlight small font-weight-bold\"></div>\r\n                                                </div>\r\n                                            </div>\r\n                                        </div>\r\n                                        <div class=\"form-group col-sm-12 col-md-3\">\r\n                                            <label class=\"small font-weight-bold\" for=\"programNumber\">\r\n                            <fa-icon icon=\"hashtag\"></fa-icon> calcium (mg/L)\r\n                          </label>\r\n                                            <div class=\"input-group\">\r\n                                                <div class=\"d-flex bd-highlight\">\r\n                                                    <div class=\"p-2 flex-grow-1 bd-highlight\">\r\n                                                        <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"calcium\" type=\"number\" [(ngModel)]=\"model.calcium\" name=\"calcium\">\r\n                                                    </div>\r\n                                                    <div class=\"p-2 m-2 bd-highlight small font-weight-bold\"></div>\r\n                                                </div>\r\n\r\n                                            </div>\r\n                                        </div>\r\n                                        <div class=\"form-group col-sm12 col-md-3\">\r\n                                            <label class=\"small font-weight-bold\" for=\"programNumber\">\r\n                                                            <fa-icon icon=\"hashtag\"></fa-icon> Within Specs\r\n                                                          </label>\r\n                                            <div class=\"col-3\">\r\n                                                <label [hidden]=\"!readonly\" class=\"switch switch-label switch-success small ml-1\" onclick=\"return false;\">\r\n                                                              <input class=\"switch-input\" type=\"checkbox\" [(ngModel)]=\"model.withinSpecs\" (change)=\"makeReadOnly('')\" name=\"withinSpecs\">\r\n                                                              <span class=\"switch-slider\" data-checked=\"Yes\" data-unchecked=\"No\"></span>\r\n                                                            </label>\r\n                                                <label [hidden]=\"readonly\" class=\"switch switch-label switch-success small ml-1\">\r\n                                                              <input class=\"switch-input\" type=\"checkbox\" [(ngModel)]=\"model.withinSpecs\" name=\"withinSpecs\">\r\n                                                              <span class=\"switch-slider\" data-checked=\"Yes\" data-unchecked=\"No\"></span>\r\n                                                            </label>\r\n                                            </div>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div class=\"form-row\">\r\n\r\n                                        <div class=\"form-group col-sm-12 col-md-3\">\r\n                                            <label class=\"small font-weight-bold\" for=\"clientName\">\r\n                        <fa-icon icon=\"industry\"></fa-icon> magnesium (mg/L)\r\n                      </label>\r\n                                            <div class=\"input-group\">\r\n                                                <div class=\"d-flex bd-highlight\">\r\n                                                    <div class=\"p-2 flex-grow-1 bd-highlight\">\r\n                                                        <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"magnesium\" type=\"number\" [(ngModel)]=\"model.magnesium\" name=\"magnesium\">\r\n                                                    </div>\r\n                                                    <div class=\"p-2 m-2 bd-highlight small font-weight-bold\"></div>\r\n                                                </div>\r\n                                            </div>\r\n                                        </div>\r\n                                        <div class=\"form-group col-sm-12 col-md-3\">\r\n                                            <label class=\"small font-weight-bold\" for=\"programNumber\">\r\n                            <fa-icon icon=\"hashtag\"></fa-icon> remainingVolume (L)\r\n                          </label>\r\n                                            <div class=\"input-group\">\r\n                                                <div class=\"d-flex bd-highlight\">\r\n                                                    <div class=\"p-2 flex-grow-1 bd-highlight\">\r\n                                                        <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"remainingVolume\" type=\"number\" [(ngModel)]=\"model.remainingVolume\" name=\"remainingVolume\">\r\n                                                    </div>\r\n                                                    <div class=\"p-2 m-2 bd-highlight small font-weight-bold\">L</div>\r\n                                                </div>\r\n\r\n                                            </div>\r\n                                        </div>\r\n                                        <div class=\"form-group col-sm12 col-md-3\">\r\n                                            <label class=\"small font-weight-bold\" for=\"name\">\r\n                            <fa-icon icon=\"calendar-alt\"></fa-icon> colour\r\n                          </label>\r\n                                            <div class=\"input-group\">\r\n                                                <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"colour\" type=\"text\" [(ngModel)]=\"model.colour\" name=\"colour\">\r\n                                            </div>\r\n                                        </div>\r\n                                        <div class=\"form-group col-sm-12 col-md-3\">\r\n                                            <label class=\"small font-weight-bold\" for=\"clientName\">\r\n                            <fa-icon icon=\"industry\"></fa-icon> appearance\r\n                          </label>\r\n                                            <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"appearance\" type=\"text\" [(ngModel)]=\"model.appearance\" name=\"appearance\">\r\n                                        </div>\r\n                                    </div>\r\n                                    <div class=\"form-row\">\r\n\r\n                                        <div class=\"form-group col-sm12 col-md-3\">\r\n                                            <label class=\"small font-weight-bold\" for=\"clientServiceRepresentative\">\r\n                        <fa-icon icon=\"address-card\"></fa-icon> odour\r\n                      </label>\r\n                                            <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"odour\" type=\"text\" [(ngModel)]=\"model.odour\" name=\"odour\">\r\n                                        </div>\r\n                                        <div class=\"form-group col-sm-12 col-md-3\">\r\n                                            <label class=\"small font-weight-bold\" for=\"dateCollected\">\r\n                          Analysis Date\r\n                        </label>\r\n                                            <div class=\"input-group\">\r\n                                                <input readonly ngClass=\"form-control-plaintext\" name=\"analyzedDate\" [(ngModel)]=\"model.analyzedDate\" ngbDatepicker #d=\"ngbDatepicker\">\r\n                                            </div>\r\n                                        </div>\r\n                                    </div>\r\n                                </ng-template>\r\n                            </ngb-tab>\r\n                        </ngb-tabset>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>"

/***/ }),

/***/ "./src/app/water-analysis/components/water-analysis-detail/water-analysis-detail.component.scss":
/*!******************************************************************************************************!*\
  !*** ./src/app/water-analysis/components/water-analysis-detail/water-analysis-detail.component.scss ***!
  \******************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "em {\n  float: right;\n  color: #E05C65;\n  padding-left: 10px; }\n\n.error input {\n  background-color: #E3C3C5; }\n\n.error ::-webkit-input-placeholder {\n  color: #999; }\n\n.error ::-moz-placeholder {\n  color: #999; }\n\n.error :-moz-placeholder {\n  color: #999; }\n\n.error :-ms-input-placeholder {\n  color: #999; }\n\n.form-wdith {\n  width: 100%; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvd2F0ZXItYW5hbHlzaXMvY29tcG9uZW50cy93YXRlci1hbmFseXNpcy1kZXRhaWwvRTpcXGZyb250ZW5kMi9zcmNcXGFwcFxcd2F0ZXItYW5hbHlzaXNcXGNvbXBvbmVudHNcXHdhdGVyLWFuYWx5c2lzLWRldGFpbFxcd2F0ZXItYW5hbHlzaXMtZGV0YWlsLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksWUFBWTtFQUNaLGNBQWM7RUFDZCxrQkFBa0IsRUFBQTs7QUFHdEI7RUFDSSx5QkFBeUIsRUFBQTs7QUFHN0I7RUFDSSxXQUFXLEVBQUE7O0FBR2Y7RUFDSSxXQUFXLEVBQUE7O0FBR2Y7RUFDSSxXQUFXLEVBQUE7O0FBR2Y7RUFDSSxXQUFXLEVBQUE7O0FBR2Y7RUFDSSxXQUFXLEVBQUEiLCJmaWxlIjoic3JjL2FwcC93YXRlci1hbmFseXNpcy9jb21wb25lbnRzL3dhdGVyLWFuYWx5c2lzLWRldGFpbC93YXRlci1hbmFseXNpcy1kZXRhaWwuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJlbSB7XHJcbiAgICBmbG9hdDogcmlnaHQ7XHJcbiAgICBjb2xvcjogI0UwNUM2NTtcclxuICAgIHBhZGRpbmctbGVmdDogMTBweDtcclxufVxyXG5cclxuLmVycm9yIGlucHV0IHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNFM0MzQzU7XHJcbn1cclxuXHJcbi5lcnJvciA6Oi13ZWJraXQtaW5wdXQtcGxhY2Vob2xkZXIge1xyXG4gICAgY29sb3I6ICM5OTk7XHJcbn1cclxuXHJcbi5lcnJvciA6Oi1tb3otcGxhY2Vob2xkZXIge1xyXG4gICAgY29sb3I6ICM5OTk7XHJcbn1cclxuXHJcbi5lcnJvciA6LW1vei1wbGFjZWhvbGRlciB7XHJcbiAgICBjb2xvcjogIzk5OTtcclxufVxyXG5cclxuLmVycm9yIDotbXMtaW5wdXQtcGxhY2Vob2xkZXIge1xyXG4gICAgY29sb3I6ICM5OTk7XHJcbn1cclxuXHJcbi5mb3JtLXdkaXRoIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG59Il19 */"

/***/ }),

/***/ "./src/app/water-analysis/components/water-analysis-detail/water-analysis-detail.component.ts":
/*!****************************************************************************************************!*\
  !*** ./src/app/water-analysis/components/water-analysis-detail/water-analysis-detail.component.ts ***!
  \****************************************************************************************************/
/*! exports provided: WaterAnalysisDetailComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WaterAnalysisDetailComponent", function() { return WaterAnalysisDetailComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ngx-toastr */ "./node_modules/ngx-toastr/fesm5/ngx-toastr.js");
/* harmony import */ var _services_water_analysis_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/water-analysis.service */ "./src/app/water-analysis/services/water-analysis.service.ts");
/* harmony import */ var _models_water_sample__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../models/water-sample */ "./src/app/water-analysis/models/water-sample.ts");
/* harmony import */ var object_mapper__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! object-mapper */ "./node_modules/object-mapper/index.js");
/* harmony import */ var object_mapper__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(object_mapper__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var src_app_user_services_user_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/user/services/user.service */ "./src/app/user/services/user.service.ts");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var src_app_core_utils_file_download_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/core/utils/file-download.service */ "./src/app/core/utils/file-download.service.ts");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var src_app_lab_sample_services_lab_sample_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/lab-sample/services/lab-sample.service */ "./src/app/lab-sample/services/lab-sample.service.ts");













var WaterAnalysisDetailComponent = /** @class */ (function () {
    function WaterAnalysisDetailComponent(route, router, toastrService, waterAnalysisService, labSampleService, fileDownloadService, userService) {
        this.route = route;
        this.router = router;
        this.toastrService = toastrService;
        this.waterAnalysisService = waterAnalysisService;
        this.labSampleService = labSampleService;
        this.fileDownloadService = fileDownloadService;
        this.userService = userService;
        this.readonly = true;
        this.newrequest = false;
        this.isDownloading = false;
        this.staffList = [];
        this.selectStaffInput = new rxjs__WEBPACK_IMPORTED_MODULE_8__["Subject"]();
        this.selectStaffPreLoading = false;
        this.typeString = { 1: 'TT', 2: 'UCA', 4: 'RH', 8: 'SGSA', 128: 'WA' };
        this.chartType = 128;
        this.mapp = {
            'sampleId': 'sampleId',
            'serviceCenter': 'serviceCenter',
            'salesRep': 'salesRep',
            'tsRep': 'tsRep',
            'waterSource': 'waterSource',
            'labAnalyst': 'labAnalyst',
            'notes': 'notes'
        };
    }
    WaterAnalysisDetailComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.route.params.subscribe(function (params) {
            if (params['id']) {
                var id = params['id'];
                _this.id = id;
                _this.getWaterAnalysis(id);
            }
            else if (params['sampleid']) {
                var id = params['sampleid'];
                _this.readonly = false;
                _this.newrequest = true;
                _this.model = new _models_water_sample__WEBPACK_IMPORTED_MODULE_5__["WaterSample"]();
                _this.model.sampleId = id;
                _this.labSampleService.getLabSample(id).subscribe(function (success) {
                    _this.model.labSample = success;
                });
            }
        });
        this.selectStaffInput.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["debounceTime"])(500), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["distinctUntilChanged"])()).subscribe(function (user) {
            _this.selectStaffPreLoading = true;
            _this.lookupStaff(user);
        });
    };
    WaterAnalysisDetailComponent.prototype.lookupStaff = function (user) {
        var _this = this;
        this.userService.search(user)
            .subscribe(function (response) {
            _this.selectStaffPreLoading = false;
            _this.staffList = response;
        });
    };
    WaterAnalysisDetailComponent.prototype.getWaterAnalysis = function (id) {
        var _this = this;
        this.waterAnalysisService.getWaterSample(id).subscribe(function (response) {
            _this.model = response;
        });
    };
    WaterAnalysisDetailComponent.prototype.downloadChart = function () {
        var _this = this;
        this.waterAnalysisService.downloadChart(this.id).subscribe(function (success) {
            _this.fileDownloadService
                .emulateDownload(success, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', "Chart" + _this.typeString[_this.chartType] + "_" + _this.model.labSample.loginNo + ".xlsx");
        }, function () {
            _this.toastrService.error('Server error while downloading file.');
        });
    };
    WaterAnalysisDetailComponent.prototype.download = function () {
        var _this = this;
        this.waterAnalysisService.downloadResult(this.id).subscribe(function (success) {
            _this.fileDownloadService
                .emulateDownload(success, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', "Chart" + _this.typeString[_this.chartType] + "_" + _this.model.labSample.loginNo + ".xlsx");
        });
    };
    WaterAnalysisDetailComponent.prototype.cancel = function () {
        if (this.id !== undefined) {
            this.readonly = true;
        }
        else {
            this.router.navigate(['/water-analysis']);
        }
    };
    WaterAnalysisDetailComponent.prototype.save = function (formValues) {
        var _this = this;
        if (this.id === undefined) {
            var mappedModel = object_mapper__WEBPACK_IMPORTED_MODULE_6__(this.model, this.mapp);
            this.waterAnalysisService.saveWaterSample(mappedModel).subscribe(function (success) {
                _this.model.modifiedBy = success.modifiedBy;
                _this.model.modifiedOn = success.modifiedOn;
                _this.model.createdBy = success.createdBy;
                _this.model.createdOn = success.createdOn;
                _this.toastrService.success('Water Analysis saved successfully.');
                _this.readonly = true;
            }, function (err) {
                _this.readonly = false;
            });
        }
        else {
            this.waterAnalysisService.updateWaterSample(this.model.id, this.model).subscribe(function () {
                _this.toastrService.success('Water Analysis successfully updated.');
                _this.readonly = true;
            });
        }
    };
    WaterAnalysisDetailComponent.prototype.edit = function () {
        this.readonly = false;
    };
    WaterAnalysisDetailComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-water-analysis-detail',
            template: __webpack_require__(/*! ./water-analysis-detail.component.html */ "./src/app/water-analysis/components/water-analysis-detail/water-analysis-detail.component.html"),
            providers: [{ provide: _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_11__["NgbDateAdapter"], useClass: _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_11__["NgbDateNativeAdapter"] }],
            styles: [__webpack_require__(/*! ./water-analysis-detail.component.scss */ "./src/app/water-analysis/components/water-analysis-detail/water-analysis-detail.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            ngx_toastr__WEBPACK_IMPORTED_MODULE_3__["ToastrService"],
            _services_water_analysis_service__WEBPACK_IMPORTED_MODULE_4__["WaterAnalysisService"],
            src_app_lab_sample_services_lab_sample_service__WEBPACK_IMPORTED_MODULE_12__["LabSampleService"],
            src_app_core_utils_file_download_service__WEBPACK_IMPORTED_MODULE_10__["FileDownloadService"],
            src_app_user_services_user_service__WEBPACK_IMPORTED_MODULE_7__["UserService"]])
    ], WaterAnalysisDetailComponent);
    return WaterAnalysisDetailComponent;
}());



/***/ }),

/***/ "./src/app/water-analysis/components/water-analysis-list/water-analysis-list.component.html":
/*!**************************************************************************************************!*\
  !*** ./src/app/water-analysis/components/water-analysis-list/water-analysis-list.component.html ***!
  \**************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">\r\n    <div class=\"col-12\">\r\n        <div class=\"card\">\r\n            <div class=\"card-header\">\r\n                <fa-icon icon=\"tint\"></fa-icon> H<sub>2</sub>O Analysis\r\n            </div>\r\n            <div class=\"card-body\">\r\n                <div style=\"position: relative; top: 150px\">\r\n                    <ngx-ui-loader [loaderId]=\"'grid-loader'\"></ngx-ui-loader>\r\n                </div>\r\n                <ngx-datatable class=\"bootstrap\" [rows]=\"tableState.data\" [loadingIndicator]=\"tableState.loading\" [columnMode]=\"'force'\" [rowHeight]=\"'auto'\" [summaryRow]=\"false\" [summaryPosition]=\"'bottom'\" [footerHeight]=\"40\" [externalPaging]=\"true\" [externalSorting]=\"true\"\r\n                    [count]=\"tableState.count\" [offset]=\"tableState.page - 1\" [limit]=\"tableState.limit\" (page)='setPage($event)' (sort)=\"onSort($event)\">\r\n\r\n                    <ngx-datatable-column name=\"Login#\" prop=\"loginNo\">\r\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\r\n                            <span class=\"datatable-header-cell-wrapper\">\r\n                <span class=\"datatable-header-cell-label draggable\" (click)=\"sort(column.prop)\" [ngClass]=\"{'font-weight-bold': tableState.orderBy === column.prop}\">{{ column.name }}</span>\r\n                            <fa-icon [icon]=\"tableState.orderDirection === 'asc' ? 'sort-up' : 'sort-down'\" class=\"float-right\" *ngIf=\"tableState.orderBy === column.prop\"></fa-icon>\r\n                            <input [ngbTypeahead]=\"columnSearch(column.prop)\" type=\"text\" class=\"form-control form-control-sm\" name=\"\" id=\"\" aria-describedby=\"helpId\" placeholder=\"\">\r\n                            </span>\r\n                        </ng-template>\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            <a class=\"text-primary small\" [routerLink]=\"[ '/lab-samples/' + row.sampleId ]\">\r\n                            {{value}}\r\n                            </a>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"Sample\" prop=\"sampleName\">\r\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\r\n                            <span class=\"datatable-header-cell-wrapper\">\r\n                          <span class=\"datatable-header-cell-label draggable\" (click)=\"sort(column.prop)\" [ngClass]=\"{'font-weight-bold': tableState.orderBy === column.prop}\">{{ column.name }}</span>\r\n                            <fa-icon [icon]=\"tableState.orderDirection === 'asc' ? 'sort-up' : 'sort-down'\" class=\"float-right\" *ngIf=\"tableState.orderBy === column.prop\"></fa-icon>\r\n                            <input [ngbTypeahead]=\"columnSearch(column.prop)\" type=\"text\" class=\"form-control form-control-sm\" name=\"\" id=\"\" aria-describedby=\"helpId\" placeholder=\"\">\r\n                            </span>\r\n                        </ng-template>\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            {{value}}\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"Lab Analyst\" prop=\"labAnalyst\">\r\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\r\n                            <span class=\"datatable-header-cell-wrapper\">\r\n                          <span class=\"datatable-header-cell-label draggable\" (click)=\"sort(column.prop)\" [ngClass]=\"{'font-weight-bold': tableState.orderBy === column.prop}\">{{ column.name }}</span>\r\n                            <fa-icon [icon]=\"tableState.orderDirection === 'asc' ? 'sort-up' : 'sort-down'\" class=\"float-right\" *ngIf=\"tableState.orderBy === column.prop\"></fa-icon>\r\n                            <input [ngbTypeahead]=\"columnSearch(column.prop)\" type=\"text\" class=\"form-control form-control-sm\" name=\"\" id=\"\" aria-describedby=\"helpId\" placeholder=\"\">\r\n                            </span>\r\n                        </ng-template>\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            <span class=\"small\">{{ value }}</span>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"Water Source\" prop=\"waterSource\">\r\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\r\n                            <span class=\"datatable-header-cell-wrapper\">\r\n                          <span class=\"datatable-header-cell-label draggable\" (click)=\"sort(column.prop)\" [ngClass]=\"{'font-weight-bold': tableState.orderBy === column.prop}\">{{ column.name }}</span>\r\n                            <fa-icon [icon]=\"tableState.orderDirection === 'asc' ? 'sort-up' : 'sort-down'\" class=\"float-right\" *ngIf=\"tableState.orderBy === column.prop\"></fa-icon>\r\n                            <input [ngbTypeahead]=\"columnSearch(column.prop)\" type=\"text\" class=\"form-control form-control-sm\" name=\"\" id=\"\" aria-describedby=\"helpId\" placeholder=\"\">\r\n                            </span>\r\n                        </ng-template>\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            <span class=\"small\">{{ value }}</span>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"\" prop=\"\">\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            <span class=\"small\">\r\n                            <a class=\"text-primary\" [routerLink]=\"[ '/water-analysis/' + row.id ]\">\r\n                              details\r\n                            </a>\r\n                        </span>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                </ngx-datatable>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>"

/***/ }),

/***/ "./src/app/water-analysis/components/water-analysis-list/water-analysis-list.component.scss":
/*!**************************************************************************************************!*\
  !*** ./src/app/water-analysis/components/water-analysis-list/water-analysis-list.component.scss ***!
  \**************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3dhdGVyLWFuYWx5c2lzL2NvbXBvbmVudHMvd2F0ZXItYW5hbHlzaXMtbGlzdC93YXRlci1hbmFseXNpcy1saXN0LmNvbXBvbmVudC5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/water-analysis/components/water-analysis-list/water-analysis-list.component.ts":
/*!************************************************************************************************!*\
  !*** ./src/app/water-analysis/components/water-analysis-list/water-analysis-list.component.ts ***!
  \************************************************************************************************/
/*! exports provided: WaterAnalysisListComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WaterAnalysisListComponent", function() { return WaterAnalysisListComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_water_analysis_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/water-analysis.service */ "./src/app/water-analysis/services/water-analysis.service.ts");
/* harmony import */ var ngx_ui_loader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ngx-ui-loader */ "./node_modules/ngx-ui-loader/fesm5/ngx-ui-loader.js");
/* harmony import */ var src_app_core_datatable_table_state__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/datatable/table-state */ "./src/app/core/datatable/table-state.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");






var WaterAnalysisListComponent = /** @class */ (function () {
    function WaterAnalysisListComponent(waterAnalysisService, ngxService) {
        this.waterAnalysisService = waterAnalysisService;
        this.ngxService = ngxService;
        this.tableState = new src_app_core_datatable_table_state__WEBPACK_IMPORTED_MODULE_4__["TableState"]();
    }
    WaterAnalysisListComponent.prototype.ngOnInit = function () {
        this.getWaterSamples();
    };
    WaterAnalysisListComponent.prototype.getWaterSamples = function () {
        var _this = this;
        this.ngxService.startLoader('grid-loader');
        this.waterAnalysisService.getWaterSamples(this.tableState.page, this.tableState.limit, this.tableState.filters, this.tableState.orderBy, this.tableState.orderDirection).subscribe(function (response) {
            _this.tableState.attachResponse(response);
            _this.ngxService.stopLoader('grid-loader');
        });
    };
    WaterAnalysisListComponent.prototype.setPage = function (pageInfo) {
        this.tableState.page = pageInfo.offset + 1;
        this.getWaterSamples();
    };
    WaterAnalysisListComponent.prototype.onSort = function (event) {
        this.tableState.setOrdering(event.column.prop);
        this.getWaterSamples();
    };
    WaterAnalysisListComponent.prototype.sort = function (columnName) {
        this.tableState.setOrdering(columnName);
        this.getWaterSamples();
    };
    WaterAnalysisListComponent.prototype.showMe = function (row) {
    };
    WaterAnalysisListComponent.prototype.columnSearch = function (columName$) {
        var _this = this;
        var func = function (text$) {
            return text$.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["debounceTime"])(300), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["distinctUntilChanged"])(), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(function (term) {
                _this.tableState.setFilter(columName$, term);
                _this.getWaterSamples();
            }));
        };
        return func;
    };
    WaterAnalysisListComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-water-analysis-list',
            template: __webpack_require__(/*! ./water-analysis-list.component.html */ "./src/app/water-analysis/components/water-analysis-list/water-analysis-list.component.html"),
            styles: [__webpack_require__(/*! ./water-analysis-list.component.scss */ "./src/app/water-analysis/components/water-analysis-list/water-analysis-list.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_water_analysis_service__WEBPACK_IMPORTED_MODULE_2__["WaterAnalysisService"],
            ngx_ui_loader__WEBPACK_IMPORTED_MODULE_3__["NgxUiLoaderService"]])
    ], WaterAnalysisListComponent);
    return WaterAnalysisListComponent;
}());



/***/ }),

/***/ "./src/app/water-analysis/models/water-sample.ts":
/*!*******************************************************!*\
  !*** ./src/app/water-analysis/models/water-sample.ts ***!
  \*******************************************************/
/*! exports provided: WaterSample */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WaterSample", function() { return WaterSample; });
var WaterSample = /** @class */ (function () {
    function WaterSample() {
    }
    return WaterSample;
}());



/***/ }),

/***/ "./src/app/water-analysis/water-analysis-routing.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/water-analysis/water-analysis-routing.module.ts ***!
  \*****************************************************************/
/*! exports provided: WaterAnalysisRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WaterAnalysisRoutingModule", function() { return WaterAnalysisRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _components_water_analysis_list_water_analysis_list_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/water-analysis-list/water-analysis-list.component */ "./src/app/water-analysis/components/water-analysis-list/water-analysis-list.component.ts");
/* harmony import */ var _components_water_analysis_detail_water_analysis_detail_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/water-analysis-detail/water-analysis-detail.component */ "./src/app/water-analysis/components/water-analysis-detail/water-analysis-detail.component.ts");





var routes = [
    {
        path: '',
        component: _components_water_analysis_list_water_analysis_list_component__WEBPACK_IMPORTED_MODULE_3__["WaterAnalysisListComponent"]
    },
    {
        path: 'new/:sampleid',
        component: _components_water_analysis_detail_water_analysis_detail_component__WEBPACK_IMPORTED_MODULE_4__["WaterAnalysisDetailComponent"]
    },
    {
        path: ':id',
        component: _components_water_analysis_detail_water_analysis_detail_component__WEBPACK_IMPORTED_MODULE_4__["WaterAnalysisDetailComponent"]
    }
];
var WaterAnalysisRoutingModule = /** @class */ (function () {
    function WaterAnalysisRoutingModule() {
    }
    WaterAnalysisRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], WaterAnalysisRoutingModule);
    return WaterAnalysisRoutingModule;
}());



/***/ }),

/***/ "./src/app/water-analysis/water-analysis.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/water-analysis/water-analysis.module.ts ***!
  \*********************************************************/
/*! exports provided: WaterAnalysisModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WaterAnalysisModule", function() { return WaterAnalysisModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @fortawesome/free-solid-svg-icons */ "./node_modules/@fortawesome/free-solid-svg-icons/index.es.js");
/* harmony import */ var _fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fortawesome/fontawesome-svg-core */ "./node_modules/@fortawesome/fontawesome-svg-core/index.es.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var ngx_ui_loader__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ngx-ui-loader */ "./node_modules/ngx-ui-loader/fesm5/ngx-ui-loader.js");
/* harmony import */ var _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ng-select/ng-select */ "./node_modules/@ng-select/ng-select/fesm5/ng-select.js");
/* harmony import */ var _water_analysis_routing_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./water-analysis-routing.module */ "./src/app/water-analysis/water-analysis-routing.module.ts");
/* harmony import */ var _components_water_analysis_list_water_analysis_list_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./components/water-analysis-list/water-analysis-list.component */ "./src/app/water-analysis/components/water-analysis-list/water-analysis-list.component.ts");
/* harmony import */ var _components_water_analysis_detail_water_analysis_detail_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./components/water-analysis-detail/water-analysis-detail.component */ "./src/app/water-analysis/components/water-analysis-detail/water-analysis-detail.component.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @swimlane/ngx-datatable */ "./node_modules/@swimlane/ngx-datatable/release/index.js");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _fortawesome_angular_fontawesome__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @fortawesome/angular-fontawesome */ "./node_modules/@fortawesome/angular-fontawesome/fesm5/angular-fontawesome.js");














var WaterAnalysisModule = /** @class */ (function () {
    function WaterAnalysisModule() {
        _fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_4__["library"].add(_fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__["faVial"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__["faSortUp"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__["faSortDown"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__["faCalendarAlt"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__["faBlender"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__["faHashtag"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__["faIndustry"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__["faAddressCard"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__["faLocationArrow"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__["faMapMarkerAlt"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__["faArrowCircleDown"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__["faInfoCircle"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__["faVials"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__["faComment"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__["faArrowCircleLeft"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__["faDownload"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__["faWater"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__["faTint"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__["faCircleNotch"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__["faEdit"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__["faTimesCircle"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__["faSave"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__["faPlus"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__["faMinus"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__["faCodeBranch"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__["faStar"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_3__["faPoll"]);
    }
    WaterAnalysisModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_components_water_analysis_list_water_analysis_list_component__WEBPACK_IMPORTED_MODULE_9__["WaterAnalysisListComponent"], _components_water_analysis_detail_water_analysis_detail_component__WEBPACK_IMPORTED_MODULE_10__["WaterAnalysisDetailComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_11__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_11__["ReactiveFormsModule"],
                _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_12__["NgxDatatableModule"],
                _fortawesome_angular_fontawesome__WEBPACK_IMPORTED_MODULE_13__["FontAwesomeModule"],
                _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__["NgbModule"],
                ngx_ui_loader__WEBPACK_IMPORTED_MODULE_6__["NgxUiLoaderModule"],
                _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_7__["NgSelectModule"],
                _water_analysis_routing_module__WEBPACK_IMPORTED_MODULE_8__["WaterAnalysisRoutingModule"]
            ]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], WaterAnalysisModule);
    return WaterAnalysisModule;
}());



/***/ })

}]);
//# sourceMappingURL=water-analysis-water-analysis-module.js.map