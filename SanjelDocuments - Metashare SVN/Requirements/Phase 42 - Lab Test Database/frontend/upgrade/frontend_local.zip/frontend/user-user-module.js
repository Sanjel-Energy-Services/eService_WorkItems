(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["user-user-module"],{

/***/ "./src/app/user/components/user-create/user-create.component.html":
/*!************************************************************************!*\
  !*** ./src/app/user/components/user-create/user-create.component.html ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"modal-header\">\r\n  <h4 class=\"modal-title\" id=\"modal-basic-title\">Add Users to Sanjel Lab Database</h4>\r\n  <button type=\"button\" class=\"close\" aria-label=\"Close\" (click)=\"onCancel()\">\r\n    <span aria-hidden=\"true\">&times;</span>\r\n  </button>\r\n</div>\r\n<div class=\"modal-body\">\r\n  <form>\r\n    <p>To add user, just type their Active Directory User Name</p>\r\n    <div class=\"form-group\">\r\n      <label for=\"userName\">User</label>\r\n      <ng-select [items]=\"ldapUserList\" [typeahead]=\"selectUserInput\" [loading]=\"selectUserPreLoading\" bindLabel=\"userName\"\r\n        [(ngModel)]=\"selectedUser\" name=\"userName\">\r\n        <ng-template ng-option-tmp let-item=\"item\" let-index=\"index\" let-search=\"searchTerm\">\r\n          <div class=\"row\">\r\n            <div class=\"col-md-12\">\r\n                <fa-icon icon=\"user\"></fa-icon> {{item.firstName}} {{item.lastName}} ({{item.userName}})\r\n            </div>\r\n          </div>\r\n          <div class=\"row\">\r\n            <div class=\"col-md-12 text-muted\">\r\n              {{item.email}}\r\n            </div>\r\n          </div>\r\n        </ng-template>\r\n      </ng-select>\r\n      <div class=\"invalid-feedback\" [ngClass]=\"{'show': feedback}\">\r\n          {{feedback}}\r\n      </div>\r\n    </div>\r\n  </form>\r\n</div>\r\n<div class=\"modal-footer\">\r\n  <button type=\"button\" class=\"btn btn-primary\" (click)=\"onSave()\">Save</button>\r\n  <button type=\"button\" class=\"btn btn-outline-dark\" (click)=\"onCancel()\">Cancel</button>\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/user/components/user-create/user-create.component.scss":
/*!************************************************************************!*\
  !*** ./src/app/user/components/user-create/user-create.component.scss ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".show {\n  display: inline; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXNlci9jb21wb25lbnRzL3VzZXItY3JlYXRlL0U6XFxmcm9udGVuZDIvc3JjXFxhcHBcXHVzZXJcXGNvbXBvbmVudHNcXHVzZXItY3JlYXRlXFx1c2VyLWNyZWF0ZS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGVBQWUsRUFBQSIsImZpbGUiOiJzcmMvYXBwL3VzZXIvY29tcG9uZW50cy91c2VyLWNyZWF0ZS91c2VyLWNyZWF0ZS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zaG93IHtcclxuICAgIGRpc3BsYXk6IGlubGluZTtcclxufSJdfQ== */"

/***/ }),

/***/ "./src/app/user/components/user-create/user-create.component.ts":
/*!**********************************************************************!*\
  !*** ./src/app/user/components/user-create/user-create.component.ts ***!
  \**********************************************************************/
/*! exports provided: UserCreateComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserCreateComponent", function() { return UserCreateComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/user.service */ "./src/app/user/services/user.service.ts");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");






var UserCreateComponent = /** @class */ (function () {
    function UserCreateComponent(userService, activeModal) {
        this.userService = userService;
        this.activeModal = activeModal;
        this.selectUserInput = new rxjs__WEBPACK_IMPORTED_MODULE_3__["Subject"]();
        this.selectUserPreLoading = false;
    }
    UserCreateComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.selectUserInput.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["debounceTime"])(500), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["distinctUntilChanged"])()).subscribe(function (term) {
            _this.selectUserPreLoading = true;
            _this.searchUsers(term);
        });
    };
    UserCreateComponent.prototype.searchUsers = function (term) {
        var _this = this;
        this.userService.search(term)
            .subscribe(function (response) {
            _this.selectUserPreLoading = false;
            _this.ldapUserList = response;
        });
    };
    UserCreateComponent.prototype.onSave = function () {
        var _this = this;
        if (this.selectedUser == null) {
            return;
        }
        // return;
        this.userService.createUser(this.selectedUser.userName)
            .subscribe(function (response) {
            _this.activeModal.close();
        }, function (error) {
            _this.feedback = error.error.Message;
        });
    };
    UserCreateComponent.prototype.onCancel = function () {
        this.activeModal.close();
    };
    UserCreateComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-user-create',
            template: __webpack_require__(/*! ./user-create.component.html */ "./src/app/user/components/user-create/user-create.component.html"),
            styles: [__webpack_require__(/*! ./user-create.component.scss */ "./src/app/user/components/user-create/user-create.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_user_service__WEBPACK_IMPORTED_MODULE_2__["UserService"],
            _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__["NgbActiveModal"]])
    ], UserCreateComponent);
    return UserCreateComponent;
}());



/***/ }),

/***/ "./src/app/user/components/user-edit/user-edit.component.html":
/*!********************************************************************!*\
  !*** ./src/app/user/components/user-edit/user-edit.component.html ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"modal-header\">\r\n  <h4 class=\"modal-title\" id=\"modal-basic-title\">Edit User</h4>\r\n  <button type=\"button\" class=\"close\" aria-label=\"Close\" (click)=\"onCancel()\">\r\n    <span aria-hidden=\"true\">&times;</span>\r\n  </button>\r\n</div>\r\n<div class=\"modal-body\">\r\n    <form>\r\n        <div class=\"form-group\">\r\n          <label for=\"roles\">Roles</label>\r\n          <ng-select \r\n            [items]=\"roles\" \r\n            bindLabel=\"roles\"\r\n            [multiple]=\"true\"\r\n            [(ngModel)]=\"user.roles\" \r\n            name=\"roles\">\r\n          </ng-select>\r\n        </div>\r\n      </form>\r\n</div>\r\n<div class=\"modal-footer\">\r\n  <button type=\"button\" class=\"btn btn-primary\" (click)=\"onSave()\">Save</button>\r\n  <button type=\"button\" class=\"btn btn-outline-dark\" (click)=\"onCancel()\">Cancel</button>\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/user/components/user-edit/user-edit.component.scss":
/*!********************************************************************!*\
  !*** ./src/app/user/components/user-edit/user-edit.component.scss ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3VzZXIvY29tcG9uZW50cy91c2VyLWVkaXQvdXNlci1lZGl0LmNvbXBvbmVudC5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/user/components/user-edit/user-edit.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/user/components/user-edit/user-edit.component.ts ***!
  \******************************************************************/
/*! exports provided: UserEditComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserEditComponent", function() { return UserEditComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/user.service */ "./src/app/user/services/user.service.ts");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _models_sld_user__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../models/sld-user */ "./src/app/user/models/sld-user.ts");





var UserEditComponent = /** @class */ (function () {
    function UserEditComponent(userService, activeModal) {
        this.userService = userService;
        this.activeModal = activeModal;
    }
    UserEditComponent.prototype.ngOnInit = function () {
        this.getRoles();
    };
    UserEditComponent.prototype.onCancel = function () {
        this.activeModal.close();
    };
    UserEditComponent.prototype.onSave = function () {
        var _this = this;
        this.userService.update(this.user).subscribe(function (response) {
            _this.activeModal.close();
        });
    };
    UserEditComponent.prototype.getRoles = function () {
        var _this = this;
        this.userService.getRoles().subscribe(function (response) {
            _this.roles = response;
        });
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _models_sld_user__WEBPACK_IMPORTED_MODULE_4__["SldUser"])
    ], UserEditComponent.prototype, "user", void 0);
    UserEditComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-user-edit',
            template: __webpack_require__(/*! ./user-edit.component.html */ "./src/app/user/components/user-edit/user-edit.component.html"),
            styles: [__webpack_require__(/*! ./user-edit.component.scss */ "./src/app/user/components/user-edit/user-edit.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_user_service__WEBPACK_IMPORTED_MODULE_2__["UserService"],
            _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_3__["NgbActiveModal"]])
    ], UserEditComponent);
    return UserEditComponent;
}());



/***/ }),

/***/ "./src/app/user/components/user-list/user-list.component.html":
/*!********************************************************************!*\
  !*** ./src/app/user/components/user-list/user-list.component.html ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">\r\n  <div class=\"col-12\">\r\n    <div class=\"card\">\r\n      <div class=\"card-header\">\r\n        <fa-icon icon=\"table\"></fa-icon>\r\n        User Management\r\n        <button id=\"btn-add-user\" class=\"btn btn-sm btn-outline-primary float-right\" (click)=\"addUser()\">Add\r\n          User</button>\r\n      </div>\r\n      <div class=\"card-body\">\r\n        <ngx-datatable class=\"bootstrap\" [rows]=\"tableState.data\" [loadingIndicator]=\"tableState.loading\"\r\n          [columnMode]=\"'force'\" [rowHeight]=\"'auto'\" [summaryRow]=\"true\" [summaryPosition]=\"'bottom'\"\r\n          [footerHeight]=\"40\" [externalPaging]=\"true\" [count]=\"tableState.count\" [offset]=\"tableState.page - 1\"\r\n          [limit]=\"tableState.limit\" (page)='setPage($event)'>\r\n          <ngx-datatable-column name=\"userName\">\r\n            <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n              <button type=\"button\" class=\"btn btn-link btn-sm\" (click)=\"onEdit(row)\">{{value}}</button>\r\n            </ng-template>\r\n          </ngx-datatable-column>\r\n          <ngx-datatable-column name=\"name\">\r\n          </ngx-datatable-column>\r\n          <ngx-datatable-column name=\"email\">\r\n          </ngx-datatable-column>\r\n          <ngx-datatable-column name=\"roles\">\r\n          </ngx-datatable-column>\r\n          <ngx-datatable-column name=\"action\" [width]=\"80\">\r\n            <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n              <div class=\"btn-group\" role=\"group\" aria-label=\"user-actions\">\r\n                <button type=\"button\" class=\"btn btn-link btn-sm\" [ngClass]=\"row.blocked ? 'text-dark' : 'text-success'\"\r\n                  (click)=\"onLock(row)\" placement=\"bottom\" container=\"body\"\r\n                  [ngbTooltip]=\"(row.blocked ? 'Unlock ' : 'Lock ') + row.userName\">\r\n                  <fa-icon [icon]=\"row.blocked ? 'lock' : 'lock-open'\"></fa-icon>\r\n                </button>\r\n                <button type=\"button\" class=\"btn btn-link btn-sm text-danger\" (click)=\"onDelete(row)\" placement=\"bottom\"\r\n                  container=\"body\" [ngbTooltip]=\"'Delete ' + row.userName + '?'\">\r\n                  <fa-icon icon=\"trash\"></fa-icon>\r\n                </button>\r\n              </div>\r\n            </ng-template>\r\n          </ngx-datatable-column>\r\n        </ngx-datatable>\r\n      </div>\r\n    </div>\r\n  </div>\r\n"

/***/ }),

/***/ "./src/app/user/components/user-list/user-list.component.scss":
/*!********************************************************************!*\
  !*** ./src/app/user/components/user-list/user-list.component.scss ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3VzZXIvY29tcG9uZW50cy91c2VyLWxpc3QvdXNlci1saXN0LmNvbXBvbmVudC5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/user/components/user-list/user-list.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/user/components/user-list/user-list.component.ts ***!
  \******************************************************************/
/*! exports provided: UserListComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserListComponent", function() { return UserListComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _user_create_user_create_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../user-create/user-create.component */ "./src/app/user/components/user-create/user-create.component.ts");
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/user.service */ "./src/app/user/services/user.service.ts");
/* harmony import */ var src_app_core_datatable_table_state__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/datatable/table-state */ "./src/app/core/datatable/table-state.ts");
/* harmony import */ var src_app_shared_widget_confirm_dialog_confirm_dialog_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/widget/confirm-dialog/confirm-dialog.component */ "./src/app/shared/widget/confirm-dialog/confirm-dialog.component.ts");
/* harmony import */ var _user_edit_user_edit_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../user-edit/user-edit.component */ "./src/app/user/components/user-edit/user-edit.component.ts");








var UserListComponent = /** @class */ (function () {
    function UserListComponent(modalService, userService) {
        this.modalService = modalService;
        this.userService = userService;
        this.tableState = new src_app_core_datatable_table_state__WEBPACK_IMPORTED_MODULE_5__["TableState"]();
        this.columns = [
            { prop: 'userName' },
            { name: 'name' },
            { name: 'email' }
        ];
    }
    UserListComponent.prototype.ngOnInit = function () {
        this.getUsers();
    };
    UserListComponent.prototype.addUser = function () {
        var _this = this;
        var modalRef = this.modalService.open(_user_create_user_create_component__WEBPACK_IMPORTED_MODULE_3__["UserCreateComponent"]);
        modalRef.result.then(function (result) {
            _this.getUsers();
        });
    };
    UserListComponent.prototype.setPage = function (pageInfo) {
        this.tableState.page = pageInfo.offset + 1;
        this.getUsers();
    };
    UserListComponent.prototype.getUsers = function () {
        var _this = this;
        this.tableState.startLoading();
        this.userService.getUsers(this.tableState.page, this.tableState.limit).subscribe(function (response) {
            _this.tableState.attachResponse(response);
        });
    };
    UserListComponent.prototype.onDelete = function (row) {
        var _this = this;
        var modalRef = this.modalService.open(src_app_shared_widget_confirm_dialog_confirm_dialog_component__WEBPACK_IMPORTED_MODULE_6__["ConfirmDialogComponent"]);
        modalRef.componentInstance.title = 'delete user';
        modalRef.componentInstance.message = "are you sure you want to delete " + row.name + "?";
        modalRef.componentInstance.confirm.subscribe(function (confirm) {
            if (confirm) {
                _this.userService.deleteUser(row.userId).subscribe(function (response) {
                    _this.getUsers();
                });
            }
        });
    };
    UserListComponent.prototype.onLock = function (row) {
        var _this = this;
        this.userService.setLock(row).subscribe(function () { _this.getUsers(); });
    };
    UserListComponent.prototype.onEdit = function (row) {
        var _this = this;
        var modalRef = this.modalService.open(_user_edit_user_edit_component__WEBPACK_IMPORTED_MODULE_7__["UserEditComponent"]);
        modalRef.componentInstance.user = row;
        modalRef.result.then(function (result) {
            _this.getUsers();
        });
    };
    UserListComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-user-list',
            template: __webpack_require__(/*! ./user-list.component.html */ "./src/app/user/components/user-list/user-list.component.html"),
            styles: [__webpack_require__(/*! ./user-list.component.scss */ "./src/app/user/components/user-list/user-list.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_2__["NgbModal"],
            _services_user_service__WEBPACK_IMPORTED_MODULE_4__["UserService"]])
    ], UserListComponent);
    return UserListComponent;
}());



/***/ }),

/***/ "./src/app/user/models/sld-user.ts":
/*!*****************************************!*\
  !*** ./src/app/user/models/sld-user.ts ***!
  \*****************************************/
/*! exports provided: SldUser */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SldUser", function() { return SldUser; });
var SldUser = /** @class */ (function () {
    function SldUser() {
    }
    return SldUser;
}());



/***/ }),

/***/ "./src/app/user/user-routing.module.ts":
/*!*********************************************!*\
  !*** ./src/app/user/user-routing.module.ts ***!
  \*********************************************/
/*! exports provided: UserRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserRoutingModule", function() { return UserRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _components_user_list_user_list_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/user-list/user-list.component */ "./src/app/user/components/user-list/user-list.component.ts");




var routes = [{
        path: '',
        component: _components_user_list_user_list_component__WEBPACK_IMPORTED_MODULE_3__["UserListComponent"]
    }];
var UserRoutingModule = /** @class */ (function () {
    function UserRoutingModule() {
    }
    UserRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], UserRoutingModule);
    return UserRoutingModule;
}());



/***/ }),

/***/ "./src/app/user/user.module.ts":
/*!*************************************!*\
  !*** ./src/app/user/user.module.ts ***!
  \*************************************/
/*! exports provided: UserModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserModule", function() { return UserModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _user_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./user-routing.module */ "./src/app/user/user-routing.module.ts");
/* harmony import */ var _components_user_list_user_list_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/user-list/user-list.component */ "./src/app/user/components/user-list/user-list.component.ts");
/* harmony import */ var _components_user_create_user_create_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/user-create/user-create.component */ "./src/app/user/components/user-create/user-create.component.ts");
/* harmony import */ var _fortawesome_angular_fontawesome__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @fortawesome/angular-fontawesome */ "./node_modules/@fortawesome/angular-fontawesome/fesm5/angular-fontawesome.js");
/* harmony import */ var _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ng-select/ng-select */ "./node_modules/@ng-select/ng-select/fesm5/ng-select.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @swimlane/ngx-datatable */ "./node_modules/@swimlane/ngx-datatable/release/index.js");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _shared_widget_widget_module__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../shared/widget/widget.module */ "./src/app/shared/widget/widget.module.ts");
/* harmony import */ var _components_user_edit_user_edit_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./components/user-edit/user-edit.component */ "./src/app/user/components/user-edit/user-edit.component.ts");
/* harmony import */ var _fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @fortawesome/fontawesome-svg-core */ "./node_modules/@fortawesome/fontawesome-svg-core/index.es.js");
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @fortawesome/free-solid-svg-icons */ "./node_modules/@fortawesome/free-solid-svg-icons/index.es.js");















var UserModule = /** @class */ (function () {
    function UserModule() {
        _fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_13__["library"].add(_fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_14__["faLock"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_14__["faLockOpen"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_14__["faTrash"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_14__["faUser"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_14__["faTable"]);
    }
    UserModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_components_user_list_user_list_component__WEBPACK_IMPORTED_MODULE_4__["UserListComponent"], _components_user_create_user_create_component__WEBPACK_IMPORTED_MODULE_5__["UserCreateComponent"], _components_user_edit_user_edit_component__WEBPACK_IMPORTED_MODULE_12__["UserEditComponent"]],
            entryComponents: [_components_user_create_user_create_component__WEBPACK_IMPORTED_MODULE_5__["UserCreateComponent"], _components_user_edit_user_edit_component__WEBPACK_IMPORTED_MODULE_12__["UserEditComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _user_routing_module__WEBPACK_IMPORTED_MODULE_3__["UserRoutingModule"],
                _fortawesome_angular_fontawesome__WEBPACK_IMPORTED_MODULE_6__["FontAwesomeModule"],
                _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_7__["NgSelectModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_8__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_8__["ReactiveFormsModule"],
                _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_9__["NgbModule"],
                _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_10__["NgxDatatableModule"],
                _shared_widget_widget_module__WEBPACK_IMPORTED_MODULE_11__["WidgetModule"]
            ],
            exports: [_components_user_create_user_create_component__WEBPACK_IMPORTED_MODULE_5__["UserCreateComponent"]]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], UserModule);
    return UserModule;
}());



/***/ })

}]);
//# sourceMappingURL=user-user-module.js.map