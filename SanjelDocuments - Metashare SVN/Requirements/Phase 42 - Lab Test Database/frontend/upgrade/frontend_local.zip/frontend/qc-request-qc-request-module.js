(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["qc-request-qc-request-module"],{

/***/ "./src/app/qc-request/adapters/qc-request-adapter.ts":
/*!***********************************************************!*\
  !*** ./src/app/qc-request/adapters/qc-request-adapter.ts ***!
  \***********************************************************/
/*! exports provided: QcRequestAdapter */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "QcRequestAdapter", function() { return QcRequestAdapter; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var QcRequestAdapter = /** @class */ (function () {
    function QcRequestAdapter() {
    }
    QcRequestAdapter.prototype.adapt = function (item) {
        var ret = {
            businessId: item.businessId,
            sampleId: item.sampleId,
            loginNo: item.loginNo,
            tT40: item.tT40,
            tT100: item.tT100,
            initialBC: item.initialBC,
            rheology: item.rheology,
            tenSecGelStrength: item.tenSecGelStrength,
            tenMinGelStrength: item.tenMinGelStrength,
            density: item.density,
            productionWeek: new Date(item.productionWeek),
            blaine: item.blaine,
            retainedSieve: item.retainedSieve,
            vicatInitialSet: item.vicatInitialSet,
            oneDay: item.oneDay,
            labSample: item.labSample,
            freeWater: item.freeWater,
            specificGravity: item.specificGravity,
            createdOn: item.createOn,
            createdBy: item.createdBy,
            modifiedOn: item.modifiedOn,
            modifiedBy: item.modifiedBy
        };
        return ret;
    };
    QcRequestAdapter = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        })
    ], QcRequestAdapter);
    return QcRequestAdapter;
}());



/***/ }),

/***/ "./src/app/qc-request/components/qc-request-detail/qc-request-detail.component.html":
/*!******************************************************************************************!*\
  !*** ./src/app/qc-request/components/qc-request-detail/qc-request-detail.component.html ***!
  \******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">\r\n    <div class=\"col-12\">\r\n        <div *ngIf=\"model\" class=\"card\" [ngClass]=\"{'sld-card-warning': model.status === 'New', 'sld-card-info':  model.status === 'InProgress', 'sld-card-success':  model.status === 'Completed', 'sld-card-danger':  model.status === 'Cancelled'}\">\r\n            <div class=\"card-body\">\r\n                <div class=\"row\">\r\n                    <div class=\"col-12\">\r\n                        <div class=\"row\">\r\n                            <div class=\"col-lg-5 col-md-12\">\r\n                                <h4 class=\"card-title mb-0 text-primary\">\r\n                                    <fa-icon icon=\"vials\" [ngClass]=\"{'text-warning': model.status === 'New', 'text-info': model.status === 'InProgress', 'text-success': model.status === 'Completed', 'text-danger': model.status === 'Cancelled'}\">\r\n                                    </fa-icon>\r\n                                    Quality Control Test Request - <span class=\"font-weight-bold\">{{ model.labSample?.loginNo }}</span>\r\n\r\n                                    <span [hidden]=\"statusChange\" class=\"badge ml-2\" (click)=\"toggleState();\" [ngClass]=\"{'badge-warning': model.status === 'New', 'badge-info': model.status === 'InProgress', 'badge-success': model.status === 'Completed', 'badge-danger': model.status === 'Cancelled'}\">{{model.status}}</span>\r\n                                    <div class=\"keep-in-line col-md-4\">\r\n                                        <ng-select [hidden]=\"!statusChange\" class=\"small ml-4\" [items]=\"stateList\" [(ngModel)]='model.status' (change)='onStateChanged()'>\r\n                                        </ng-select>\r\n                                    </div>\r\n                                </h4>\r\n\r\n                                <div class=\"small text-muted\">Created on {{ model.createdOn | date }} by {{ model.createdBy }}, last updated on {{ model.modifiedOn | date }} by {{ model.modifiedBy }}</div>\r\n                            </div>\r\n                            <div class=\"col-lg-7 col-md-12\">\r\n                                <div class=\"btn-toolbar float-right\" role=\"toolbar\" aria-label=\"Toolbar\">\r\n                                    <a class=\"btn btn-sm btn-outline-primary ml-1 mt-1\" [routerLink]=\"[ '/qc-requests/' ]\">\r\n                                        <fa-icon icon=\"arrow-circle-left\"></fa-icon> Return to list\r\n                                    </a>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <hr>\r\n                <div class=\"row\">\r\n                    <div class=\"col-12\">\r\n                        <ngb-tabset [activeId]=\"tab\">\r\n                            <ngb-tab [id]=\"0\">\r\n\r\n                                <ng-template ngbTabTitle>\r\n\r\n                                    <span class=\"text-primary\">\r\n                          <fa-icon icon=\"info-circle\"></fa-icon> General\r\n                        </span>\r\n                                </ng-template>\r\n                                <ng-template ngbTabContent>\r\n                                    <form #qcRequestForm=\"ngForm\" autocomplete=\"off\" (ngSubmit)=\"save(qcRequestForm.value)\">\r\n                                        <div class=\"row\">\r\n                                            <div class=\"col-12\">\r\n                                                <div *ngIf=\"readonly\" class=\"btn-toolbar float-right mb-2\" role=\"toolbar\" aria-label=\"Toolbar\">\r\n                                                    <button type=\"button\" class=\"btn btn-sm btn-outline-primary ml-1\" (click)=\"edit()\">\r\n                              <fa-icon icon=\"edit\"></fa-icon> Edit\r\n                            </button>\r\n                                                </div>\r\n                                                <div [hidden]=\"readonly\" class=\"btn-toolbar float-right mb-2\" role=\"toolbar\" aria-label=\"Toolbar\">\r\n                                                    <span (mouseenter)=\"mouseoverSave=true\" (mouseleave)=\"mouseoverSave=false\">\r\n                                                        <button [disabled]=\"qcRequestForm.invalid\" type=\"submit\" class=\"btn btn-sm btn-success ml-1\">\r\n                              <fa-icon icon=\"save\"></fa-icon> Save\r\n                            </button></span>\r\n                                                    <button type=\"button\" class=\"btn btn-sm btn-outline-primary ml-1\" (click)=\"cancel()\">\r\n                              <fa-icon icon=\"times-circle\"></fa-icon> Cancel\r\n                            </button>\r\n                                                </div>\r\n                                            </div>\r\n                                        </div>\r\n                                        <div class=\"form-row\">\r\n                                            <div class=\"form-group col-sm12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"tT40\">\r\n                            <fa-icon icon=\"hashtag\"></fa-icon> TT 40 (hr:min)\r\n                          </label>\r\n\r\n                                                <div class=\"input-group\">\r\n                                                    <div class=\"d-flex bd-highlight\">\r\n                                                        <div class=\"p-2 flex-grow-1 bd-highlight\">\r\n                                                            <em *ngIf=\"qcRequestForm.controls.tT40?.invalid && (qcRequestForm.controls.tT40?.touched || mouseoverSave)\">Required</em>\r\n                                                            <input autofocus [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"tT40\" type=\"number\" [(ngModel)]=\"model.tT40\" name=\"tT40\" required>\r\n                                                        </div>\r\n                                                        <div class=\"p-2 m-2 bd-highlight small font-weight-bold\"></div>\r\n                                                    </div>\r\n\r\n                                                </div>\r\n                                            </div>\r\n                                            <div class=\"form-group col-sm-12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"tT100\">\r\n                            <fa-icon icon=\"hashtag\"></fa-icon> TT 100 (hr:min)\r\n                          </label>\r\n\r\n                                                <div class=\"input-group\">\r\n                                                    <div class=\"d-flex bd-highlight\">\r\n                                                        <div class=\"p-2 flex-grow-1 bd-highlight\">\r\n                                                            <em *ngIf=\"qcRequestForm.controls.tT100?.invalid && (qcRequestForm.controls.tT100?.touched || mouseoverSave)\">Required</em>\r\n                                                            <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"tT100\" type=\"number\" [(ngModel)]=\"model.tT100\" name=\"tT100\" required>\r\n                                                        </div>\r\n                                                        <div class=\"p-2 m-2 bd-highlight small font-weight-bold\"></div>\r\n                                                    </div>\r\n\r\n                                                </div>\r\n                                            </div>\r\n                                            <div class=\"form-group col-sm-12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"initialBC\">\r\n                             Initial BC (Bc)\r\n                          </label>\r\n\r\n                                                <div class=\"input-group\">\r\n                                                    <div class=\"d-flex bd-highlight\">\r\n                                                        <div class=\"p-2 flex-grow-1 bd-highlight\">\r\n                                                            <em *ngIf=\"qcRequestForm.controls.initialBC?.invalid && (qcRequestForm.controls.initialBC?.touched || mouseoverSave)\">Required</em>\r\n                                                            <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"initialBC\" type=\"number\" [(ngModel)]=\"model.initialBC\" name=\"initialBC\" required>\r\n                                                        </div>\r\n                                                        <div class=\"p-2 m-2 bd-highlight small font-weight-bold\"></div>\r\n                                                    </div>\r\n\r\n                                                </div>\r\n                                            </div>\r\n                                            <div class=\"form-group col-sm-12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"rheology\">\r\n                             Rheology (DR @ 300 rpm)\r\n                          </label>\r\n\r\n                                                <div class=\"input-group\">\r\n                                                    <div class=\"d-flex bd-highlight\">\r\n                                                        <div class=\"p-2 flex-grow-1 bd-highlight\">\r\n                                                            <em *ngIf=\"qcRequestForm.controls.rheology?.invalid && (qcRequestForm.controls.rheology?.touched || mouseoverSave)\">Required</em>\r\n                                                            <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"rheology\" type=\"number\" [(ngModel)]=\"model.rheology\" name=\"rheology\" required>\r\n                                                        </div>\r\n                                                        <div class=\"p-2 m-2 bd-highlight small font-weight-bold\"></div>\r\n                                                    </div>\r\n\r\n                                                </div>\r\n                                            </div>\r\n                                        </div>\r\n                                        <div class=\"form-row\">\r\n                                            <div class=\"form-group col-sm-12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"tenSecGelStrength\">\r\n                            <fa-icon icon=\"clock\"></fa-icon> 10sec Gel Strength (lbf/100ft<sup>2</sup>)\r\n                          </label>\r\n\r\n                                                <div class=\"input-group\">\r\n                                                    <div class=\"d-flex bd-highlight\">\r\n                                                        <div class=\"p-2 flex-grow-1 bd-highlight\">\r\n                                                            <em *ngIf=\"qcRequestForm.controls.tenSecGelStrength?.invalid && (qcRequestForm.controls.tenSecGelStrength?.touched || mouseoverSave)\">Required</em>\r\n                                                            <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"tenSecGelStrength\" type=\"number\" [(ngModel)]=\"model.tenSecGelStrength\" name=\"tenSecGelStrength\" required>\r\n                                                        </div>\r\n                                                        <div class=\"p-2 m-2 bd-highlight small font-weight-bold\"></div>\r\n                                                    </div>\r\n\r\n                                                </div>\r\n                                            </div>\r\n                                            <div class=\"form-group col-sm12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"tenMinGelStrength\">\r\n                            <fa-icon icon=\"clock\"></fa-icon> 10min Gel Strength (lbf/100ft<sup>2</sup>)\r\n                          </label>\r\n\r\n                                                <div class=\"input-group\">\r\n                                                    <div class=\"d-flex bd-highlight\">\r\n                                                        <div class=\"p-2 flex-grow-1 bd-highlight\">\r\n                                                            <em *ngIf=\"qcRequestForm.controls.tenMinGelStrength?.invalid && (qcRequestForm.controls.tenMinGelStrength?.touched || mouseoverSave)\">Required</em>\r\n                                                            <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"tenMinGelStrength\" type=\"number\" [(ngModel)]=\"model.tenMinGelStrength\" name=\"tenMinGelStrength\" required>\r\n                                                        </div>\r\n                                                        <div class=\"p-2 m-2 bd-highlight small font-weight-bold\"></div>\r\n                                                    </div>\r\n\r\n                                                </div>\r\n                                            </div>\r\n                                            <div class=\"form-group col-sm12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"density\">\r\n                            <fa-icon icon=\"weight\"></fa-icon> Density (kg/m<sup>3</sup>)\r\n                          </label>\r\n\r\n                                                <div class=\"input-group\">\r\n                                                    <div class=\"d-flex bd-highlight\">\r\n                                                        <div class=\"p-2 flex-grow-1 bd-highlight\">\r\n                                                            <em *ngIf=\"qcRequestForm.controls.density?.invalid && (qcRequestForm.controls.density?.touched || mouseoverSave)\">Required</em>\r\n                                                            <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"density\" type=\"number\" [(ngModel)]=\"model.density\" name=\"density\" required>\r\n                                                        </div>\r\n                                                        <div class=\"p-2 m-2 bd-highlight small font-weight-bold\"></div>\r\n                                                    </div>\r\n\r\n                                                </div>\r\n                                            </div>\r\n                                            <div class=\"form-group col-sm12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"productionWeek\">\r\n                            <fa-icon icon=\"calendar-alt\"></fa-icon> Production Week\r\n                          </label>\r\n\r\n                                                <div class=\"input-group\">\r\n                                                    <em *ngIf=\"qcRequestForm.controls.productionWeek?.invalid && (qcRequestForm.controls.productionWeek?.touched || mouseoverSave)\">Required</em>\r\n                                                    <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" name=\"productionWeek\" [(ngModel)]=\"model.productionWeek\" ngbDatepicker #d=\"ngbDatepicker\">\r\n                                                    <div [hidden]=\"readonly\" class=\"input-group-append\">\r\n                                                        <button class=\"btn btn-sm btn-outline-secondary\" (click)=\"d.toggle()\" type=\"button\">\r\n                              <fa-icon icon=\"calendar-alt\"></fa-icon>\r\n                            </button>\r\n                                                    </div>\r\n                                                </div>\r\n                                            </div>\r\n                                        </div>\r\n                                        <div class=\"form-row\">\r\n                                            <div class=\"form-group col-sm-12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"tenSecGelStrength\">\r\n                                <fa-icon icon=\"water\"></fa-icon> Free Water (%)\r\n                              </label>\r\n\r\n                                                <div class=\"input-group\">\r\n                                                    <div class=\"d-flex bd-highlight\">\r\n                                                        <div class=\"p-2 flex-grow-1 bd-highlight\">\r\n                                                            <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"freeWater\" type=\"number\" [(ngModel)]=\"model.freeWater\" name=\"freeWater\">\r\n                                                        </div>\r\n                                                        <div class=\"p-2 m-2 bd-highlight small font-weight-bold\"></div>\r\n                                                    </div>\r\n\r\n                                                </div>\r\n                                            </div>\r\n                                            <div class=\"form-group col-sm12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"tenMinGelStrength\">\r\n                                 Specific Gravity\r\n                              </label>\r\n\r\n                                                <div class=\"input-group\">\r\n                                                    <div class=\"d-flex bd-highlight\">\r\n                                                        <div class=\"p-2 flex-grow-1 bd-highlight\">\r\n                                                            <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"specificGravity\" type=\"number\" [(ngModel)]=\"model.specificGravity\" name=\"specificGravity\">\r\n                                                        </div>\r\n                                                        <div class=\"p-2 m-2 bd-highlight small font-weight-bold\"></div>\r\n                                                    </div>\r\n\r\n                                                </div>\r\n                                            </div>\r\n                                            <div class=\"form-group col-sm-12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"blaine\">\r\n                                 Blaine (m<sup>2</sup>/kg)\r\n                              </label>\r\n\r\n                                                <div class=\"input-group\">\r\n                                                    <div class=\"d-flex bd-highlight\">\r\n                                                        <div class=\"p-2 flex-grow-1 bd-highlight\">\r\n                                                            <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"blaine\" type=\"number\" [(ngModel)]=\"model.blaine\" name=\"blaine\">\r\n                                                        </div>\r\n                                                        <div class=\"p-2 m-2 bd-highlight small font-weight-bold\"></div>\r\n                                                    </div>\r\n\r\n                                                </div>\r\n                                            </div>\r\n                                            <div class=\"form-group col-sm12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"retainedSieve\">\r\n                                 Retained Sieve (% Retained on 45µ sieve)\r\n                              </label>\r\n\r\n\r\n                                                <div class=\"input-group\">\r\n                                                    <div class=\"d-flex bd-highlight\">\r\n                                                        <div class=\"p-2 flex-grow-1 bd-highlight\">\r\n                                                            <em *ngIf=\"qcRequestForm.controls.retainedSieve?.invalid && (qcRequestForm.controls.retainedSieve?.touched || mouseoverSave)\">Required</em>\r\n                                                            <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"retainedSieve\" type=\"number\" [(ngModel)]=\"model.retainedSieve\" name=\"retainedSieve\" required>\r\n                                                        </div>\r\n                                                        <div class=\"p-2 m-2 bd-highlight small font-weight-bold\"></div>\r\n                                                    </div>\r\n\r\n                                                </div>\r\n                                            </div>\r\n\r\n                                        </div>\r\n                                        <div class=\"form-row\">\r\n\r\n                                            <div class=\"form-group col-sm12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"vicatInitialSet\">\r\n                             Vicat Initial Set (min)\r\n                          </label>\r\n                                                <div class=\"input-group\">\r\n                                                    <div class=\"d-flex bd-highlight\">\r\n                                                        <div class=\"p-2 flex-grow-1 bd-highlight\">\r\n                                                            <em *ngIf=\"qcRequestForm.controls.vicatInitialSet?.invalid && (qcRequestForm.controls.vicatInitialSet?.touched || mouseoverSave)\">Required</em>\r\n                                                            <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"vicatInitialSet\" type=\"number\" [(ngModel)]=\"model.vicatInitialSet\" name=\"vicatInitialSet\" required>\r\n                                                        </div>\r\n                                                        <div class=\"p-2 m-2 bd-highlight small font-weight-bold\"></div>\r\n                                                    </div>\r\n\r\n                                                </div>\r\n                                            </div>\r\n                                            <div class=\"form-group col-sm12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"oneDay\">\r\n                            <fa-icon icon=\"calendar-day\"></fa-icon> One Day (Compressive Strength, MPa)\r\n                          </label>\r\n                                                <div class=\"input-group\">\r\n                                                    <div class=\"d-flex bd-highlight\">\r\n                                                        <div class=\"p-2 flex-grow-1 bd-highlight\">\r\n                                                            <em *ngIf=\"qcRequestForm.controls.oneDay?.invalid && (qcRequestForm.controls.oneDay?.touched || mouseoverSave)\">Required</em>\r\n                                                            <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"oneDay\" type=\"number\" [(ngModel)]=\"model.oneDay\" name=\"oneDay\" required>\r\n                                                        </div>\r\n                                                        <div class=\"p-2 m-2 bd-highlight small font-weight-bold\"></div>\r\n                                                    </div>\r\n\r\n                                                </div>\r\n                                            </div>\r\n                                            <div class=\"form-group col-sm12 col-md-3\">\r\n\r\n                                            </div>\r\n                                            <div class=\"form-group col-sm12 col-md-3\">\r\n                                            </div>\r\n                                        </div>\r\n                                    </form>\r\n                                </ng-template>\r\n\r\n                            </ngb-tab>\r\n                        </ngb-tabset>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>"

/***/ }),

/***/ "./src/app/qc-request/components/qc-request-detail/qc-request-detail.component.scss":
/*!******************************************************************************************!*\
  !*** ./src/app/qc-request/components/qc-request-detail/qc-request-detail.component.scss ***!
  \******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "em {\n  float: right;\n  color: #E05C65;\n  padding-left: 10px; }\n\n.error input {\n  background-color: #E3C3C5; }\n\n.error ::-webkit-input-placeholder {\n  color: #999; }\n\n.error ::-moz-placeholder {\n  color: #999; }\n\n.error :-moz-placeholder {\n  color: #999; }\n\n.error :-ms-input-placeholder {\n  color: #999; }\n\n.form-wdith {\n  width: 100%; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcWMtcmVxdWVzdC9jb21wb25lbnRzL3FjLXJlcXVlc3QtZGV0YWlsL0U6XFxmcm9udGVuZDIvc3JjXFxhcHBcXHFjLXJlcXVlc3RcXGNvbXBvbmVudHNcXHFjLXJlcXVlc3QtZGV0YWlsXFxxYy1yZXF1ZXN0LWRldGFpbC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFlBQVk7RUFDWixjQUFjO0VBQ2Qsa0JBQWtCLEVBQUE7O0FBR3RCO0VBQ0kseUJBQXlCLEVBQUE7O0FBRzdCO0VBQ0ksV0FBVyxFQUFBOztBQUdmO0VBQ0ksV0FBVyxFQUFBOztBQUdmO0VBQ0ksV0FBVyxFQUFBOztBQUdmO0VBQ0ksV0FBVyxFQUFBOztBQUdmO0VBQ0ksV0FBVyxFQUFBIiwiZmlsZSI6InNyYy9hcHAvcWMtcmVxdWVzdC9jb21wb25lbnRzL3FjLXJlcXVlc3QtZGV0YWlsL3FjLXJlcXVlc3QtZGV0YWlsLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiZW0ge1xyXG4gICAgZmxvYXQ6IHJpZ2h0O1xyXG4gICAgY29sb3I6ICNFMDVDNjU7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDEwcHg7XHJcbn1cclxuXHJcbi5lcnJvciBpbnB1dCB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRTNDM0M1O1xyXG59XHJcblxyXG4uZXJyb3IgOjotd2Via2l0LWlucHV0LXBsYWNlaG9sZGVyIHtcclxuICAgIGNvbG9yOiAjOTk5O1xyXG59XHJcblxyXG4uZXJyb3IgOjotbW96LXBsYWNlaG9sZGVyIHtcclxuICAgIGNvbG9yOiAjOTk5O1xyXG59XHJcblxyXG4uZXJyb3IgOi1tb3otcGxhY2Vob2xkZXIge1xyXG4gICAgY29sb3I6ICM5OTk7XHJcbn1cclxuXHJcbi5lcnJvciA6LW1zLWlucHV0LXBsYWNlaG9sZGVyIHtcclxuICAgIGNvbG9yOiAjOTk5O1xyXG59XHJcblxyXG4uZm9ybS13ZGl0aCB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxufSJdfQ== */"

/***/ }),

/***/ "./src/app/qc-request/components/qc-request-detail/qc-request-detail.component.ts":
/*!****************************************************************************************!*\
  !*** ./src/app/qc-request/components/qc-request-detail/qc-request-detail.component.ts ***!
  \****************************************************************************************/
/*! exports provided: QcRequestDetailComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "QcRequestDetailComponent", function() { return QcRequestDetailComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _models_qc_request__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../models/qc-request */ "./src/app/qc-request/models/qc-request.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ngx-toastr */ "./node_modules/ngx-toastr/fesm5/ngx-toastr.js");
/* harmony import */ var _services_qc_request_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/qc-request.service */ "./src/app/qc-request/services/qc-request.service.ts");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var src_app_lab_sample_services_lab_sample_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/lab-sample/services/lab-sample.service */ "./src/app/lab-sample/services/lab-sample.service.ts");








var QcRequestDetailComponent = /** @class */ (function () {
    function QcRequestDetailComponent(route, router, toastrService, qcRequestService, labSampleService) {
        this.route = route;
        this.router = router;
        this.toastrService = toastrService;
        this.qcRequestService = qcRequestService;
        this.labSampleService = labSampleService;
        this.readonly = true;
        this.staffList = [];
        this.selectStaffPreLoading = false;
    }
    QcRequestDetailComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.route.params.subscribe(function (params) {
            if (params['id']) {
                var id = params['id'];
                _this.id = id;
                _this.getQcRequest(id);
            }
            else if (params['sampleid']) {
                var id = params['sampleid'];
                _this.readonly = false;
                _this.model = new _models_qc_request__WEBPACK_IMPORTED_MODULE_2__["QCRequest"]();
                _this.model.sampleId = id;
                _this.labSampleService.getLabSample(id).subscribe(function (success) {
                    _this.model.labSample = success;
                });
            }
        });
    };
    QcRequestDetailComponent.prototype.getQcRequest = function (id) {
        var _this = this;
        this.qcRequestService.getQcRequest(id).subscribe(function (response) {
            _this.model = response;
        });
    };
    QcRequestDetailComponent.prototype.cancel = function () {
        if (this.id !== undefined) {
            this.readonly = true;
        }
        else {
            this.router.navigate(['/qc-requests']);
        }
    };
    QcRequestDetailComponent.prototype.save = function (formValues) {
        var _this = this;
        if (this.id === undefined) {
            this.qcRequestService.save(this.model).subscribe(function (success) {
                _this.model.modifiedBy = success.modifiedBy;
                _this.model.modifiedOn = success.modifiedOn;
                _this.model.createdBy = success.createdBy;
                _this.model.createdOn = success.createdOn;
                _this.toastrService.success('Quality Control Test saved successfully.');
            });
        }
        else {
            this.qcRequestService.update(this.model.businessId, this.model).subscribe(function () {
                _this.toastrService.success('Quality Control Test successfully updated.');
            });
        }
        this.readonly = true;
    };
    QcRequestDetailComponent.prototype.edit = function () {
        this.readonly = false;
    };
    QcRequestDetailComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-qc-request-detail',
            template: __webpack_require__(/*! ./qc-request-detail.component.html */ "./src/app/qc-request/components/qc-request-detail/qc-request-detail.component.html"),
            providers: [{ provide: _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_6__["NgbDateAdapter"], useClass: _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_6__["NgbDateNativeAdapter"] }],
            styles: [__webpack_require__(/*! ./qc-request-detail.component.scss */ "./src/app/qc-request/components/qc-request-detail/qc-request-detail.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
            ngx_toastr__WEBPACK_IMPORTED_MODULE_4__["ToastrService"],
            _services_qc_request_service__WEBPACK_IMPORTED_MODULE_5__["QcRequestService"],
            src_app_lab_sample_services_lab_sample_service__WEBPACK_IMPORTED_MODULE_7__["LabSampleService"]])
    ], QcRequestDetailComponent);
    return QcRequestDetailComponent;
}());



/***/ }),

/***/ "./src/app/qc-request/components/qc-request-list/qc-request-list.component.html":
/*!**************************************************************************************!*\
  !*** ./src/app/qc-request/components/qc-request-list/qc-request-list.component.html ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">\r\n    <div class=\"col-12\">\r\n        <div class=\"card\">\r\n            <div class=\"card-header\">\r\n                <fa-icon icon=\"vials\"></fa-icon> Quality Control Test Request\r\n            </div>\r\n            <div class=\"card-body\">\r\n                <div style=\"position: relative; top: 150px\">\r\n                    <ngx-ui-loader [loaderId]=\"'grid-loader'\"></ngx-ui-loader>\r\n                </div>\r\n                <ngx-datatable class=\"bootstrap\" [rows]=\"tableState.data\" [loadingIndicator]=\"tableState.loading\" [columnMode]=\"'force'\" [rowHeight]=\"'auto'\" [summaryRow]=\"false\" [summaryPosition]=\"'bottom'\" [footerHeight]=\"40\" [externalPaging]=\"true\" [externalSorting]=\"true\"\r\n                    [count]=\"tableState.count\" [offset]=\"tableState.page - 1\" [limit]=\"tableState.limit\" (page)='setPage($event)' (sort)=\"onSort($event)\">\r\n\r\n                    <ngx-datatable-column name=\"Login#\" prop=\"loginNo\">\r\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\r\n                            <span class=\"datatable-header-cell-wrapper\">\r\n                    <span class=\"datatable-header-cell-label draggable\" (click)=\"sort(column.prop)\" [ngClass]=\"{'font-weight-bold': tableState.orderBy === column.prop}\">{{ column.name }}</span>\r\n                            <fa-icon [icon]=\"tableState.orderDirection === 'asc' ? 'sort-up' : 'sort-down'\" class=\"float-right\" *ngIf=\"tableState.orderBy === column.prop\"></fa-icon>\r\n                            <input [ngbTypeahead]=\"columnSearch(column.prop)\" type=\"text\" class=\"form-control form-control-sm\" name=\"\" id=\"\" aria-describedby=\"helpId\" placeholder=\"\">\r\n                            </span>\r\n                        </ng-template>\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            <a class=\"text-primary small\" [routerLink]=\"[ '/lab-samples/' + row.sampleId ]\">\r\n                                {{value}}\r\n                                </a>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"Sample\" prop=\"sampleName\">\r\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\r\n                            <span class=\"datatable-header-cell-wrapper\">\r\n                          <span class=\"datatable-header-cell-label draggable\" (click)=\"sort(column.prop)\" [ngClass]=\"{'font-weight-bold': tableState.orderBy === column.prop}\">{{ column.name }}</span>\r\n                            <fa-icon [icon]=\"tableState.orderDirection === 'asc' ? 'sort-up' : 'sort-down'\" class=\"float-right\" *ngIf=\"tableState.orderBy === column.prop\"></fa-icon>\r\n                            <input [ngbTypeahead]=\"columnSearch(column.prop)\" type=\"text\" class=\"form-control form-control-sm\" name=\"\" id=\"\" aria-describedby=\"helpId\" placeholder=\"\">\r\n                            </span>\r\n                        </ng-template>\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            {{value}}\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"TT40\" prop=\"tT40\">\r\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\r\n                            <span class=\"datatable-header-cell-wrapper\">\r\n                              <span class=\"datatable-header-cell-label draggable\" (click)=\"sort(column.prop)\" [ngClass]=\"{'font-weight-bold': tableState.orderBy === column.prop}\">{{ column.name }}</span>\r\n                            <fa-icon [icon]=\"tableState.orderDirection === 'asc' ? 'sort-up' : 'sort-down'\" class=\"float-right\" *ngIf=\"tableState.orderBy === column.prop\"></fa-icon>\r\n                            <input [ngbTypeahead]=\"columnSearch(column.prop)\" type=\"text\" class=\"form-control form-control-sm\" name=\"\" id=\"\" aria-describedby=\"helpId\" placeholder=\"\">\r\n                            </span>\r\n                        </ng-template>\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            {{value}}\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"Intial BC\" prop=\"initialBC\">\r\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\r\n                            <span class=\"datatable-header-cell-wrapper\">\r\n                              <span class=\"datatable-header-cell-label draggable\" (click)=\"sort(column.prop)\" [ngClass]=\"{'font-weight-bold': tableState.orderBy === column.prop}\">{{ column.name }}</span>\r\n                            <fa-icon [icon]=\"tableState.orderDirection === 'asc' ? 'sort-up' : 'sort-down'\" class=\"float-right\" *ngIf=\"tableState.orderBy === column.prop\"></fa-icon>\r\n                            <input [ngbTypeahead]=\"columnSearch(column.prop)\" type=\"text\" class=\"form-control form-control-sm\" name=\"\" id=\"\" aria-describedby=\"helpId\" placeholder=\"\">\r\n                            </span>\r\n                        </ng-template>\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            <span class=\"small\">{{ value }}</span>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"Rheology\" prop=\"rheology\">\r\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\r\n                            <span class=\"datatable-header-cell-wrapper\">\r\n                              <span class=\"datatable-header-cell-label draggable\" (click)=\"sort(column.prop)\" [ngClass]=\"{'font-weight-bold': tableState.orderBy === column.prop}\">{{ column.name }}</span>\r\n                            <fa-icon [icon]=\"tableState.orderDirection === 'asc' ? 'sort-up' : 'sort-down'\" class=\"float-right\" *ngIf=\"tableState.orderBy === column.prop\"></fa-icon>\r\n                            <input [ngbTypeahead]=\"columnSearch(column.prop)\" type=\"text\" class=\"form-control form-control-sm\" name=\"\" id=\"\" aria-describedby=\"helpId\" placeholder=\"\">\r\n                            </span>\r\n                        </ng-template>\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            <span class=\"small\">{{ value }}</span>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"Density\" prop=\"density\">\r\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\r\n                            <span class=\"datatable-header-cell-wrapper\">\r\n                              <span class=\"datatable-header-cell-label draggable\" (click)=\"sort(column.prop)\" [ngClass]=\"{'font-weight-bold': tableState.orderBy === column.prop}\">{{ column.name }}</span>\r\n                            <fa-icon [icon]=\"tableState.orderDirection === 'asc' ? 'sort-up' : 'sort-down'\" class=\"float-right\" *ngIf=\"tableState.orderBy === column.prop\"></fa-icon>\r\n                            <input [ngbTypeahead]=\"columnSearch(column.prop)\" type=\"text\" class=\"form-control form-control-sm\" name=\"\" id=\"\" aria-describedby=\"helpId\" placeholder=\"\">\r\n                            </span>\r\n                        </ng-template>\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            <span class=\"small\">{{ value }}</span>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"10sec Gel\" prop=\"tenSecGelStrength\">\r\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\r\n                            <span class=\"datatable-header-cell-wrapper\">\r\n                              <span class=\"datatable-header-cell-label draggable\" (click)=\"sort(column.prop)\" [ngClass]=\"{'font-weight-bold': tableState.orderBy === column.prop}\">{{ column.name }}</span>\r\n                            <fa-icon [icon]=\"tableState.orderDirection === 'asc' ? 'sort-up' : 'sort-down'\" class=\"float-right\" *ngIf=\"tableState.orderBy === column.prop\"></fa-icon>\r\n                            <input [ngbTypeahead]=\"columnSearch(column.prop)\" type=\"text\" class=\"form-control form-control-sm\" name=\"\" id=\"\" aria-describedby=\"helpId\" placeholder=\"\">\r\n                            </span>\r\n                        </ng-template>\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            <span class=\"small\">{{ value }}</span>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"10min Gel\" prop=\"tenMinGelStrength\">\r\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\r\n                            <span class=\"datatable-header-cell-wrapper\">\r\n                              <span class=\"datatable-header-cell-label draggable\" (click)=\"sort(column.prop)\" [ngClass]=\"{'font-weight-bold': tableState.orderBy === column.prop}\">{{ column.name }}</span>\r\n                            <fa-icon [icon]=\"tableState.orderDirection === 'asc' ? 'sort-up' : 'sort-down'\" class=\"float-right\" *ngIf=\"tableState.orderBy === column.prop\"></fa-icon>\r\n                            <input [ngbTypeahead]=\"columnSearch(column.prop)\" type=\"text\" class=\"form-control form-control-sm\" name=\"\" id=\"\" aria-describedby=\"helpId\" placeholder=\"\">\r\n                            </span>\r\n                        </ng-template>\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            <span class=\"small\">{{ value }}</span>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"\" prop=\"\">\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            <span class=\"small\">\r\n                                <a class=\"text-primary\" [routerLink]=\"[ '/qc-requests/' + row.businessId ]\">\r\n                                  details\r\n                                </a>\r\n                            </span>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                </ngx-datatable>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>"

/***/ }),

/***/ "./src/app/qc-request/components/qc-request-list/qc-request-list.component.scss":
/*!**************************************************************************************!*\
  !*** ./src/app/qc-request/components/qc-request-list/qc-request-list.component.scss ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3FjLXJlcXVlc3QvY29tcG9uZW50cy9xYy1yZXF1ZXN0LWxpc3QvcWMtcmVxdWVzdC1saXN0LmNvbXBvbmVudC5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/qc-request/components/qc-request-list/qc-request-list.component.ts":
/*!************************************************************************************!*\
  !*** ./src/app/qc-request/components/qc-request-list/qc-request-list.component.ts ***!
  \************************************************************************************/
/*! exports provided: QcRequestListComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "QcRequestListComponent", function() { return QcRequestListComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var ngx_ui_loader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ngx-ui-loader */ "./node_modules/ngx-ui-loader/fesm5/ngx-ui-loader.js");
/* harmony import */ var _services_qc_request_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/qc-request.service */ "./src/app/qc-request/services/qc-request.service.ts");
/* harmony import */ var src_app_core_datatable_table_state__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/datatable/table-state */ "./src/app/core/datatable/table-state.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");







var QcRequestListComponent = /** @class */ (function () {
    function QcRequestListComponent(route, qcRequestService, ngxService, router) {
        this.route = route;
        this.qcRequestService = qcRequestService;
        this.ngxService = ngxService;
        this.router = router;
        this.tableState = new src_app_core_datatable_table_state__WEBPACK_IMPORTED_MODULE_5__["TableState"]();
    }
    QcRequestListComponent.prototype.ngOnInit = function () {
        this.getQcRequests();
    };
    QcRequestListComponent.prototype.getQcRequests = function () {
        var _this = this;
        this.ngxService.startLoader('grid-loader');
        this.qcRequestService.getQcRequests(this.tableState.page, this.tableState.limit, this.tableState.filters, this.tableState.orderBy, this.tableState.orderDirection).subscribe(function (response) {
            _this.tableState.attachResponse(response);
            _this.ngxService.stopLoader('grid-loader');
        });
    };
    QcRequestListComponent.prototype.setPage = function (pageInfo) {
        this.tableState.page = pageInfo.offset + 1;
        this.getQcRequests();
    };
    QcRequestListComponent.prototype.onSort = function (event) {
        this.tableState.setOrdering(event.column.prop);
        this.getQcRequests();
    };
    QcRequestListComponent.prototype.sort = function (columnName) {
        this.tableState.setOrdering(columnName);
        this.getQcRequests();
    };
    QcRequestListComponent.prototype.showMe = function (row) {
    };
    QcRequestListComponent.prototype.columnSearch = function (columName$) {
        var _this = this;
        var func = function (text$) {
            return text$.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["debounceTime"])(300), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["distinctUntilChanged"])(), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["map"])(function (term) {
                _this.tableState.setFilter(columName$, term);
                _this.getQcRequests();
            }));
        };
        return func;
    };
    QcRequestListComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-qc-request-list',
            template: __webpack_require__(/*! ./qc-request-list.component.html */ "./src/app/qc-request/components/qc-request-list/qc-request-list.component.html"),
            styles: [__webpack_require__(/*! ./qc-request-list.component.scss */ "./src/app/qc-request/components/qc-request-list/qc-request-list.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
            _services_qc_request_service__WEBPACK_IMPORTED_MODULE_4__["QcRequestService"],
            ngx_ui_loader__WEBPACK_IMPORTED_MODULE_3__["NgxUiLoaderService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], QcRequestListComponent);
    return QcRequestListComponent;
}());



/***/ }),

/***/ "./src/app/qc-request/models/qc-request.ts":
/*!*************************************************!*\
  !*** ./src/app/qc-request/models/qc-request.ts ***!
  \*************************************************/
/*! exports provided: QCRequest */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "QCRequest", function() { return QCRequest; });
var QCRequest = /** @class */ (function () {
    function QCRequest() {
    }
    return QCRequest;
}());



/***/ }),

/***/ "./src/app/qc-request/qc-request-routing.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/qc-request/qc-request-routing.module.ts ***!
  \*********************************************************/
/*! exports provided: QcRequestRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "QcRequestRoutingModule", function() { return QcRequestRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _components_qc_request_detail_qc_request_detail_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/qc-request-detail/qc-request-detail.component */ "./src/app/qc-request/components/qc-request-detail/qc-request-detail.component.ts");
/* harmony import */ var _components_qc_request_list_qc_request_list_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/qc-request-list/qc-request-list.component */ "./src/app/qc-request/components/qc-request-list/qc-request-list.component.ts");





var routes = [
    {
        path: '',
        component: _components_qc_request_list_qc_request_list_component__WEBPACK_IMPORTED_MODULE_4__["QcRequestListComponent"]
    },
    {
        path: 'new/:sampleid',
        component: _components_qc_request_detail_qc_request_detail_component__WEBPACK_IMPORTED_MODULE_3__["QcRequestDetailComponent"]
    },
    {
        path: ':id',
        component: _components_qc_request_detail_qc_request_detail_component__WEBPACK_IMPORTED_MODULE_3__["QcRequestDetailComponent"]
    }
];
var QcRequestRoutingModule = /** @class */ (function () {
    function QcRequestRoutingModule() {
    }
    QcRequestRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], QcRequestRoutingModule);
    return QcRequestRoutingModule;
}());



/***/ }),

/***/ "./src/app/qc-request/qc-request.module.ts":
/*!*************************************************!*\
  !*** ./src/app/qc-request/qc-request.module.ts ***!
  \*************************************************/
/*! exports provided: QcRequestModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "QcRequestModule", function() { return QcRequestModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _qc_request_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./qc-request-routing.module */ "./src/app/qc-request/qc-request-routing.module.ts");
/* harmony import */ var _components_qc_request_list_qc_request_list_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/qc-request-list/qc-request-list.component */ "./src/app/qc-request/components/qc-request-list/qc-request-list.component.ts");
/* harmony import */ var _components_qc_request_detail_qc_request_detail_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/qc-request-detail/qc-request-detail.component */ "./src/app/qc-request/components/qc-request-detail/qc-request-detail.component.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @swimlane/ngx-datatable */ "./node_modules/@swimlane/ngx-datatable/release/index.js");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _fortawesome_angular_fontawesome__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @fortawesome/angular-fontawesome */ "./node_modules/@fortawesome/angular-fontawesome/fesm5/angular-fontawesome.js");
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @fortawesome/free-solid-svg-icons */ "./node_modules/@fortawesome/free-solid-svg-icons/index.es.js");
/* harmony import */ var _fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @fortawesome/fontawesome-svg-core */ "./node_modules/@fortawesome/fontawesome-svg-core/index.es.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var ngx_ui_loader__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ngx-ui-loader */ "./node_modules/ngx-ui-loader/fesm5/ngx-ui-loader.js");
/* harmony import */ var _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ng-select/ng-select */ "./node_modules/@ng-select/ng-select/fesm5/ng-select.js");














var QcRequestModule = /** @class */ (function () {
    function QcRequestModule() {
        _fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_10__["library"].add(_fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faVial"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faSortUp"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faSortDown"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faCalendarAlt"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faBlender"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faHashtag"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faIndustry"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faAddressCard"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faLocationArrow"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faMapMarkerAlt"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faArrowCircleDown"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faInfoCircle"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faVials"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faComment"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faClock"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faArrowCircleLeft"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faDownload"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faWeight"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faCalendarDay"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faCircleNotch"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faEdit"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faTimesCircle"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faWater"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faSave"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faPlus"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faMinus"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faCodeBranch"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faStar"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faPoll"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faVials"]);
    }
    QcRequestModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_components_qc_request_list_qc_request_list_component__WEBPACK_IMPORTED_MODULE_4__["QcRequestListComponent"], _components_qc_request_detail_qc_request_detail_component__WEBPACK_IMPORTED_MODULE_5__["QcRequestDetailComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_6__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ReactiveFormsModule"],
                _qc_request_routing_module__WEBPACK_IMPORTED_MODULE_3__["QcRequestRoutingModule"],
                _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_7__["NgxDatatableModule"],
                _fortawesome_angular_fontawesome__WEBPACK_IMPORTED_MODULE_8__["FontAwesomeModule"],
                _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_11__["NgbModule"],
                ngx_ui_loader__WEBPACK_IMPORTED_MODULE_12__["NgxUiLoaderModule"],
                _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_13__["NgSelectModule"]
            ]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], QcRequestModule);
    return QcRequestModule;
}());



/***/ }),

/***/ "./src/app/qc-request/services/qc-request.service.ts":
/*!***********************************************************!*\
  !*** ./src/app/qc-request/services/qc-request.service.ts ***!
  \***********************************************************/
/*! exports provided: QcRequestService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "QcRequestService", function() { return QcRequestService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _adapters_qc_request_adapter__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../adapters/qc-request-adapter */ "./src/app/qc-request/adapters/qc-request-adapter.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");






var QcRequestService = /** @class */ (function () {
    function QcRequestService(http, qcRequestAdapter) {
        this.http = http;
        this.qcRequestAdapter = qcRequestAdapter;
        this.serviceUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].sldAli + "/qualityControl";
    }
    QcRequestService.prototype.getQcRequest = function (id) {
        var _this = this;
        var url = this.serviceUrl + "/" + id;
        return this.http.get(url)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(function (response) { return _this.qcRequestAdapter.adapt(response); }));
    };
    QcRequestService.prototype.update = function (id, qcRequest) {
        var url = this.serviceUrl + "/" + id;
        return this.http.put(url, qcRequest);
    };
    QcRequestService.prototype.save = function (qcRequest) {
        var _this = this;
        var url = "" + this.serviceUrl;
        return this.http.post(url, qcRequest)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(function (response) { return _this.qcRequestAdapter.adapt(response); }));
    };
    QcRequestService.prototype.getQcRequests = function (page, limit, filters, orderBy, orderDirection) {
        var url = "" + this.serviceUrl;
        var filterQuery = [];
        filters.forEach(function (value, key) {
            key.replace(':', '\:');
            value.replace(':', '\:');
            filterQuery.push(key + ":" + value);
        });
        var q = filterQuery.join('&&');
        var queryParams = [];
        if (page) {
            queryParams.push("page=" + page);
        }
        if (limit) {
            queryParams.push("limit=" + limit);
        }
        if (orderBy) {
            queryParams.push("orderBy=" + orderBy);
        }
        if (orderDirection) {
            queryParams.push("orderDirection=" + orderDirection);
        }
        if (q) {
            queryParams.push("q=" + encodeURIComponent(q));
        }
        var queryString = queryParams.join('&');
        if (queryString) {
            url = url.concat('?', queryString);
        }
        return this.http.get(url);
    };
    QcRequestService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"],
            _adapters_qc_request_adapter__WEBPACK_IMPORTED_MODULE_4__["QcRequestAdapter"]])
    ], QcRequestService);
    return QcRequestService;
}());



/***/ })

}]);
//# sourceMappingURL=qc-request-qc-request-module.js.map