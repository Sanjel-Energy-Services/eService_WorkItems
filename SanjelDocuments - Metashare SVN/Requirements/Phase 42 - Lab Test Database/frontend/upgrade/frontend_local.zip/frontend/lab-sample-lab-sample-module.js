(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["lab-sample-lab-sample-module"],{

/***/ "./src/app/lab-sample/components/lab-sample-detail/lab-sample-detail.component.html":
/*!******************************************************************************************!*\
  !*** ./src/app/lab-sample/components/lab-sample-detail/lab-sample-detail.component.html ***!
  \******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">\r\n    <div class=\"col-12\">\r\n        <div *ngIf=\"model\" class=\"card\">\r\n            <div class=\"card-body\">\r\n                <div class=\"row\">\r\n                    <div class=\"col-12\">\r\n                        <div class=\"row\">\r\n                            <div class=\"col-lg-5 col-md-12\">\r\n                                <h4 class=\"card-title mb-0 text-primary\">\r\n                                    <fa-icon icon=\"vial\" [ngClass]=\"{'text-warning': model.status === 'New', 'text-info': model.status === 'InProgress', 'text-success': model.status === 'Completed', 'text-danger': model.status === 'Cancelled'}\">\r\n                                    </fa-icon>\r\n                                    Lab Sample <span class=\"font-weight-bold\">{{ model.name }}</span>\r\n                                </h4>\r\n\r\n                                <div class=\"small text-muted\">Created on {{ model.createdOn | date }} by {{ model.createdBy }}, last updated on {{ model.modifiedOn | date }} by {{ model.modifiedBy }}</div>\r\n                            </div>\r\n                            <div class=\"col-lg-7 col-md-12\">\r\n                                <div class=\"btn-toolbar float-right\" role=\"toolbar\" aria-label=\"Toolbar\">\r\n                                    <a [hidden]=\"!readonly || hasWaterAnalysis\" class=\"btn btn-sm btn-outline-primary ml-1 mt-1\" [routerLink]=\"[ '/water-analysis/new/' + model.id ]\">\r\n                                        <fa-icon icon=\"tint\"></fa-icon> Request Water Analysis\r\n                                    </a>\r\n                                    <a [hidden]=\"!readonly || hasQCTestRequest\" class=\"btn btn-sm btn-outline-primary ml-1 mt-1\" [routerLink]=\"[ '/qc-requests/new/' + model.id ]\">\r\n                                        <fa-icon icon=\"vials\"></fa-icon> QC Test Request\r\n                                    </a>\r\n                                    <a class=\"btn btn-sm btn-outline-primary ml-1 mt-1\" [routerLink]=\"[ '/lab-samples/' ]\">\r\n                                        <fa-icon icon=\"arrow-circle-left\"></fa-icon> Return to list\r\n                                    </a>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <hr>\r\n                <div class=\"row\">\r\n                    <div class=\"col-12\">\r\n                        <form #labSampleForm=\"ngForm\" autocomplete=\"off\" (ngSubmit)=\"save(labSampleForm.value)\">\r\n                            <ngb-tabset>\r\n                                <ngb-tab>\r\n                                    <ng-template ngbTabTitle><span class=\"text-primary\">\r\n                      <fa-icon icon=\"info-circle\"></fa-icon> Details\r\n                    </span></ng-template>\r\n                                    <ng-template ngbTabContent>\r\n                                        <div class=\"row\">\r\n                                            <div class=\"col-12\">\r\n                                                <div [hidden]=\"!readonly\" class=\"btn-toolbar float-right mb-2\" role=\"toolbar\" aria-label=\"Toolbar\">\r\n                                                    <button type=\"button\" class=\"btn btn-sm btn-outline-primary ml-1\" (click)=\"edit()\">\r\n                            <fa-icon icon=\"edit\"></fa-icon> Edit\r\n                          </button>\r\n                                                </div>\r\n                                                <div [hidden]=\"!readonly\" class=\"btn-toolbar float-right mb-2\" role=\"toolbar\" aria-label=\"Toolbar\">\r\n                                                    <button type=\"button\" class=\"btn btn-sm btn-outline-primary ml-1\" (click)=\"clone()\">\r\n                            <fa-icon icon=\"clone\"></fa-icon> Clone Sample\r\n                          </button>\r\n                                                </div>\r\n                                                <div [hidden]=\"readonly\" class=\"btn-toolbar float-right mb-2\" role=\"toolbar\" aria-label=\"Toolbar\">\r\n                                                    <span (mouseenter)=\"mouseoverSave=true\" (mouseleave)=\"mouseoverSave=false\">\r\n                            <button [disabled]=\"labSampleForm.invalid\" type=\"submit\" class=\"btn btn-sm btn-success ml-1\">\r\n                              <fa-icon icon=\"save\"></fa-icon> Save\r\n                            </button></span>\r\n                                                    <button type=\"button\" class=\"btn btn-sm btn-outline-primary ml-1\" (click)=\"cancel()\">\r\n                            <fa-icon icon=\"times-circle\"></fa-icon> Cancel\r\n                          </button>\r\n                                                </div>\r\n                                            </div>\r\n                                        </div>\r\n\r\n                                        <div class=\"form-row\">\r\n                                            <div class=\"form-group col-sm-12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"model.qcNumber\">\r\n                          <fa-icon icon=\"hashtag\"></fa-icon> Login #\r\n                        </label>\r\n                                                <input readonly class=\"form-control-plaintext\" id=\"loginNo\" type=\"text\" [(ngModel)]=\"model.loginNo\" name=\"loginNo\">\r\n                                            </div>\r\n                                            <div class=\"form-group col-sm-12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"model.name\">\r\n                          <fa-icon icon=\"address-card\"></fa-icon> Sample Name\r\n                        </label>\r\n                                                <em *ngIf=\"labSampleForm.controls.name?.invalid && (labSampleForm.controls.name?.touched || mouseoverSave)\">Required</em>\r\n                                                <div class=\"input-group\">\r\n                                                    <input autofocus [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"name\" name=\"name\" [(ngModel)]=\"model.name\" required>\r\n\r\n                                                </div>\r\n                                            </div>\r\n                                            <div class=\"form-group col-sm-12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"model.client\">\r\n                          <fa-icon icon=\"industry\"></fa-icon> Client\r\n                        </label>\r\n                                                <em *ngIf=\"labSampleForm.controls.client?.invalid && (labSampleForm.controls.client?.touched || mouseoverSave)\">Required</em>\r\n                                                <input [hidden]=\"!readonly\" readonly [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"client\" type=\"text\" [(ngModel)]=\"model.client\" name=\"client\">\r\n                                                <ng-select [hidden]=\"readonly\" [items]=\"clientList\" [typeahead]=\"selectClientInput\" [loading]=\"selectClientPreLoading\" bindLabel=\"company_name\" bindValue=\"company_name\" (change)=\"setClientId()\" [(ngModel)]=\"model.client\" name=\"client\">\r\n                                                </ng-select>\r\n                                            </div>\r\n\r\n                                        </div>\r\n                                        <div class=\"form-row\">\r\n                                            <div class=\"form-group col-sm-12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"model.wellName\">\r\n                          <fa-icon icon=\"arrow-circle-down\"></fa-icon> Well Name\r\n                        </label>\r\n                                                <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"wellName\" type=\"text\" [(ngModel)]=\"model.wellName\" name=\"wellName\">\r\n                                            </div>\r\n                                            <div class=\"form-group col-sm-12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"district\">\r\n                          <fa-icon icon=\"location-arrow\"></fa-icon> District\r\n                        </label>\r\n                                                <input [hidden]=\"!readonly\" readonly [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"district\" type=\"text\" [(ngModel)]=\"model.district\" name=\"district\">\r\n                                                <ng-select [hidden]=\"readonly\" [items]=\"districtList\" [typeahead]=\"selectDistrictInput\" [loading]=\"selectDistrictPreLoading\" bindLabel=\"name\" bindValue=\"name\" (change)=\"setDistrictId()\" [(ngModel)]=\"model.district\" name=\"district\">\r\n                                                </ng-select>\r\n                                            </div>\r\n                                            <div class=\"form-group col-sm-12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"well.servicePoint\">\r\n                          Type\r\n                        </label>\r\n                                                <em *ngIf=\"labSampleForm.controls.type?.invalid && (labSampleForm.controls.type?.touched || mouseoverSave)\">Required</em>\r\n                                                <input [hidden]=\"!readonly\" readonly [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"client\" type=\"text\" [(ngModel)]=\"model.type\" name=\"type\">\r\n                                                <ng-select [hidden]=\"readonly\" [items]=\"typeList\" [(ngModel)]=\"model.type\" name=\"type\" required>\r\n                                                </ng-select>\r\n                                            </div>\r\n\r\n                                        </div>\r\n                                        <div class=\"form-row\">\r\n                                            <div class=\"form-group col-sm-12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"model.quantity\">\r\n                          Quantity\r\n                        </label>\r\n                                                <em *ngIf=\"labSampleForm.controls.quantity?.invalid && (labSampleForm.controls.quantity?.touched || mouseoverSave)\">Required</em>\r\n                                                <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"quantity\" type=\"text\" [(ngModel)]=\"model.quantity\" name=\"quantity\" required>\r\n                                            </div>\r\n                                            <div class=\"form-group col-sm-12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"model.containerCount\">\r\n                          Container Count\r\n                        </label>\r\n                                                <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"containerCount\" type=\"text\" [(ngModel)]=\"model.containerCount\" name=\"containerCount\">\r\n                                            </div>\r\n                                            <div class=\"form-group col-sm-12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"model.lsd\">\r\n                          LSD\r\n                        </label>\r\n                                                <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" type=\"text\" [(ngModel)]=\"model.lsd\" name=\"lsd\">\r\n                                            </div>\r\n\r\n                                        </div>\r\n                                        <div class=\"form-row\">\r\n                                            <div class=\"form-group col-sm-12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"dateCollected\">\r\n                          Date Collected\r\n                        </label>\r\n                                                <div class=\"input-group\">\r\n                                                    <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" name=\"dateCollected\" [(ngModel)]=\"model.dateCollected\" ngbDatepicker #d=\"ngbDatepicker\">\r\n                                                    <div [hidden]=\"readonly\" class=\"input-group-append\">\r\n                                                        <button class=\"btn btn-sm btn-outline-secondary\" (click)=\"d.toggle()\" type=\"button\">\r\n                              <fa-icon icon=\"calendar-alt\"></fa-icon>\r\n                            </button>\r\n                                                    </div>\r\n                                                </div>\r\n                                            </div>\r\n                                            <div class=\"form-group col-sm-12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"model.sampleSource\">\r\n                          Sample Source\r\n                        </label>\r\n                                                <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"sampleSource\" type=\"text\" [(ngModel)]=\"model.sampleSource\" name=\"sampleSource\">\r\n                                            </div>\r\n                                            <div class=\"form-group col-sm-12 col-md-3\">\r\n                                                <label class=\"small font-weight-bold\" for=\"model.mtsNumber\">\r\n                          MTS #\r\n                        </label>\r\n                                                <input [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" type=\"text\" [(ngModel)]=\"model.mtsNumber\" name=\"mtsNumber\">\r\n                                            </div>\r\n\r\n                                        </div>\r\n                                        <div class=\"form-row\">\r\n                                            <div class=\"form-group col-sm-12 col-md-6\">\r\n                                                <label class=\"small font-weight-bold\" for=\"model.wellName\">\r\n                          Comments\r\n                        </label>\r\n                                                <textarea [readonly]=\"readonly\" [ngClass]=\"readonly ? 'form-control-plaintext' : 'form-control'\" id=\"comments\" type=\"text\" [(ngModel)]=\"model.comments\" name=\"comments\"></textarea>\r\n                                            </div>\r\n                                        </div>\r\n\r\n                                    </ng-template>\r\n                                </ngb-tab>\r\n                            </ngb-tabset>\r\n                        </form>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>"

/***/ }),

/***/ "./src/app/lab-sample/components/lab-sample-detail/lab-sample-detail.component.scss":
/*!******************************************************************************************!*\
  !*** ./src/app/lab-sample/components/lab-sample-detail/lab-sample-detail.component.scss ***!
  \******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "em {\n  float: right;\n  color: #E05C65;\n  padding-left: 10px; }\n\n.error input {\n  background-color: #E3C3C5; }\n\n.error ::-webkit-input-placeholder {\n  color: #999; }\n\n.error ::-moz-placeholder {\n  color: #999; }\n\n.error :-moz-placeholder {\n  color: #999; }\n\n.error :-ms-input-placeholder {\n  color: #999; }\n\n.form-wdith {\n  width: 100%; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbGFiLXNhbXBsZS9jb21wb25lbnRzL2xhYi1zYW1wbGUtZGV0YWlsL0U6XFxmcm9udGVuZDIvc3JjXFxhcHBcXGxhYi1zYW1wbGVcXGNvbXBvbmVudHNcXGxhYi1zYW1wbGUtZGV0YWlsXFxsYWItc2FtcGxlLWRldGFpbC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFlBQVk7RUFDWixjQUFjO0VBQ2Qsa0JBQWtCLEVBQUE7O0FBR3RCO0VBQ0kseUJBQXlCLEVBQUE7O0FBRzdCO0VBQ0ksV0FBVyxFQUFBOztBQUdmO0VBQ0ksV0FBVyxFQUFBOztBQUdmO0VBQ0ksV0FBVyxFQUFBOztBQUdmO0VBQ0ksV0FBVyxFQUFBOztBQUdmO0VBQ0ksV0FBVyxFQUFBIiwiZmlsZSI6InNyYy9hcHAvbGFiLXNhbXBsZS9jb21wb25lbnRzL2xhYi1zYW1wbGUtZGV0YWlsL2xhYi1zYW1wbGUtZGV0YWlsLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiZW0ge1xyXG4gICAgZmxvYXQ6IHJpZ2h0O1xyXG4gICAgY29sb3I6ICNFMDVDNjU7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDEwcHg7XHJcbn1cclxuXHJcbi5lcnJvciBpbnB1dCB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRTNDM0M1O1xyXG59XHJcblxyXG4uZXJyb3IgOjotd2Via2l0LWlucHV0LXBsYWNlaG9sZGVyIHtcclxuICAgIGNvbG9yOiAjOTk5O1xyXG59XHJcblxyXG4uZXJyb3IgOjotbW96LXBsYWNlaG9sZGVyIHtcclxuICAgIGNvbG9yOiAjOTk5O1xyXG59XHJcblxyXG4uZXJyb3IgOi1tb3otcGxhY2Vob2xkZXIge1xyXG4gICAgY29sb3I6ICM5OTk7XHJcbn1cclxuXHJcbi5lcnJvciA6LW1zLWlucHV0LXBsYWNlaG9sZGVyIHtcclxuICAgIGNvbG9yOiAjOTk5O1xyXG59XHJcblxyXG4uZm9ybS13ZGl0aCB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxufSJdfQ== */"

/***/ }),

/***/ "./src/app/lab-sample/components/lab-sample-detail/lab-sample-detail.component.ts":
/*!****************************************************************************************!*\
  !*** ./src/app/lab-sample/components/lab-sample-detail/lab-sample-detail.component.ts ***!
  \****************************************************************************************/
/*! exports provided: LabSampleDetailComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LabSampleDetailComponent", function() { return LabSampleDetailComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_lab_sample_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/lab-sample.service */ "./src/app/lab-sample/services/lab-sample.service.ts");
/* harmony import */ var _models_lab_sample__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../models/lab-sample */ "./src/app/lab-sample/models/lab-sample.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ngx-toastr */ "./node_modules/ngx-toastr/fesm5/ngx-toastr.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var src_app_master_data_services_service_point_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/master-data/services/service-point.service */ "./src/app/master-data/services/service-point.service.ts");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var src_app_water_analysis_services_water_analysis_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/water-analysis/services/water-analysis.service */ "./src/app/water-analysis/services/water-analysis.service.ts");











var LabSampleDetailComponent = /** @class */ (function () {
    function LabSampleDetailComponent(labSampleService, servicePointService, waterAnalysisService, router, route, toastrService) {
        this.labSampleService = labSampleService;
        this.servicePointService = servicePointService;
        this.waterAnalysisService = waterAnalysisService;
        this.router = router;
        this.route = route;
        this.toastrService = toastrService;
        this.readonly = true;
        this.selectDistrictPreLoading = false;
        this.selectClientPreLoading = false;
        this.hasWaterAnalysis = false;
        this.hasQCTestRequest = false;
        this.selectDistrictInput = new rxjs__WEBPACK_IMPORTED_MODULE_6__["Subject"]();
        this.selectClientInput = new rxjs__WEBPACK_IMPORTED_MODULE_6__["Subject"]();
        this.districtList = [];
        this.clientList = [];
        this.typeList = ['Additive', 'Cement', 'Experimental', 'Water', 'Other'];
    }
    LabSampleDetailComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.subscription = this.route.params.subscribe(function (params) {
            _this.id = params['id'];
        });
        if (this.id === 'new') {
            this.model = new _models_lab_sample__WEBPACK_IMPORTED_MODULE_3__["LabSample"]();
            this.readonly = false;
        }
        else {
            this.getLabSample(this.id);
        }
        this.selectDistrictInput.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["debounceTime"])(500), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["distinctUntilChanged"])()).subscribe(function (term) {
            _this.selectDistrictPreLoading = true;
            _this.lookupDistrict(term);
        });
        this.selectClientInput.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["debounceTime"])(500), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_7__["distinctUntilChanged"])()).subscribe(function (term) {
            _this.selectClientPreLoading = true;
            _this.lookupClient(term);
        });
    };
    LabSampleDetailComponent.prototype.getLabSample = function (id) {
        var _this = this;
        this.labSampleService.getLabSample(this.id).subscribe(function (response) {
            _this.model = response;
            _this.hasWaterAnalysis = _this.model.waterAnalysis !== null && _this.model.waterAnalysis !== undefined;
            _this.hasQCTestRequest = _this.model.qualityControl !== null && _this.model.qualityControl !== undefined;
        });
    };
    LabSampleDetailComponent.prototype.lookupDistrict = function (term) {
        var _this = this;
        this.servicePointService.lookupDistrict(term)
            .subscribe(function (response) {
            _this.selectDistrictPreLoading = false;
            _this.districtList = response;
        });
    };
    LabSampleDetailComponent.prototype.lookupClient = function (term) {
        var _this = this;
        this.servicePointService.lookupClient(term)
            .subscribe(function (response) {
            _this.selectClientPreLoading = false;
            _this.clientList = response;
        });
    };
    LabSampleDetailComponent.prototype.setDistrictId = function () {
        var _this = this;
        if (this.districtList !== undefined) {
            this.districtList.forEach(function (d) {
                if (d.name === _this.model.district) {
                    _this.model.districtId = d.id;
                }
            });
        }
    };
    LabSampleDetailComponent.prototype.setClientId = function () {
        var _this = this;
        if (this.clientList !== undefined) {
            this.clientList.forEach(function (d) {
                if (d.company_name === _this.model.client) {
                    _this.model.clientId = d.client_ID;
                }
            });
        }
    };
    LabSampleDetailComponent.prototype.ngOnDestroy = function () {
        this.subscription.unsubscribe();
    };
    LabSampleDetailComponent.prototype.cancel = function () {
        if (this.id === 'new') {
            this.router.navigate(['lab-samples']);
        }
        else {
            this.readonly = true;
        }
    };
    LabSampleDetailComponent.prototype.edit = function () {
        this.readonly = false;
    };
    LabSampleDetailComponent.prototype.clone = function () {
        this.readonly = false;
        this.id = 'new';
        this.model.loginNo = null;
    };
    LabSampleDetailComponent.prototype.save = function (formValues) {
        var _this = this;
        if (this.id === 'new') {
            this.labSampleService.saveLabSample(this.model).subscribe(function (success) {
                _this.id = success.id;
                _this.model.id = success.id;
                _this.model.loginNo = success.loginNo;
                _this.model.modifiedBy = success.modifiedBy;
                _this.model.modifiedOn = success.modifiedOn;
                _this.model.createdBy = success.createdBy;
                _this.model.createdDate = success.createdDate;
                _this.toastrService.success('Login Sample saved successfully.');
                _this.readonly = true;
            }, function (err) {
                _this.readonly = false;
            });
        }
        else {
            this.labSampleService.updateLabSample(this.model.id, this.model).subscribe(function (success) {
                _this.toastrService.success('Login Sample successfully updated.');
                _this.readonly = true;
            });
        }
    };
    LabSampleDetailComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-lab-sample-detail',
            template: __webpack_require__(/*! ./lab-sample-detail.component.html */ "./src/app/lab-sample/components/lab-sample-detail/lab-sample-detail.component.html"),
            providers: [{ provide: _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_9__["NgbDateAdapter"], useClass: _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_9__["NgbDateNativeAdapter"] }],
            styles: [__webpack_require__(/*! ./lab-sample-detail.component.scss */ "./src/app/lab-sample/components/lab-sample-detail/lab-sample-detail.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_lab_sample_service__WEBPACK_IMPORTED_MODULE_2__["LabSampleService"],
            src_app_master_data_services_service_point_service__WEBPACK_IMPORTED_MODULE_8__["ServicePointService"],
            src_app_water_analysis_services_water_analysis_service__WEBPACK_IMPORTED_MODULE_10__["WaterAnalysisService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"],
            ngx_toastr__WEBPACK_IMPORTED_MODULE_5__["ToastrService"]])
    ], LabSampleDetailComponent);
    return LabSampleDetailComponent;
}());



/***/ }),

/***/ "./src/app/lab-sample/components/lab-sample-list/lab-sample-list.component.html":
/*!**************************************************************************************!*\
  !*** ./src/app/lab-sample/components/lab-sample-list/lab-sample-list.component.html ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">\r\n    <div class=\"col-12\">\r\n        <div class=\"card\">\r\n            <div class=\"card-header\">\r\n                <fa-icon icon=\"vial\"></fa-icon> Lab Samples<a class=\"btn btn-primary float-right\" [routerLink]=\"['/lab-samples/new']\" role=\"button\">New Sample</a>\r\n            </div>\r\n            <div class=\"card-body\">\r\n                <div style=\"position: relative; top: 150px\">\r\n                    <ngx-ui-loader [loaderId]=\"'grid-loader'\"></ngx-ui-loader>\r\n                </div>\r\n                <ngx-datatable class=\"bootstrap\" [rows]=\"tableState.data\" [loadingIndicator]=\"tableState.loading\" [columnMode]=\"'force'\" [rowHeight]=\"'auto'\" [summaryRow]=\"true\" [summaryPosition]=\"'bottom'\" [footerHeight]=\"40\" [externalPaging]=\"true\" [externalSorting]=\"true\"\r\n                    [count]=\"tableState.count\" [offset]=\"tableState.page - 1\" [limit]=\"tableState.limit\" (page)='setPage($event)' (sort)=\"onSort($event)\">\r\n\r\n                    <ngx-datatable-column name=\"Name\" prop=\"name\">\r\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\r\n                            <span class=\"datatable-header-cell-wrapper\">\r\n                <span class=\"datatable-header-cell-label draggable\" (click)=\"sort(column.prop)\" [ngClass]=\"{'font-weight-bold': tableState.orderBy === column.prop}\">{{ column.name }}</span>\r\n                            <fa-icon [icon]=\"tableState.orderDirection === 'asc' ? 'sort-up' : 'sort-down'\" class=\"float-right\" *ngIf=\"tableState.orderBy === column.prop\"></fa-icon>\r\n                            <input [ngbTypeahead]=\"columnSearch(column.prop)\" type=\"text\" class=\"form-control form-control-sm\" name=\"\" id=\"\" aria-describedby=\"helpId\" placeholder=\"\">\r\n                            </span>\r\n                        </ng-template>\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            <a class=\"text-primary small\" [routerLink]=\"[ '/lab-samples/' + row.id ]\">\r\n                              {{value}}\r\n                            </a>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"Date Created\" prop=\"createdDate\">\r\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\r\n                            <span class=\"datatable-header-cell-wrapper\">\r\n                <span class=\"datatable-header-cell-label draggable\" (click)=\"sort('createdOn')\" [ngClass]=\"{'font-weight-bold': tableState.orderBy === column.prop}\">{{ column.name }}</span>\r\n                            <fa-icon [icon]=\"tableState.orderDirection === 'asc' ? 'sort-up' : 'sort-down'\" class=\"float-right\" *ngIf=\"tableState.orderBy === column.prop\"></fa-icon>\r\n                            </span>\r\n                        </ng-template>\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            <span class=\"small\">{{ value | date }}</span>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"Login #\" prop=\"loginNo\">\r\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\r\n                            <span class=\"datatable-header-cell-wrapper\">\r\n                <span class=\"datatable-header-cell-label draggable\" (click)=\"sort(column.prop)\" [ngClass]=\"{'font-weight-bold': tableState.orderBy === column.prop}\">{{ column.name }}</span>\r\n                            <fa-icon [icon]=\"tableState.orderDirection === 'asc' ? 'sort-up' : 'sort-down'\" class=\"float-right\" *ngIf=\"tableState.orderBy === column.prop\"></fa-icon>\r\n                            <input [ngbTypeahead]=\"columnSearch(column.prop)\" type=\"text\" class=\"form-control form-control-sm\" name=\"\" id=\"\" aria-describedby=\"helpId\" placeholder=\"\">\r\n                            </span>\r\n                        </ng-template>\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            <span class=\"small\">{{ value }}</span>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"District\" prop=\"district\" [width]=\"50\">\r\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\r\n                            <span class=\"datatable-header-cell-wrapper\">\r\n                          <span class=\"datatable-header-cell-label draggable\" (click)=\"sort(column.prop)\" [ngClass]=\"{'font-weight-bold': tableState.orderBy === column.prop}\">{{ column.name }}</span>\r\n                            <fa-icon [icon]=\"tableState.orderDirection === 'asc' ? 'sort-up' : 'sort-down'\" class=\"float-right\" *ngIf=\"tableState.orderBy === column.prop\"></fa-icon>\r\n                            <input [ngbTypeahead]=\"columnSearch(column.prop)\" type=\"text\" class=\"form-control form-control-sm\" name=\"\" id=\"\" aria-describedby=\"helpId\" placeholder=\"\">\r\n                            </span>\r\n                        </ng-template>\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            <span class=\"small\">{{ value }}</span>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"Client\" prop=\"client\" [width]=\"50\">\r\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\r\n                            <span class=\"datatable-header-cell-wrapper\">\r\n                          <span class=\"datatable-header-cell-label draggable\" (click)=\"sort(column.prop)\" [ngClass]=\"{'font-weight-bold': tableState.orderBy === column.prop}\">{{ column.name }}</span>\r\n                            <fa-icon [icon]=\"tableState.orderDirection === 'asc' ? 'sort-up' : 'sort-down'\" class=\"float-right\" *ngIf=\"tableState.orderBy === column.prop\"></fa-icon>\r\n                            <input [ngbTypeahead]=\"columnSearch(column.prop)\" type=\"text\" class=\"form-control form-control-sm\" name=\"\" id=\"\" aria-describedby=\"helpId\" placeholder=\"\">\r\n                            </span>\r\n                        </ng-template>\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            <span class=\"small\">{{ value }}</span>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"Well Name\" prop=\"wellName\" [width]=\"50\">\r\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\r\n                            <span class=\"datatable-header-cell-wrapper\">\r\n                          <span class=\"datatable-header-cell-label draggable\" (click)=\"sort(column.prop)\" [ngClass]=\"{'font-weight-bold': tableState.orderBy === column.prop}\">{{ column.name }}</span>\r\n                            <fa-icon [icon]=\"tableState.orderDirection === 'asc' ? 'sort-up' : 'sort-down'\" class=\"float-right\" *ngIf=\"tableState.orderBy === column.prop\"></fa-icon>\r\n                            <input [ngbTypeahead]=\"columnSearch(column.prop)\" type=\"text\" class=\"form-control form-control-sm\" name=\"\" id=\"\" aria-describedby=\"helpId\" placeholder=\"\">\r\n                            </span>\r\n                        </ng-template>\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            <span class=\"small\">{{ value }}</span>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"Type\" prop=\"type\" [width]=\"50\">\r\n                        <ng-template let-column=\"column\" ngx-datatable-header-template>\r\n                            <span class=\"datatable-header-cell-wrapper\">\r\n                <span class=\"datatable-header-cell-label draggable\" (click)=\"sort(column.prop)\" [ngClass]=\"{'font-weight-bold': tableState.orderBy === column.prop}\">{{ column.name }}</span>\r\n                            <fa-icon [icon]=\"tableState.orderDirection === 'asc' ? 'sort-up' : 'sort-down'\" class=\"float-right\" *ngIf=\"tableState.orderBy === column.prop\"></fa-icon>\r\n                            <input [ngbTypeahead]=\"columnSearch(column.prop)\" type=\"text\" class=\"form-control form-control-sm\" name=\"\" id=\"\" aria-describedby=\"helpId\" placeholder=\"\">\r\n                            </span>\r\n                        </ng-template>\r\n                        <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\">\r\n                            <span class=\"small\">{{ value }}</span>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                </ngx-datatable>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>"

/***/ }),

/***/ "./src/app/lab-sample/components/lab-sample-list/lab-sample-list.component.scss":
/*!**************************************************************************************!*\
  !*** ./src/app/lab-sample/components/lab-sample-list/lab-sample-list.component.scss ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2xhYi1zYW1wbGUvY29tcG9uZW50cy9sYWItc2FtcGxlLWxpc3QvbGFiLXNhbXBsZS1saXN0LmNvbXBvbmVudC5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/lab-sample/components/lab-sample-list/lab-sample-list.component.ts":
/*!************************************************************************************!*\
  !*** ./src/app/lab-sample/components/lab-sample-list/lab-sample-list.component.ts ***!
  \************************************************************************************/
/*! exports provided: LabSampleListComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LabSampleListComponent", function() { return LabSampleListComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_lab_sample_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/lab-sample.service */ "./src/app/lab-sample/services/lab-sample.service.ts");
/* harmony import */ var ngx_ui_loader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ngx-ui-loader */ "./node_modules/ngx-ui-loader/fesm5/ngx-ui-loader.js");
/* harmony import */ var src_app_core_datatable_table_state__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/datatable/table-state */ "./src/app/core/datatable/table-state.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");






var LabSampleListComponent = /** @class */ (function () {
    function LabSampleListComponent(labSampleService, ngxService) {
        this.labSampleService = labSampleService;
        this.ngxService = ngxService;
        this.tableState = new src_app_core_datatable_table_state__WEBPACK_IMPORTED_MODULE_4__["TableState"]();
    }
    LabSampleListComponent.prototype.ngOnInit = function () {
        this.getLabSamples();
    };
    LabSampleListComponent.prototype.getLabSamples = function () {
        var _this = this;
        this.ngxService.startLoader('grid-loader');
        this.labSampleService.getLabSamples(this.tableState.page, this.tableState.limit, this.tableState.filters, this.tableState.orderBy, this.tableState.orderDirection).subscribe(function (response) {
            _this.tableState.attachResponse(response);
            _this.ngxService.stopLoader('grid-loader');
        });
    };
    LabSampleListComponent.prototype.setPage = function (pageInfo) {
        this.tableState.page = pageInfo.offset + 1;
        this.getLabSamples();
    };
    LabSampleListComponent.prototype.onSort = function (event) {
        this.tableState.setOrdering(event.column.prop);
        this.getLabSamples();
    };
    LabSampleListComponent.prototype.sort = function (columnName) {
        this.tableState.setOrdering(columnName);
        this.getLabSamples();
    };
    LabSampleListComponent.prototype.showMe = function (row) {
    };
    LabSampleListComponent.prototype.columnSearch = function (columName$) {
        var _this = this;
        var func = function (text$) {
            return text$.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["debounceTime"])(300), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["distinctUntilChanged"])(), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(function (term) {
                _this.tableState.setFilter(columName$, term);
                _this.getLabSamples();
            }));
        };
        return func;
    };
    LabSampleListComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-lab-sample-list',
            template: __webpack_require__(/*! ./lab-sample-list.component.html */ "./src/app/lab-sample/components/lab-sample-list/lab-sample-list.component.html"),
            styles: [__webpack_require__(/*! ./lab-sample-list.component.scss */ "./src/app/lab-sample/components/lab-sample-list/lab-sample-list.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_lab_sample_service__WEBPACK_IMPORTED_MODULE_2__["LabSampleService"],
            ngx_ui_loader__WEBPACK_IMPORTED_MODULE_3__["NgxUiLoaderService"]])
    ], LabSampleListComponent);
    return LabSampleListComponent;
}());



/***/ }),

/***/ "./src/app/lab-sample/lab-sample-routing.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/lab-sample/lab-sample-routing.module.ts ***!
  \*********************************************************/
/*! exports provided: LabSampleRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LabSampleRoutingModule", function() { return LabSampleRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _components_lab_sample_list_lab_sample_list_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/lab-sample-list/lab-sample-list.component */ "./src/app/lab-sample/components/lab-sample-list/lab-sample-list.component.ts");
/* harmony import */ var _components_lab_sample_detail_lab_sample_detail_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/lab-sample-detail/lab-sample-detail.component */ "./src/app/lab-sample/components/lab-sample-detail/lab-sample-detail.component.ts");





var routes = [
    {
        path: '',
        component: _components_lab_sample_list_lab_sample_list_component__WEBPACK_IMPORTED_MODULE_3__["LabSampleListComponent"]
    },
    {
        path: ':id',
        component: _components_lab_sample_detail_lab_sample_detail_component__WEBPACK_IMPORTED_MODULE_4__["LabSampleDetailComponent"]
    },
    {
        path: 'new',
        component: _components_lab_sample_detail_lab_sample_detail_component__WEBPACK_IMPORTED_MODULE_4__["LabSampleDetailComponent"]
    }
];
var LabSampleRoutingModule = /** @class */ (function () {
    function LabSampleRoutingModule() {
    }
    LabSampleRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], LabSampleRoutingModule);
    return LabSampleRoutingModule;
}());



/***/ }),

/***/ "./src/app/lab-sample/lab-sample.module.ts":
/*!*************************************************!*\
  !*** ./src/app/lab-sample/lab-sample.module.ts ***!
  \*************************************************/
/*! exports provided: LabSampleModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LabSampleModule", function() { return LabSampleModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _lab_sample_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./lab-sample-routing.module */ "./src/app/lab-sample/lab-sample-routing.module.ts");
/* harmony import */ var _components_lab_sample_list_lab_sample_list_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/lab-sample-list/lab-sample-list.component */ "./src/app/lab-sample/components/lab-sample-list/lab-sample-list.component.ts");
/* harmony import */ var _components_lab_sample_detail_lab_sample_detail_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/lab-sample-detail/lab-sample-detail.component */ "./src/app/lab-sample/components/lab-sample-detail/lab-sample-detail.component.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @swimlane/ngx-datatable */ "./node_modules/@swimlane/ngx-datatable/release/index.js");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _fortawesome_angular_fontawesome__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @fortawesome/angular-fontawesome */ "./node_modules/@fortawesome/angular-fontawesome/fesm5/angular-fontawesome.js");
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @fortawesome/free-solid-svg-icons */ "./node_modules/@fortawesome/free-solid-svg-icons/index.es.js");
/* harmony import */ var _fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @fortawesome/fontawesome-svg-core */ "./node_modules/@fortawesome/fontawesome-svg-core/index.es.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var ngx_ui_loader__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ngx-ui-loader */ "./node_modules/ngx-ui-loader/fesm5/ngx-ui-loader.js");
/* harmony import */ var _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ng-select/ng-select */ "./node_modules/@ng-select/ng-select/fesm5/ng-select.js");














var LabSampleModule = /** @class */ (function () {
    function LabSampleModule() {
        _fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_10__["library"].add(_fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faVial"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faSortUp"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faSortDown"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faCalendarAlt"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faBlender"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faHashtag"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faIndustry"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faAddressCard"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faLocationArrow"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faMapMarkerAlt"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faArrowCircleDown"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faInfoCircle"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faVials"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faComment"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faArrowCircleLeft"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faDownload"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faClone"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faCircleNotch"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faEdit"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faTimesCircle"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faSave"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faPlus"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faMinus"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faCodeBranch"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faStar"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_9__["faPoll"]);
    }
    LabSampleModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_components_lab_sample_list_lab_sample_list_component__WEBPACK_IMPORTED_MODULE_4__["LabSampleListComponent"], _components_lab_sample_detail_lab_sample_detail_component__WEBPACK_IMPORTED_MODULE_5__["LabSampleDetailComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_6__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ReactiveFormsModule"],
                _lab_sample_routing_module__WEBPACK_IMPORTED_MODULE_3__["LabSampleRoutingModule"],
                _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_7__["NgxDatatableModule"],
                _fortawesome_angular_fontawesome__WEBPACK_IMPORTED_MODULE_8__["FontAwesomeModule"],
                _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_11__["NgbModule"],
                ngx_ui_loader__WEBPACK_IMPORTED_MODULE_12__["NgxUiLoaderModule"],
                _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_13__["NgSelectModule"]
            ]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], LabSampleModule);
    return LabSampleModule;
}());



/***/ }),

/***/ "./src/app/lab-sample/models/lab-sample.ts":
/*!*************************************************!*\
  !*** ./src/app/lab-sample/models/lab-sample.ts ***!
  \*************************************************/
/*! exports provided: LabSample */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LabSample", function() { return LabSample; });
var LabSample = /** @class */ (function () {
    function LabSample() {
    }
    return LabSample;
}());



/***/ })

}]);
//# sourceMappingURL=lab-sample-lab-sample-module.js.map