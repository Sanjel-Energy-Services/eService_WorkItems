(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./auth/auth.module": [
		"./src/app/auth/auth.module.ts",
		"auth-auth-module"
	],
	"./home/home.module": [
		"./src/app/home/home.module.ts",
		"home-home-module"
	],
	"./lab-request/lab-request.module": [
		"./src/app/lab-request/lab-request.module.ts",
		"default~lab-request-lab-request-module~lab-sample-lab-sample-module~qc-request-qc-request-module~sea~16d0dd08",
		"common",
		"lab-request-lab-request-module"
	],
	"./lab-sample/lab-sample.module": [
		"./src/app/lab-sample/lab-sample.module.ts",
		"default~lab-request-lab-request-module~lab-sample-lab-sample-module~qc-request-qc-request-module~sea~16d0dd08",
		"common",
		"lab-sample-lab-sample-module"
	],
	"./qc-request/qc-request.module": [
		"./src/app/qc-request/qc-request.module.ts",
		"default~lab-request-lab-request-module~lab-sample-lab-sample-module~qc-request-qc-request-module~sea~16d0dd08",
		"common",
		"qc-request-qc-request-module"
	],
	"./search/search.module": [
		"./src/app/search/search.module.ts",
		"default~lab-request-lab-request-module~lab-sample-lab-sample-module~qc-request-qc-request-module~sea~16d0dd08",
		"common",
		"search-search-module"
	],
	"./user/user.module": [
		"./src/app/user/user.module.ts",
		"default~lab-request-lab-request-module~lab-sample-lab-sample-module~qc-request-qc-request-module~sea~16d0dd08",
		"common",
		"user-user-module"
	],
	"./water-analysis/water-analysis.module": [
		"./src/app/water-analysis/water-analysis.module.ts",
		"default~lab-request-lab-request-module~lab-sample-lab-sample-module~qc-request-qc-request-module~sea~16d0dd08",
		"common",
		"water-analysis-water-analysis-module"
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _core_security_auth_guard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./core/security/auth.guard */ "./src/app/core/security/auth.guard.ts");
/* harmony import */ var _core_security_role_enum__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./core/security/role.enum */ "./src/app/core/security/role.enum.ts");





var routes = [
    { path: '', pathMatch: 'full', redirectTo: 'home' },
    {
        path: 'home',
        loadChildren: './home/home.module#HomeModule',
        canActivate: [_core_security_auth_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]]
    },
    {
        path: 'users',
        loadChildren: './user/user.module#UserModule',
        canActivate: [_core_security_auth_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]],
        data: { roles: [_core_security_role_enum__WEBPACK_IMPORTED_MODULE_4__["Role"].ADMIN] }
    },
    {
        path: 'lab-samples',
        loadChildren: './lab-sample/lab-sample.module#LabSampleModule',
        canActivate: [_core_security_auth_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]],
        data: { roles: [_core_security_role_enum__WEBPACK_IMPORTED_MODULE_4__["Role"].ADMIN, _core_security_role_enum__WEBPACK_IMPORTED_MODULE_4__["Role"].LABTEAM, _core_security_role_enum__WEBPACK_IMPORTED_MODULE_4__["Role"].LABMANAGER] }
    },
    {
        path: 'lab-requests',
        loadChildren: './lab-request/lab-request.module#LabRequestModule',
        canActivate: [_core_security_auth_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]],
        data: { roles: [_core_security_role_enum__WEBPACK_IMPORTED_MODULE_4__["Role"].ADMIN, _core_security_role_enum__WEBPACK_IMPORTED_MODULE_4__["Role"].ENGINEERING_AND_SALES, _core_security_role_enum__WEBPACK_IMPORTED_MODULE_4__["Role"].LABTEAM, _core_security_role_enum__WEBPACK_IMPORTED_MODULE_4__["Role"].LABMANAGER] }
    },
    {
        path: 'experimental',
        loadChildren: './lab-request/lab-request.module#LabRequestModule',
        canActivate: [_core_security_auth_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]],
        data: { roles: [_core_security_role_enum__WEBPACK_IMPORTED_MODULE_4__["Role"].ADMIN, _core_security_role_enum__WEBPACK_IMPORTED_MODULE_4__["Role"].LABTEAM, _core_security_role_enum__WEBPACK_IMPORTED_MODULE_4__["Role"].LABMANAGER] }
    },
    {
        path: 'water-analysis',
        loadChildren: './water-analysis/water-analysis.module#WaterAnalysisModule',
        canActivate: [_core_security_auth_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]],
        data: { roles: [_core_security_role_enum__WEBPACK_IMPORTED_MODULE_4__["Role"].ADMIN, _core_security_role_enum__WEBPACK_IMPORTED_MODULE_4__["Role"].LABTEAM, _core_security_role_enum__WEBPACK_IMPORTED_MODULE_4__["Role"].LABMANAGER] }
    },
    {
        path: 'qc-requests',
        loadChildren: './qc-request/qc-request.module#QcRequestModule',
        canActivate: [_core_security_auth_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]],
        data: { roles: [_core_security_role_enum__WEBPACK_IMPORTED_MODULE_4__["Role"].ADMIN, _core_security_role_enum__WEBPACK_IMPORTED_MODULE_4__["Role"].LABTEAM, _core_security_role_enum__WEBPACK_IMPORTED_MODULE_4__["Role"].LABMANAGER] }
    },
    {
        path: 'search',
        loadChildren: './search/search.module#SearchModule',
        canActivate: [_core_security_auth_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]],
        data: { roles: [_core_security_role_enum__WEBPACK_IMPORTED_MODULE_4__["Role"].ADMIN, _core_security_role_enum__WEBPACK_IMPORTED_MODULE_4__["Role"].ENGINEERING_AND_SALES, _core_security_role_enum__WEBPACK_IMPORTED_MODULE_4__["Role"].LABTEAM, _core_security_role_enum__WEBPACK_IMPORTED_MODULE_4__["Role"].LABMANAGER] }
    },
    {
        path: 'auth',
        loadChildren: './auth/auth.module#AuthModule'
    }
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ngx-ui-loader></ngx-ui-loader>\r\n<div class=\"app header-fixed sidebar-fixed aside-menu-fixed sidebar-show\">\r\n  <app-header></app-header>\r\n  <div class=\"sidebar bg-light\" *ngIf=\"isLoggedIn()\">\r\n    <nav class=\"sidebar-nav\">\r\n      <app-sidebar></app-sidebar>\r\n      \r\n    </nav>\r\n    <button class=\"sidebar-minimizer brand-minimizer\" type=\"button\"></button>\r\n  </div>\r\n  <main role=\"main\" class=\"main\">\r\n    <div class=\"container-fluid\">\r\n      <router-outlet></router-outlet>\r\n    </div>\r\n  </main>\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/app.component.scss":
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/*\r\n * Sidebar\r\n */\n.sidebar {\n  position: fixed;\n  top: 65px;\n  bottom: 0;\n  left: 0;\n  z-index: 100;\n  /* Behind the navbar */\n  padding: 10px 0 0;\n  /* Height of navbar */\n  box-shadow: inset -1px 0 0 rgba(0, 0, 0, 0.1); }\n.ng-select.custom .ng-control {\n  min-height: 20px;\n  height: 20px; }\n/*\r\n * Content\r\n */\n[role=\"main\"] {\n  margin-top: 60px;\n  padding-top: 15px;\n  /* Space for fixed navbar */ }\n/*\r\n * Navbar\r\n */\n/*\r\n * Datatable\r\n */\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvRTpcXGZyb250ZW5kMi9zcmNcXGFwcFxcYXBwLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9hcHAuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7O0VDQ0U7QURHRjtFQUNFLGVBQWU7RUFDZixTQUFTO0VBQ1QsU0FBUztFQUNULE9BQU87RUFDUCxZQUFZO0VBQUUsc0JBQUE7RUFDZCxpQkFBaUI7RUFBRSxxQkFBQTtFQUNuQiw2Q0FBNEMsRUFBQTtBQUc5QztFQUNFLGdCQUFnQjtFQUNoQixZQUFZLEVBQUE7QUFHZDs7RUNBRTtBQUNGO0VESUUsZ0JBQWdCO0VBQ2hCLGlCQUFpQjtFQUFFLDJCQUFBLEVBQTRCO0FBR2pEOztFQ0RFO0FET0Q7O0VDSkMiLCJmaWxlIjoic3JjL2FwcC9hcHAuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuLypcclxuICogU2lkZWJhclxyXG4gKi9cclxuXHJcbi5zaWRlYmFyIHtcclxuICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgdG9wOiA2NXB4O1xyXG4gIGJvdHRvbTogMDtcclxuICBsZWZ0OiAwO1xyXG4gIHotaW5kZXg6IDEwMDsgLyogQmVoaW5kIHRoZSBuYXZiYXIgKi9cclxuICBwYWRkaW5nOiAxMHB4IDAgMDsgLyogSGVpZ2h0IG9mIG5hdmJhciAqL1xyXG4gIGJveC1zaGFkb3c6IGluc2V0IC0xcHggMCAwIHJnYmEoMCwgMCwgMCwgLjEpO1xyXG59XHJcblxyXG4ubmctc2VsZWN0LmN1c3RvbSAubmctY29udHJvbCB7XHJcbiAgbWluLWhlaWdodDogMjBweDtcclxuICBoZWlnaHQ6IDIwcHg7XHJcbn1cclxuXHJcbi8qXHJcbiAqIENvbnRlbnRcclxuICovXHJcblxyXG5bcm9sZT1cIm1haW5cIl0ge1xyXG4gIG1hcmdpbi10b3A6IDYwcHg7XHJcbiAgcGFkZGluZy10b3A6IDE1cHg7IC8qIFNwYWNlIGZvciBmaXhlZCBuYXZiYXIgKi9cclxufVxyXG5cclxuLypcclxuICogTmF2YmFyXHJcbiAqL1xyXG5cclxuXHJcblxyXG4gLypcclxuICogRGF0YXRhYmxlXHJcbiAqLyIsIi8qXHJcbiAqIFNpZGViYXJcclxuICovXG4uc2lkZWJhciB7XG4gIHBvc2l0aW9uOiBmaXhlZDtcbiAgdG9wOiA2NXB4O1xuICBib3R0b206IDA7XG4gIGxlZnQ6IDA7XG4gIHotaW5kZXg6IDEwMDtcbiAgLyogQmVoaW5kIHRoZSBuYXZiYXIgKi9cbiAgcGFkZGluZzogMTBweCAwIDA7XG4gIC8qIEhlaWdodCBvZiBuYXZiYXIgKi9cbiAgYm94LXNoYWRvdzogaW5zZXQgLTFweCAwIDAgcmdiYSgwLCAwLCAwLCAwLjEpOyB9XG5cbi5uZy1zZWxlY3QuY3VzdG9tIC5uZy1jb250cm9sIHtcbiAgbWluLWhlaWdodDogMjBweDtcbiAgaGVpZ2h0OiAyMHB4OyB9XG5cbi8qXHJcbiAqIENvbnRlbnRcclxuICovXG5bcm9sZT1cIm1haW5cIl0ge1xuICBtYXJnaW4tdG9wOiA2MHB4O1xuICBwYWRkaW5nLXRvcDogMTVweDtcbiAgLyogU3BhY2UgZm9yIGZpeGVkIG5hdmJhciAqLyB9XG5cbi8qXHJcbiAqIE5hdmJhclxyXG4gKi9cbi8qXHJcbiAqIERhdGF0YWJsZVxyXG4gKi9cbiJdfQ== */"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _core_security_authentication_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./core/security/authentication.service */ "./src/app/core/security/authentication.service.ts");



var AppComponent = /** @class */ (function () {
    function AppComponent(authenticationService) {
        this.authenticationService = authenticationService;
        this.title = 'Sanjel Lab Database';
    }
    AppComponent.prototype.isLoggedIn = function () {
        return this.authenticationService.isLoggedIn();
    };
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.scss */ "./src/app/app.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_core_security_authentication_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm5/animations.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ngx-toastr */ "./node_modules/ngx-toastr/fesm5/ngx-toastr.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _shared_layout_layout_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./shared/layout/layout.module */ "./src/app/shared/layout/layout.module.ts");
/* harmony import */ var _core_security_auth_interceptor_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./core/security/auth-interceptor.service */ "./src/app/core/security/auth-interceptor.service.ts");
/* harmony import */ var ngx_ui_loader__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ngx-ui-loader */ "./node_modules/ngx-ui-loader/fesm5/ngx-ui-loader.js");
/* harmony import */ var _core_handling_http_error_interceptor__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./core/handling/http-error-interceptor */ "./src/app/core/handling/http-error-interceptor.ts");
/* harmony import */ var ngx_file_drop__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ngx-file-drop */ "./node_modules/ngx-file-drop/fesm5/ngx-file-drop.js");
/* harmony import */ var _lab_result_lab_result_module__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./lab-result/lab-result.module */ "./src/app/lab-result/lab-result.module.ts");





// Third party providers

 // https://ng-bootstrap.github.io/








var ngxUiLoaderConfig = {
    fgsColor: '#6e273d',
    bgsColor: '#6e273d',
    bgsPosition: ngx_ui_loader__WEBPACK_IMPORTED_MODULE_11__["POSITION"].bottomCenter,
    bgsSize: 40,
    bgsType: ngx_ui_loader__WEBPACK_IMPORTED_MODULE_11__["SPINNER"].rectangleBounce,
    fgsType: ngx_ui_loader__WEBPACK_IMPORTED_MODULE_11__["SPINNER"].rectangleBounce,
    hasProgressBar: false,
    threshold: 50
};
var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_8__["AppComponent"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
                _app_routing_module__WEBPACK_IMPORTED_MODULE_7__["AppRoutingModule"],
                _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_6__["NgbModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClientModule"],
                _shared_layout_layout_module__WEBPACK_IMPORTED_MODULE_9__["LayoutModule"],
                _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_3__["BrowserAnimationsModule"],
                ngx_ui_loader__WEBPACK_IMPORTED_MODULE_11__["NgxUiLoaderModule"].forRoot(ngxUiLoaderConfig),
                ngx_toastr__WEBPACK_IMPORTED_MODULE_5__["ToastrModule"].forRoot(),
                ngx_file_drop__WEBPACK_IMPORTED_MODULE_13__["FileDropModule"],
                _lab_result_lab_result_module__WEBPACK_IMPORTED_MODULE_14__["LabResultModule"]
            ],
            providers: [
                {
                    provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HTTP_INTERCEPTORS"],
                    useClass: _core_security_auth_interceptor_service__WEBPACK_IMPORTED_MODULE_10__["AuthInterceptorService"],
                    multi: true
                },
                {
                    provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HTTP_INTERCEPTORS"],
                    useClass: _core_handling_http_error_interceptor__WEBPACK_IMPORTED_MODULE_12__["HttpErrorInterceptor"],
                    multi: true,
                }
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_8__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/core/handling/http-error-interceptor.ts":
/*!*********************************************************!*\
  !*** ./src/app/core/handling/http-error-interceptor.ts ***!
  \*********************************************************/
/*! exports provided: HttpErrorInterceptor */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HttpErrorInterceptor", function() { return HttpErrorInterceptor; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ngx-toastr */ "./node_modules/ngx-toastr/fesm5/ngx-toastr.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _security_authentication_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../security/authentication.service */ "./src/app/core/security/authentication.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var http_status_codes__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! http-status-codes */ "./node_modules/http-status-codes/index.js");
/* harmony import */ var http_status_codes__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(http_status_codes__WEBPACK_IMPORTED_MODULE_7__);








var HttpErrorInterceptor = /** @class */ (function () {
    function HttpErrorInterceptor(toastr, router, authenticationService) {
        this.toastr = toastr;
        this.router = router;
        this.authenticationService = authenticationService;
    }
    HttpErrorInterceptor.prototype.intercept = function (req, next) {
        var _this = this;
        return next
            .handle(req)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["catchError"])(function (error) {
            var errorMessage = '';
            if (error.error instanceof ErrorEvent) {
                // client-side error
                errorMessage = "Error: " + error.error.message;
            }
            else {
                errorMessage = "Error Code: " + error.status + "\nMessage: " + error.message;
                // server-side error
                switch (error.status) {
                    case http_status_codes__WEBPACK_IMPORTED_MODULE_7__["UNAUTHORIZED"]:
                        _this.authenticationService.logout();
                        _this.router.navigateByUrl('auth');
                        errorMessage = 'Token seems to have expired. Kindly login again.';
                        _this.toastr.error(errorMessage);
                        break;
                    case http_status_codes__WEBPACK_IMPORTED_MODULE_7__["BAD_REQUEST"]:
                        _this.toastr.warning("Validation error - " + JSON.stringify(error.error.errors));
                        break;
                    default:
                        _this.toastr.error('An error occured while trying to process request!');
                        break;
                }
            }
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["throwError"])(error);
        }));
    };
    HttpErrorInterceptor = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [ngx_toastr__WEBPACK_IMPORTED_MODULE_3__["ToastrService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"],
            _security_authentication_service__WEBPACK_IMPORTED_MODULE_5__["AuthenticationService"]])
    ], HttpErrorInterceptor);
    return HttpErrorInterceptor;
}());



/***/ }),

/***/ "./src/app/core/security/auth-interceptor.service.ts":
/*!***********************************************************!*\
  !*** ./src/app/core/security/auth-interceptor.service.ts ***!
  \***********************************************************/
/*! exports provided: AuthInterceptorService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthInterceptorService", function() { return AuthInterceptorService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _storage_local_storage_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../storage/local-storage.service */ "./src/app/core/storage/local-storage.service.ts");



var AuthInterceptorService = /** @class */ (function () {
    function AuthInterceptorService(localStorageService) {
        this.localStorageService = localStorageService;
    }
    AuthInterceptorService.prototype.intercept = function (req, next) {
        var jwt_token = this.getAuthorizationToken();
        if (jwt_token) {
            req = req.clone({ setHeaders: { Authorization: "Bearer " + jwt_token } });
        }
        return next.handle(req);
    };
    AuthInterceptorService.prototype.getAuthorizationToken = function () {
        return this.localStorageService.getToken();
    };
    AuthInterceptorService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_storage_local_storage_service__WEBPACK_IMPORTED_MODULE_2__["LocalStorageService"]])
    ], AuthInterceptorService);
    return AuthInterceptorService;
}());



/***/ }),

/***/ "./src/app/core/security/auth.guard.ts":
/*!*********************************************!*\
  !*** ./src/app/core/security/auth.guard.ts ***!
  \*********************************************/
/*! exports provided: AuthGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthGuard", function() { return AuthGuard; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _authentication_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./authentication.service */ "./src/app/core/security/authentication.service.ts");




var AuthGuard = /** @class */ (function () {
    function AuthGuard(router, authenticationService) {
        this.router = router;
        this.authenticationService = authenticationService;
    }
    AuthGuard.prototype.canActivate = function (next, state) {
        var isLoggedIn = this.authenticationService.isLoggedIn();
        if (!isLoggedIn) {
            this.router.navigateByUrl('/auth');
            return false;
        }
        if (next.data.roles) {
            if (!this.authenticationService.hasRole(next.data.roles)) {
                return false;
            }
        }
        return true;
    };
    AuthGuard = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _authentication_service__WEBPACK_IMPORTED_MODULE_3__["AuthenticationService"]])
    ], AuthGuard);
    return AuthGuard;
}());



/***/ }),

/***/ "./src/app/core/security/authentication.service.ts":
/*!*********************************************************!*\
  !*** ./src/app/core/security/authentication.service.ts ***!
  \*********************************************************/
/*! exports provided: AuthenticationService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthenticationService", function() { return AuthenticationService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _storage_local_storage_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../storage/local-storage.service */ "./src/app/core/storage/local-storage.service.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");






var AuthenticationService = /** @class */ (function () {
    function AuthenticationService(http, localStorageService) {
        this.http = http;
        this.localStorageService = localStorageService;
    }
    AuthenticationService.prototype.login = function (userName, password) {
        var _this = this;
        return this.http
            .post(src_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].sldAli + "/auth", {
            userName: userName,
            password: password
        })
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(function (data) {
            if (data) {
                _this.localStorageService.saveToken(data.jwtToken);
                _this.localStorageService.saveUser(data.me.name.trim() ? data.me.name : data.me.userName);
                _this.localStorageService.saveRoles(data.me.roles);
            }
            return data;
        }));
    };
    AuthenticationService.prototype.logout = function () {
        this.localStorageService.removeToken();
    };
    AuthenticationService.prototype.isLoggedIn = function () {
        return !!this.localStorageService.getToken();
    };
    AuthenticationService.prototype.getCurrentUser = function () {
        return this.localStorageService.getUser();
    };
    AuthenticationService.prototype.hasRole = function (roleList) {
        var userRoles = this.localStorageService.getRoles();
        return roleList.filter(function (value) { return userRoles.includes(value); }).length > 0;
    };
    AuthenticationService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"],
            _storage_local_storage_service__WEBPACK_IMPORTED_MODULE_2__["LocalStorageService"]])
    ], AuthenticationService);
    return AuthenticationService;
}());



/***/ }),

/***/ "./src/app/core/security/role.enum.ts":
/*!********************************************!*\
  !*** ./src/app/core/security/role.enum.ts ***!
  \********************************************/
/*! exports provided: Role */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Role", function() { return Role; });
var Role;
(function (Role) {
    Role["ADMIN"] = "admin";
    Role["ENGINEERING_AND_SALES"] = "Engineering_And_Sales";
    Role["LABTEAM"] = "Lab_Team";
    Role["LABMANAGER"] = "Lab_Manager";
})(Role || (Role = {}));


/***/ }),

/***/ "./src/app/core/storage/local-storage.service.ts":
/*!*******************************************************!*\
  !*** ./src/app/core/storage/local-storage.service.ts ***!
  \*******************************************************/
/*! exports provided: LocalStorageService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LocalStorageService", function() { return LocalStorageService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var TOKEN_KEY = 'AuthToken';
var USER_KEY = 'UserInfo';
var ROLE_KEY = 'RoleKey';
var LocalStorageService = /** @class */ (function () {
    function LocalStorageService() {
    }
    LocalStorageService.prototype.removeToken = function () {
        window.localStorage.removeItem(TOKEN_KEY);
        window.localStorage.removeItem(USER_KEY);
    };
    LocalStorageService.prototype.saveUser = function (user) {
        window.localStorage.setItem(USER_KEY, JSON.stringify(user));
    };
    LocalStorageService.prototype.getUser = function () {
        var userString = window.localStorage.getItem(USER_KEY);
        if (userString) {
            try {
                var user = JSON.parse(userString);
                return user;
            }
            catch (e) { }
        }
        return null;
    };
    LocalStorageService.prototype.saveToken = function (token) {
        if (!token) {
            return;
        }
        window.localStorage.setItem(TOKEN_KEY, token);
    };
    LocalStorageService.prototype.getToken = function () {
        return window.localStorage.getItem(TOKEN_KEY);
    };
    LocalStorageService.prototype.saveRoles = function (roles) {
        if (!roles) {
            return;
        }
        window.localStorage.setItem(ROLE_KEY, JSON.stringify(roles));
    };
    LocalStorageService.prototype.getRoles = function () {
        var roles = window.localStorage.getItem(ROLE_KEY);
        if (!roles) {
            return [];
        }
        return JSON.parse(roles);
    };
    LocalStorageService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], LocalStorageService);
    return LocalStorageService;
}());



/***/ }),

/***/ "./src/app/core/utils/file-download.service.ts":
/*!*****************************************************!*\
  !*** ./src/app/core/utils/file-download.service.ts ***!
  \*****************************************************/
/*! exports provided: FileDownloadService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FileDownloadService", function() { return FileDownloadService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _storage_local_storage_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../storage/local-storage.service */ "./src/app/core/storage/local-storage.service.ts");




var FileDownloadService = /** @class */ (function () {
    function FileDownloadService(localStorageService) {
        this.localStorageService = localStorageService;
    }
    /**
     * Downloads a file front the sld api.
     * @param url - SldLab api url
     */
    FileDownloadService.prototype.downloadFile = function (url) {
        var jwt_token = this.localStorageService.getToken();
        return rxjs__WEBPACK_IMPORTED_MODULE_2__["Observable"].create(function (observer) {
            var xhr = new XMLHttpRequest();
            xhr.open('GET', url, true);
            xhr.setRequestHeader('Content-type', 'application/json');
            xhr.setRequestHeader('Authorization', "Bearer " + jwt_token);
            xhr.responseType = 'blob';
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4) {
                    if (xhr.status === 200) {
                        var contentType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
                        var blob = new Blob([xhr.response], { type: contentType });
                        observer.next(blob);
                        observer.complete();
                    }
                    else {
                        observer.error(xhr.response);
                    }
                }
            };
            xhr.send();
        });
    };
    /**
     * Create an anchor and emulate the download.
     * @param content - downloaded blob
     * @param contentType - the content type
     * @param fileName - the name of the file
     */
    FileDownloadService.prototype.emulateDownload = function (content, contentType, fileName) {
        var blob = new Blob([content], { type: contentType });
        var element = document.createElement('a');
        element.href = window.URL.createObjectURL(blob);
        element.download = fileName;
        document.body.appendChild(element);
        element.click();
    };
    FileDownloadService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_storage_local_storage_service__WEBPACK_IMPORTED_MODULE_3__["LocalStorageService"]])
    ], FileDownloadService);
    return FileDownloadService;
}());



/***/ }),

/***/ "./src/app/lab-result/adapters/result-response-adapter.ts":
/*!****************************************************************!*\
  !*** ./src/app/lab-result/adapters/result-response-adapter.ts ***!
  \****************************************************************/
/*! exports provided: ResultResponseAdapter */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ResultResponseAdapter", function() { return ResultResponseAdapter; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _models_result_response__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../models/result-response */ "./src/app/lab-result/models/result-response.ts");
/* harmony import */ var _models_result__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../models/result */ "./src/app/lab-result/models/result.ts");
/* harmony import */ var _models_result_output__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../models/result-output */ "./src/app/lab-result/models/result-output.ts");
/* harmony import */ var _models_result_file_info__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../models/result-file-info */ "./src/app/lab-result/models/result-file-info.ts");






var ResultResponseAdapter = /** @class */ (function () {
    function ResultResponseAdapter() {
    }
    ResultResponseAdapter.prototype.adapt = function (item) {
        return new _models_result_response__WEBPACK_IMPORTED_MODULE_2__["ResultResponse"](item.iterationId, item.results.map(function (result) { return new _models_result__WEBPACK_IMPORTED_MODULE_3__["Result"](result.id, new Date(result.date), result.instrumentId, result.schedule, result.testType, result.approved, result.resultOutputs.map(function (output) { return output.map(function (inner) { return new _models_result_output__WEBPACK_IMPORTED_MODULE_4__["ResultOutput"](inner.label, inner.value, inner.unit); }); }), new _models_result_file_info__WEBPACK_IMPORTED_MODULE_5__["ResultFileInfo"](result.resultFileInfo.id, result.resultFileInfo.name)); }));
    };
    ResultResponseAdapter = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        })
    ], ResultResponseAdapter);
    return ResultResponseAdapter;
}());



/***/ }),

/***/ "./src/app/lab-result/adapters/upload-response-adapter.ts":
/*!****************************************************************!*\
  !*** ./src/app/lab-result/adapters/upload-response-adapter.ts ***!
  \****************************************************************/
/*! exports provided: UploadResponseAdapter */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UploadResponseAdapter", function() { return UploadResponseAdapter; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _models_upload_response__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../models/upload-response */ "./src/app/lab-result/models/upload-response.ts");
/* harmony import */ var _models_upload_metadata__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../models/upload-metadata */ "./src/app/lab-result/models/upload-metadata.ts");




var UploadResponseAdapter = /** @class */ (function () {
    function UploadResponseAdapter() {
    }
    UploadResponseAdapter.prototype.adapt = function (item) {
        var result = new _models_upload_response__WEBPACK_IMPORTED_MODULE_2__["UploadResponse"](item.fileName, item.status, item.status === 200 ? 'uploaded' : 'failed', item.message, new _models_upload_metadata__WEBPACK_IMPORTED_MODULE_3__["UploadMetadata"](item.chartMetadata.requestId, item.chartMetadata.version, item.chartMetadata.iterationId, item.chartMetadata.labTestType, item.chartMetadata.waRequestId));
        return result;
    };
    UploadResponseAdapter = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        })
    ], UploadResponseAdapter);
    return UploadResponseAdapter;
}());



/***/ }),

/***/ "./src/app/lab-result/components/upload-result/upload-result.component.html":
/*!**********************************************************************************!*\
  !*** ./src/app/lab-result/components/upload-result/upload-result.component.html ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div style=\"position: relative; top: 150px\">\r\n    <ngx-ui-loader [loaderId]=\"'grid-loader'\"></ngx-ui-loader>\r\n</div>\r\n<div class=\"modal-header\">\r\n    <h4 class=\"modal-title\" id=\"modal-basic-title\">Upload Test Result</h4>\r\n    <button type=\"button\" class=\"close\" aria-label=\"Close\" (click)=\"onCancel()\">\r\n    <span aria-hidden=\"true\">&times;</span>\r\n  </button>\r\n</div>\r\n<div class=\"modal-body\">\r\n\r\n    <div class=\"row\">\r\n        <div class=\"col-12\">\r\n            <file-drop dropZoneLabel=\"Drop Chart files here\" (onFileDrop)=\"dropped($event)\" (onFileOver)=\"fileOver($event)\" (onFileLeave)=\"fileLeave($event)\">\r\n            </file-drop>\r\n        </div>\r\n        <div class=\"ordiv font-weight-bold\">\r\n            or\r\n        </div>\r\n        <div class=\"col-12\">\r\n            <div class=\"custom-file\">\r\n                <input type=\"file\" class=\"custom-file-input\" id=\"customFile\" (change)=\"handleFileInput($event.target.files)\">\r\n                <label class=\"custom-file-label\" for=\"customFile\">Choose file</label>\r\n            </div>\r\n        </div>\r\n        <hr />\r\n        <div class=\"col-12 mt-3\">\r\n            <table class=\"table\">\r\n                <thead>\r\n                    <tr>\r\n                        <th>Name</th>\r\n                        <th>TestType</th>\r\n                        <th>Status</th>\r\n                        <th></th>\r\n                    </tr>\r\n                </thead>\r\n                <tbody>\r\n                    <tr *ngFor=\"let result of results; let i=index\">\r\n                        <td><strong>{{ result.fileName }}</strong></td>\r\n                        <td>\r\n                            <span *ngIf=\"result.httpStatus == 200\">{{ result.uploadMetadata.labTestType }}</span>\r\n                            <span *ngIf=\"result.httpStatus != 200\">-</span>\r\n                        </td>\r\n                        <td><span class=\"badge\" [ngClass]=\"result.httpStatus == 200 ? 'badge-success' : 'badge-danger'\">{{ result.status }}</span></td>\r\n                        <td>\r\n                            <button *ngIf=\"result.httpStatus == 200\" type=\"button\" class=\"btn btn-link\" (click)=\"goTo(result.uploadMetadata)\">Go to request\r\n                {{ result.uploadMetadata.requestId === 0 ? '' : result.uploadMetadata.requestId }}</button>\r\n                            <span *ngIf=\"result.httpStatus != 200\" class=\"text-danger\">{{ result.message }}</span>\r\n                        </td>\r\n                    </tr>\r\n                </tbody>\r\n            </table>\r\n        </div>\r\n    </div>\r\n</div>\r\n<div class=\"modal-footer\">\r\n    <button type=\"button\" class=\"btn btn-outline-dark\" (click)=\"onCancel()\">Cancel</button>\r\n</div>"

/***/ }),

/***/ "./src/app/lab-result/components/upload-result/upload-result.component.scss":
/*!**********************************************************************************!*\
  !*** ./src/app/lab-result/components/upload-result/upload-result.component.scss ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".ordiv {\n  margin-left: 10px; }\n\n.testdiv {\n  width: 60%; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbGFiLXJlc3VsdC9jb21wb25lbnRzL3VwbG9hZC1yZXN1bHQvRTpcXGZyb250ZW5kMi9zcmNcXGFwcFxcbGFiLXJlc3VsdFxcY29tcG9uZW50c1xcdXBsb2FkLXJlc3VsdFxcdXBsb2FkLXJlc3VsdC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGlCQUFpQixFQUFBOztBQUdyQjtFQUNJLFVBQVUsRUFBQSIsImZpbGUiOiJzcmMvYXBwL2xhYi1yZXN1bHQvY29tcG9uZW50cy91cGxvYWQtcmVzdWx0L3VwbG9hZC1yZXN1bHQuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIub3JkaXYge1xyXG4gICAgbWFyZ2luLWxlZnQ6IDEwcHg7XHJcbn1cclxuXHJcbi50ZXN0ZGl2IHtcclxuICAgIHdpZHRoOiA2MCU7XHJcbn0iXX0= */"

/***/ }),

/***/ "./src/app/lab-result/components/upload-result/upload-result.component.ts":
/*!********************************************************************************!*\
  !*** ./src/app/lab-result/components/upload-result/upload-result.component.ts ***!
  \********************************************************************************/
/*! exports provided: UploadResultComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UploadResultComponent", function() { return UploadResultComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _services_lab_result_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/lab-result.service */ "./src/app/lab-result/services/lab-result.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var ngx_ui_loader__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ngx-ui-loader */ "./node_modules/ngx-ui-loader/fesm5/ngx-ui-loader.js");






var UploadResultComponent = /** @class */ (function () {
    function UploadResultComponent(activeModal, labResultService, ngxService, router) {
        this.activeModal = activeModal;
        this.labResultService = labResultService;
        this.ngxService = ngxService;
        this.router = router;
        this.results = [];
        this.errors = [];
    }
    UploadResultComponent.prototype.ngOnInit = function () {
    };
    UploadResultComponent.prototype.onCancel = function () {
        this.activeModal.close();
    };
    UploadResultComponent.prototype.dropped = function (event) {
        var _this = this;
        var _loop_1 = function (droppedFile) {
            // Is it a file?
            if (droppedFile.fileEntry.isFile) {
                var fileEntry = droppedFile.fileEntry;
                fileEntry.file(function (file) {
                    // Here you can access the real file
                    _this.uploadFile(file, droppedFile.relativePath);
                });
            }
            else {
                // It was a directory (empty directories are added, otherwise only files)
                var fileEntry = droppedFile.fileEntry;
            }
        };
        for (var _i = 0, _a = event.files; _i < _a.length; _i++) {
            var droppedFile = _a[_i];
            _loop_1(droppedFile);
        }
    };
    UploadResultComponent.prototype.handleFileInput = function (files) {
        var file = files.item(0);
        this.uploadFile(file, file.name);
    };
    UploadResultComponent.prototype.uploadFile = function (file, fileName) {
        var _this = this;
        this.ngxService.startLoader('grid-loader');
        this.labResultService.UploadResult(file, fileName).subscribe(function (success) {
            _this.ngxService.stopLoader('grid-loader');
            _this.results.push(success);
        }, function (error) {
            _this.ngxService.stopLoader('grid-loader');
            _this.results.push(error.error);
        });
    };
    UploadResultComponent.prototype.fileOver = function (event) {
    };
    UploadResultComponent.prototype.fileLeave = function (event) {
    };
    UploadResultComponent.prototype.goTo = function (data) {
        this.activeModal.close();
        if (data.requestId === 0) {
            this.router.navigate(["/water-analysis/" + data.waRequestId]);
        }
        else {
            this.router.navigate(["/lab-requests/view/" + data.requestId], { queryParams: { tab: '2', version: data.version } });
        }
    };
    UploadResultComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-upload-result',
            template: __webpack_require__(/*! ./upload-result.component.html */ "./src/app/lab-result/components/upload-result/upload-result.component.html"),
            styles: [__webpack_require__(/*! ./upload-result.component.scss */ "./src/app/lab-result/components/upload-result/upload-result.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_2__["NgbActiveModal"],
            _services_lab_result_service__WEBPACK_IMPORTED_MODULE_3__["LabResultService"],
            ngx_ui_loader__WEBPACK_IMPORTED_MODULE_5__["NgxUiLoaderService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]])
    ], UploadResultComponent);
    return UploadResultComponent;
}());



/***/ }),

/***/ "./src/app/lab-result/lab-result-routing.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/lab-result/lab-result-routing.module.ts ***!
  \*********************************************************/
/*! exports provided: LabResultRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LabResultRoutingModule", function() { return LabResultRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var routes = [];
var LabResultRoutingModule = /** @class */ (function () {
    function LabResultRoutingModule() {
    }
    LabResultRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], LabResultRoutingModule);
    return LabResultRoutingModule;
}());



/***/ }),

/***/ "./src/app/lab-result/lab-result.module.ts":
/*!*************************************************!*\
  !*** ./src/app/lab-result/lab-result.module.ts ***!
  \*************************************************/
/*! exports provided: LabResultModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LabResultModule", function() { return LabResultModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _lab_result_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./lab-result-routing.module */ "./src/app/lab-result/lab-result-routing.module.ts");
/* harmony import */ var ngx_file_drop__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ngx-file-drop */ "./node_modules/ngx-file-drop/fesm5/ngx-file-drop.js");
/* harmony import */ var _components_upload_result_upload_result_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/upload-result/upload-result.component */ "./src/app/lab-result/components/upload-result/upload-result.component.ts");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");









var LabResultModule = /** @class */ (function () {
    function LabResultModule() {
    }
    LabResultModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [
                _components_upload_result_upload_result_component__WEBPACK_IMPORTED_MODULE_5__["UploadResultComponent"]
            ],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _lab_result_routing_module__WEBPACK_IMPORTED_MODULE_3__["LabResultRoutingModule"],
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_7__["BrowserModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_8__["FormsModule"],
                ngx_file_drop__WEBPACK_IMPORTED_MODULE_4__["FileDropModule"],
                _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_6__["NgbModule"]
            ],
            entryComponents: [
                _components_upload_result_upload_result_component__WEBPACK_IMPORTED_MODULE_5__["UploadResultComponent"]
            ],
            exports: [
                _components_upload_result_upload_result_component__WEBPACK_IMPORTED_MODULE_5__["UploadResultComponent"]
            ],
            schemas: [
                _angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]
            ]
        })
    ], LabResultModule);
    return LabResultModule;
}());



/***/ }),

/***/ "./src/app/lab-result/models/result-file-info.ts":
/*!*******************************************************!*\
  !*** ./src/app/lab-result/models/result-file-info.ts ***!
  \*******************************************************/
/*! exports provided: ResultFileInfo */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ResultFileInfo", function() { return ResultFileInfo; });
var ResultFileInfo = /** @class */ (function () {
    function ResultFileInfo(id, name) {
        this.id = id;
        this.name = name;
    }
    return ResultFileInfo;
}());



/***/ }),

/***/ "./src/app/lab-result/models/result-output.ts":
/*!****************************************************!*\
  !*** ./src/app/lab-result/models/result-output.ts ***!
  \****************************************************/
/*! exports provided: ResultOutput */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ResultOutput", function() { return ResultOutput; });
var ResultOutput = /** @class */ (function () {
    function ResultOutput(label, value, unit) {
        this.label = label;
        this.value = value;
        this.unit = unit;
    }
    return ResultOutput;
}());



/***/ }),

/***/ "./src/app/lab-result/models/result-response.ts":
/*!******************************************************!*\
  !*** ./src/app/lab-result/models/result-response.ts ***!
  \******************************************************/
/*! exports provided: ResultResponse */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ResultResponse", function() { return ResultResponse; });
var ResultResponse = /** @class */ (function () {
    function ResultResponse(iterationId, results) {
        this.iterationId = iterationId;
        this.results = results;
    }
    return ResultResponse;
}());



/***/ }),

/***/ "./src/app/lab-result/models/result.ts":
/*!*********************************************!*\
  !*** ./src/app/lab-result/models/result.ts ***!
  \*********************************************/
/*! exports provided: Result */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Result", function() { return Result; });
var Result = /** @class */ (function () {
    function Result(id, date, instrumentId, schedule, testType, approved, resultOutputs, // ResultOutput[],
    resultFileInfo) {
        this.id = id;
        this.date = date;
        this.instrumentId = instrumentId;
        this.schedule = schedule;
        this.testType = testType;
        this.resultOutputs = resultOutputs;
        this.resultFileInfo = resultFileInfo;
        this.approved = approved;
    }
    return Result;
}());



/***/ }),

/***/ "./src/app/lab-result/models/upload-metadata.ts":
/*!******************************************************!*\
  !*** ./src/app/lab-result/models/upload-metadata.ts ***!
  \******************************************************/
/*! exports provided: UploadMetadata */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UploadMetadata", function() { return UploadMetadata; });
var UploadMetadata = /** @class */ (function () {
    function UploadMetadata(requestId, version, iterationId, labTestType, waRequestId) {
        this.requestId = requestId;
        this.version = version;
        this.iterationId = iterationId;
        this.labTestType = labTestType;
        this.waRequestId = waRequestId;
    }
    return UploadMetadata;
}());



/***/ }),

/***/ "./src/app/lab-result/models/upload-response.ts":
/*!******************************************************!*\
  !*** ./src/app/lab-result/models/upload-response.ts ***!
  \******************************************************/
/*! exports provided: UploadResponse */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UploadResponse", function() { return UploadResponse; });
var UploadResponse = /** @class */ (function () {
    function UploadResponse(fileName, httpStatus, status, message, uploadMetadata) {
        this.fileName = fileName;
        this.httpStatus = httpStatus;
        this.status = status;
        this.message = message;
        this.uploadMetadata = uploadMetadata;
    }
    return UploadResponse;
}());



/***/ }),

/***/ "./src/app/lab-result/services/lab-result.service.ts":
/*!***********************************************************!*\
  !*** ./src/app/lab-result/services/lab-result.service.ts ***!
  \***********************************************************/
/*! exports provided: LabResultService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LabResultService", function() { return LabResultService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _adapters_result_response_adapter__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../adapters/result-response-adapter */ "./src/app/lab-result/adapters/result-response-adapter.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var src_app_core_utils_file_download_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/utils/file-download.service */ "./src/app/core/utils/file-download.service.ts");
/* harmony import */ var _adapters_upload_response_adapter__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../adapters/upload-response-adapter */ "./src/app/lab-result/adapters/upload-response-adapter.ts");








var LabResultService = /** @class */ (function () {
    function LabResultService(http, resultResponseAdapter, uploadResponseAdapter, fileDownloadService) {
        this.http = http;
        this.resultResponseAdapter = resultResponseAdapter;
        this.uploadResponseAdapter = uploadResponseAdapter;
        this.fileDownloadService = fileDownloadService;
        this.serviceUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].sldAli + "/results";
    }
    LabResultService.prototype.UploadResult = function (file, fileName) {
        var _this = this;
        var url = this.serviceUrl + "/upload";
        var formData = new FormData();
        formData.append('file', file, fileName);
        return this.http.post(url, formData)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(function (response) { return _this.uploadResponseAdapter.adapt(response); }));
    };
    LabResultService.prototype.GetTemplates = function () {
        var url = this.serviceUrl + "/templates";
        return this.http.get(url);
    };
    LabResultService.prototype.GetResults = function (iterationId) {
        var _this = this;
        var url = this.serviceUrl + "/" + iterationId;
        return this.http.get(url)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])(function (response) { return _this.resultResponseAdapter.adapt(response); }));
    };
    /**
     * Downlaods the file by id
     * @param fileId - the file uuid
     */
    LabResultService.prototype.downloadFileResult = function (fileId) {
        var url = this.serviceUrl + "/" + fileId + "/chartresult";
        return this.fileDownloadService.downloadFile(url);
    };
    LabResultService.prototype.deleteResult = function (resultId) {
        var url = this.serviceUrl + "/" + resultId;
        return this.http.delete(url);
    };
    LabResultService.prototype.approveResult = function (resultId, state) {
        var url = this.serviceUrl + "/" + resultId + "/" + state;
        return this.http.put(url, undefined);
    };
    LabResultService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"],
            _adapters_result_response_adapter__WEBPACK_IMPORTED_MODULE_4__["ResultResponseAdapter"],
            _adapters_upload_response_adapter__WEBPACK_IMPORTED_MODULE_7__["UploadResponseAdapter"],
            src_app_core_utils_file_download_service__WEBPACK_IMPORTED_MODULE_6__["FileDownloadService"]])
    ], LabResultService);
    return LabResultService;
}());



/***/ }),

/***/ "./src/app/shared/layout/header/header.component.html":
/*!************************************************************!*\
  !*** ./src/app/shared/layout/header/header.component.html ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<nav class=\"navbar navbar-expand-md navbar-light sld-nav fixed-top bg-white\">\r\n    <img src=\"assets/sanjel.svg\" alt=\"sanjel energy\" height=\"55px\">\r\n    <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarSupportedContent-4\" aria-controls=\"navbarSupportedContent-4\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">\r\n    <span class=\"navbar-toggler-icon\"></span>\r\n  </button>\r\n    <div *ngIf=\"environmentName !== 'Prod'\" class=\"d-flex flex-fill justify-content-center testdiv\">\r\n        <img src=\"assets/sjtest.png\" alt=\"test\" height=\"55px\">\r\n    </div>\r\n\r\n    <div class=\"collapse navbar-collapse\" id=\"navbarSupportedContent-4\">\r\n        <ul class=\"navbar-nav ml-auto\">\r\n            <li class=\"nav-item\" *ngIf=\"isLoggedIn()\">\r\n                <button class=\"btn btn-sm btn-outline-primary mr-2\">\r\n                  <fa-icon icon=\"user\"></fa-icon>\r\n                   {{ currentUser }}\r\n                </button>\r\n            </li>\r\n            <li class=\"nav-item\" *ngIf=\"isLoggedIn() && isInRole(['admin', 'Lab_Team', 'Lab_Manager'])\">\r\n                <button (click)=\"uploadResult()\" class=\"btn btn-sm btn-outline-primary mr-2\">\r\n          <fa-icon icon=\"upload\"></fa-icon>\r\n          Upload Result\r\n        </button>\r\n            </li>\r\n            <li class=\"nav-item\" *ngIf=\"!isLoggedIn()\">\r\n                <a routerLink=\"/auth\" class=\"nav-link\">\r\n                    <fa-icon icon=\"sign-in-alt\"></fa-icon>Login\r\n                </a>\r\n            </li>\r\n            <li class=\"nav-item\" *ngIf=\"isLoggedIn()\">\r\n                <button (click)=\"logout()\" class=\"btn btn-sm btn-outline-primary\">\r\n          <fa-icon icon=\"sign-out-alt\"></fa-icon>Logout\r\n        </button>\r\n            </li>\r\n        </ul>\r\n    </div>\r\n</nav>"

/***/ }),

/***/ "./src/app/shared/layout/header/header.component.scss":
/*!************************************************************!*\
  !*** ./src/app/shared/layout/header/header.component.scss ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".sld-nav {\n  border-bottom: 1px solid rgba(0, 0, 0, 0.1);\n  height: 65px; }\n\n.testdiv {\n  width: 70%; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hhcmVkL2xheW91dC9oZWFkZXIvRTpcXGZyb250ZW5kMi9zcmNcXGFwcFxcc2hhcmVkXFxsYXlvdXRcXGhlYWRlclxcaGVhZGVyLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksMkNBQTBDO0VBQzFDLFlBQVksRUFBQTs7QUFHaEI7RUFDSSxVQUFVLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9zaGFyZWQvbGF5b3V0L2hlYWRlci9oZWFkZXIuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuc2xkLW5hdiB7XHJcbiAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgcmdiYSgwLCAwLCAwLCAuMSk7XHJcbiAgICBoZWlnaHQ6IDY1cHg7XHJcbn1cclxuXHJcbi50ZXN0ZGl2IHtcclxuICAgIHdpZHRoOiA3MCU7XHJcbn0iXX0= */"

/***/ }),

/***/ "./src/app/shared/layout/header/header.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/shared/layout/header/header.component.ts ***!
  \**********************************************************/
/*! exports provided: HeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderComponent", function() { return HeaderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_core_security_authentication_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/security/authentication.service */ "./src/app/core/security/authentication.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var src_app_lab_result_components_upload_result_upload_result_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/lab-result/components/upload-result/upload-result.component */ "./src/app/lab-result/components/upload-result/upload-result.component.ts");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");







var HeaderComponent = /** @class */ (function () {
    function HeaderComponent(authenticationService, router, modalService) {
        this.authenticationService = authenticationService;
        this.router = router;
        this.modalService = modalService;
    }
    HeaderComponent.prototype.ngOnInit = function () {
        this.currentUser = this.authenticationService.getCurrentUser();
        this.environmentName = src_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].environmentName;
    };
    HeaderComponent.prototype.isLoggedIn = function () {
        var loginStatus = this.authenticationService.isLoggedIn();
        if (loginStatus) {
            this.currentUser = this.authenticationService.getCurrentUser();
        }
        return loginStatus;
    };
    HeaderComponent.prototype.logout = function () {
        this.authenticationService.logout();
        this.router.navigateByUrl('auth');
    };
    /**
     * open pop up to upload results
     */
    HeaderComponent.prototype.uploadResult = function () {
        var modalRef = this.modalService.open(src_app_lab_result_components_upload_result_upload_result_component__WEBPACK_IMPORTED_MODULE_5__["UploadResultComponent"], { size: 'lg' });
    };
    HeaderComponent.prototype.isAdmin = function () {
        return this.isInRole(['admin']);
    };
    HeaderComponent.prototype.isInRole = function (role) {
        return this.authenticationService.hasRole(role);
    };
    HeaderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-header',
            template: __webpack_require__(/*! ./header.component.html */ "./src/app/shared/layout/header/header.component.html"),
            styles: [__webpack_require__(/*! ./header.component.scss */ "./src/app/shared/layout/header/header.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_core_security_authentication_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
            _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_4__["NgbModal"]])
    ], HeaderComponent);
    return HeaderComponent;
}());



/***/ }),

/***/ "./src/app/shared/layout/layout.module.ts":
/*!************************************************!*\
  !*** ./src/app/shared/layout/layout.module.ts ***!
  \************************************************/
/*! exports provided: LayoutModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LayoutModule", function() { return LayoutModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _header_header_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./header/header.component */ "./src/app/shared/layout/header/header.component.ts");
/* harmony import */ var _sidebar_sidebar_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./sidebar/sidebar.component */ "./src/app/shared/layout/sidebar/sidebar.component.ts");
/* harmony import */ var _fortawesome_angular_fontawesome__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @fortawesome/angular-fontawesome */ "./node_modules/@fortawesome/angular-fontawesome/fesm5/angular-fontawesome.js");
/* harmony import */ var _fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @fortawesome/fontawesome-svg-core */ "./node_modules/@fortawesome/fontawesome-svg-core/index.es.js");
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @fortawesome/free-solid-svg-icons */ "./node_modules/@fortawesome/free-solid-svg-icons/index.es.js");
/* harmony import */ var src_app_lab_result_components_upload_result_upload_result_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/lab-result/components/upload-result/upload-result.component */ "./src/app/lab-result/components/upload-result/upload-result.component.ts");
/* harmony import */ var ngx_file_drop__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ngx-file-drop */ "./node_modules/ngx-file-drop/fesm5/ngx-file-drop.js");











var LayoutModule = /** @class */ (function () {
    function LayoutModule() {
        _fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_7__["library"].add(_fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faWater"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faTint"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faHome"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faUser"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faUsers"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faFlask"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faUpload"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faSignInAlt"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faSignOutAlt"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faVials"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faSearch"], _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_8__["faVial"]);
    }
    LayoutModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [
                _header_header_component__WEBPACK_IMPORTED_MODULE_4__["HeaderComponent"],
                _sidebar_sidebar_component__WEBPACK_IMPORTED_MODULE_5__["SidebarComponent"],
            ],
            entryComponents: [
                src_app_lab_result_components_upload_result_upload_result_component__WEBPACK_IMPORTED_MODULE_9__["UploadResultComponent"]
            ],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"],
                _fortawesome_angular_fontawesome__WEBPACK_IMPORTED_MODULE_6__["FontAwesomeModule"],
                ngx_file_drop__WEBPACK_IMPORTED_MODULE_10__["FileDropModule"]
            ],
            exports: [
                _header_header_component__WEBPACK_IMPORTED_MODULE_4__["HeaderComponent"],
                _sidebar_sidebar_component__WEBPACK_IMPORTED_MODULE_5__["SidebarComponent"]
            ]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], LayoutModule);
    return LayoutModule;
}());



/***/ }),

/***/ "./src/app/shared/layout/sidebar/sidebar.component.html":
/*!**************************************************************!*\
  !*** ./src/app/shared/layout/sidebar/sidebar.component.html ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ul class=\"nav\">\r\n    <li class=\"nav-item\">\r\n        <a class=\"nav-link sld-nav-link\" [routerLink]=\"[ '/home' ]\" [routerLinkActive]=\"['font-weight-bold']\">\r\n            <fa-icon icon=\"home\"></fa-icon> Home\r\n        </a>\r\n    </li>\r\n    <li class=\"nav-item\">\r\n        <a class=\"nav-link sld-nav-link\" [routerLink]=\"[ '/search' ]\" [routerLinkActive]=\"['font-weight-bold']\">\r\n            <fa-icon icon=\"search\"></fa-icon> Search\r\n        </a>\r\n    </li>\r\n    <li *ngIf=\"isInRole(['admin', 'Lab_Team', 'Lab_Manager'])\" class=\"nav-item\">\r\n        <a class=\"nav-link sld-nav-link\" [routerLink]=\"[ '/lab-samples' ]\" [routerLinkActive]=\"['font-weight-bold']\">\r\n            <fa-icon icon=\"vial\"></fa-icon> Sample login\r\n        </a>\r\n    </li>\r\n    <li class=\"nav-item\">\r\n        <a class=\"nav-link sld-nav-link\" [routerLink]=\"[ '/lab-requests' ]\" [routerLinkActive]=\"['font-weight-bold']\">\r\n            <fa-icon icon=\"flask\"></fa-icon> Lab request\r\n        </a>\r\n    </li>\r\n    <li *ngIf=\"isInRole(['admin', 'Lab_Team', 'Lab_Manager'])\" class=\"nav-item\">\r\n        <a class=\"nav-link sld-nav-link\" [routerLink]=\"[ '/experimental' ]\" [routerLinkActive]=\"['font-weight-bold']\">\r\n            <fa-icon icon=\"flask\"></fa-icon> Experimental\r\n        </a>\r\n    </li>\r\n    <li *ngIf=\"isInRole(['admin', 'Lab_Team', 'Lab_Manager'])\" class=\"nav-item\">\r\n        <a class=\"nav-link sld-nav-link\" [routerLink]=\"[ '/water-analysis' ]\" [routerLinkActive]=\"['font-weight-bold']\">\r\n            <fa-icon icon=\"tint\"></fa-icon> H<sub>2</sub>O analysis\r\n        </a>\r\n    </li>\r\n    <li *ngIf=\"isInRole(['admin', 'Lab_Team', 'Lab_Manager'])\" class=\"nav-item\">\r\n        <a class=\"nav-link sld-nav-link\" [routerLink]=\"[ '/qc-requests' ]\" [routerLinkActive]=\"['font-weight-bold']\">\r\n            <fa-icon icon=\"vials\"></fa-icon> Quality control\r\n        </a>\r\n    </li>\r\n    <li *ngIf=\"isAdmin()\" class=\"nav-item nav-dropdown\">\r\n        <a class=\"nav-link nav-dropdown-toggle sld-nav-link\" href=\"#\">\r\n      Admin\r\n    </a>\r\n        <ul class=\"nav-dropdown-items\">\r\n            <li class=\"nav-item\">\r\n                <a class=\"nav-link sld-nav-link\" [routerLink]=\"[ '/users' ]\" [routerLinkActive]=\"['font-weight-bold']\">\r\n                    <fa-icon icon=\"users\"></fa-icon> User Management\r\n                </a>\r\n            </li>\r\n        </ul>\r\n    </li>\r\n    <li class=\"nav-item pos_bottom m-2\">\r\n        Version: {{version.version}}\r\n    </li>\r\n</ul>"

/***/ }),

/***/ "./src/app/shared/layout/sidebar/sidebar.component.scss":
/*!**************************************************************!*\
  !*** ./src/app/shared/layout/sidebar/sidebar.component.scss ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".sidebar-link {\n  font-weight: 500; }\n\n.pos_bottom {\n  position: absolute;\n  bottom: 10px;\n  color: #6e273d; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hhcmVkL2xheW91dC9zaWRlYmFyL0U6XFxmcm9udGVuZDIvc3JjXFxhcHBcXHNoYXJlZFxcbGF5b3V0XFxzaWRlYmFyXFxzaWRlYmFyLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksZ0JBQWdCLEVBQUE7O0FBR3BCO0VBQ0ksa0JBQWtCO0VBQ2xCLFlBQVk7RUFDWixjQUFjLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9zaGFyZWQvbGF5b3V0L3NpZGViYXIvc2lkZWJhci5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zaWRlYmFyLWxpbmsge1xyXG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcclxufVxyXG5cclxuLnBvc19ib3R0b20ge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgYm90dG9tOiAxMHB4O1xyXG4gICAgY29sb3I6ICM2ZTI3M2Q7XHJcbn0iXX0= */"

/***/ }),

/***/ "./src/app/shared/layout/sidebar/sidebar.component.ts":
/*!************************************************************!*\
  !*** ./src/app/shared/layout/sidebar/sidebar.component.ts ***!
  \************************************************************/
/*! exports provided: SidebarComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SidebarComponent", function() { return SidebarComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_core_security_authentication_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/security/authentication.service */ "./src/app/core/security/authentication.service.ts");
/* harmony import */ var src_environments_version__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/version */ "./src/environments/version.ts");




var SidebarComponent = /** @class */ (function () {
    function SidebarComponent(authenticationService) {
        this.authenticationService = authenticationService;
    }
    SidebarComponent.prototype.ngOnInit = function () {
        this.version = src_environments_version__WEBPACK_IMPORTED_MODULE_3__["VERSION"];
    };
    SidebarComponent.prototype.isAdmin = function () {
        return this.isInRole(['admin']);
    };
    SidebarComponent.prototype.isInRole = function (role) {
        return this.authenticationService.hasRole(role);
    };
    SidebarComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-sidebar',
            template: __webpack_require__(/*! ./sidebar.component.html */ "./src/app/shared/layout/sidebar/sidebar.component.html"),
            styles: [__webpack_require__(/*! ./sidebar.component.scss */ "./src/app/shared/layout/sidebar/sidebar.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_core_security_authentication_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"]])
    ], SidebarComponent);
    return SidebarComponent;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false,
    environmentName: 'Dev',
    sldAli: 'http://localhost:5000/api'
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/environments/version.ts":
/*!*************************************!*\
  !*** ./src/environments/version.ts ***!
  \*************************************/
/*! exports provided: VERSION */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VERSION", function() { return VERSION; });
// IMPORTANT: THIS FILE IS AUTO GENERATED! DO NOT MANUALLY EDIT OR CHECKIN!
/* tslint:disable */
var VERSION = {
    "version": "0.0.1-dev.8b"
};
/* tslint:enable */


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.error(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! E:\frontend2\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map